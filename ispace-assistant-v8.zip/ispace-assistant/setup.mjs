import { lstatSync, mkdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { applyCommand } from './assistant-runtime/domain.mjs';
import { atomicWrite, location, readState, withLedgerLock } from './assistant-runtime/assistant.mjs';
import { assertOwner, ownerFile, ownerScope, projectRoot, readOwnerConfig } from './assistant-runtime/portable-config.mjs';

const chatIdPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function prepareDraftFolder() {
  const folder = join(projectRoot, '草稿');
  try {
    mkdirSync(folder, { mode: 0o700 });
  } catch (error) {
    if (error.code !== 'EEXIST') throw error;
    if (!lstatSync(folder).isDirectory()) throw new Error('项目的草稿位置需要是一个普通目录');
  }
}

export function setup(input) {
  const { mainChatId, workerChatId, syncStatus } = input ?? {};
  if (typeof mainChatId !== 'string' || !chatIdPattern.test(mainChatId) ||
      (workerChatId !== undefined && (typeof workerChatId !== 'string' || !chatIdPattern.test(workerChatId))) ||
      (workerChatId && mainChatId.toLowerCase() === workerChatId.toLowerCase())) {
    throw new Error('请提供本人当前的 Codex 主聊天 ID 和可选的副聊天 ID');
  }
  const primaryId = mainChatId.toLowerCase();
  const secondaryId = workerChatId?.toLowerCase();
  const { profileHash, courses } = ownerScope(syncStatus);
  const ledgerPath = location('state.json');
  return withLedgerLock(ledgerPath, () => {
    const config = readOwnerConfig({ optional: true });
    if (config) assertOwner(config.profileHash, profileHash);
    const state = readState(ledgerPath);
    if (state.mainChatId && state.mainChatId !== primaryId) throw new Error('项目已有主聊天，请使用交接流程切换');
    const previous = JSON.stringify(state);
    applyCommand(state, 'register-chat', { role: 'main', chatId: primaryId });
    if (secondaryId) applyCommand(state, 'register-chat', { role: 'worker', chatId: secondaryId });
    prepareDraftFolder();
    if (!config) atomicWrite(ownerFile, JSON.stringify({ version: 1, profileHash }, null, 2) + '\n');
    // Both writes are atomic and serialized. Retrying within the same account can finish interrupted setup.
    if (JSON.stringify(state) !== previous) {
      state.revision += 1;
      atomicWrite(ledgerPath, JSON.stringify(state, null, 2) + '\n');
    }
    return { mainChatId: state.mainChatId, workerChatIds: Object.values(state.chats)
      .filter(chat => chat.role === 'worker' && chat.status === 'active').map(chat => chat.id),
      courseCount: courses.length, profileBound: true };
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    if (process.argv.length !== 3 || process.argv[2] !== '--stdin') {
      throw new Error('用法：node setup.mjs --stdin，输入主聊天 ID、可选副聊天 ID 和已连接的 iSpace 状态 JSON');
    }
    const raw = readFileSync(0, 'utf8');
    if (Buffer.byteLength(raw, 'utf8') > 128 * 1024) throw new Error('初始化输入过大');
    const input = JSON.parse(raw.replace(/^\uFEFF/, ''));
    process.stdout.write(JSON.stringify(setup(input), null, 2) + '\n');
  } catch (error) {
    process.stderr.write(JSON.stringify({ error: error instanceof SyntaxError ? '初始化输入或本机配置不是有效 JSON' : error.message }) + '\n');
    process.exitCode = 1;
  }
}
