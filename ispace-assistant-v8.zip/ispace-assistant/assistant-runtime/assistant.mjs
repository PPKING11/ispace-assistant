import { randomUUID } from 'node:crypto';
import { closeSync, existsSync, fsyncSync, lstatSync, openSync, readFileSync, realpathSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { applyCommand, describeState, emptyState, LedgerError } from './domain.mjs';
import { archiveSubmissionReceipt, verifySubmissionReceiptArchive } from './submission-receipt.mjs';

const project = realpathSync(fileURLToPath(new URL('../', import.meta.url)));
const validStateName = /^[a-z0-9][a-z0-9._-]*\.json$/i;

function relativeDirectory(absolute) {
  const inside = relative(project, absolute);
  if (isAbsolute(inside) || inside === '..' || inside.startsWith(`..${sep}`)) {
    throw new LedgerError('任务记录必须保存在 ispace助手 项目内');
  }
}

export function safeFile(path) {
  try {
    const info = lstatSync(path);
    if (!info.isFile() || info.isSymbolicLink() || info.nlink > 1) throw new LedgerError('任务记录和锁必须是普通独立文件');
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
}

export function location(value) {
  if (!value || isAbsolute(value) || !validStateName.test(basename(value))) {
    throw new LedgerError('请选择项目内的相对 JSON 路径，例如 state.json');
  }
  const path = resolve(project, value);
  relativeDirectory(path);
  const directory = realpathSync(dirname(path));
  relativeDirectory(directory);
  const actual = join(directory, basename(path));
  safeFile(actual);
  return actual;
}

export function readState(path) {
  try {
    const state = JSON.parse(readFileSync(path, 'utf8'));
    if (state.schemaVersion !== 1 || !Number.isSafeInteger(state.revision) || state.revision < 0 || !state.chats || !state.tasks ||
      !state.rotations || !state.oldChatPolicy || !state.oldChatCounts) throw new LedgerError('任务记录格式不匹配');
    return state;
  } catch (error) {
    if (error.code === 'ENOENT') return emptyState();
    throw error;
  }
}

export function atomicWrite(path, content) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  const fd = openSync(temporary, 'wx', 0o600);
  try {
    try {
      writeFileSync(fd, content, 'utf8');
      fsyncSync(fd);
    } finally {
      closeSync(fd);
    }
    renameSync(temporary, path);
  } finally {
    if (existsSync(temporary)) rmSync(temporary);
  }
}

export function withLedgerLock(path, action) {
  // The SQLite file supplies an OS-backed writer lock. state.json remains the only task ledger.
  // A terminated process releases the lock. An interrupted write leaves either complete JSON revision.
  const lockPath = `${path}.lock.sqlite`;
  safeFile(lockPath);
  const lock = new DatabaseSync(lockPath);
  try {
    lock.exec('PRAGMA busy_timeout = 6000; BEGIN IMMEDIATE');
    const result = action();
    lock.exec('COMMIT');
    return result;
  } finally {
    lock.close();
  }
}

function mutate(path, command, input) {
  return withLedgerLock(path, () => {
    const state = readState(path);
    const previous = JSON.stringify(state);
    const result = applyCommand(state, command, input, undefined, {
      archiveReceipt: receipt => archiveSubmissionReceipt({ ...receipt, projectDir: dirname(path) }),
    });
    if (previous !== JSON.stringify(state)) {
      state.revision += 1;
      atomicWrite(path, JSON.stringify(state, null, 2) + '\n');
    }
    return result;
  });
}

function args(values) {
  const [command, ...parameters] = values;
  if (!command) throw new LedgerError('用法：node assistant-runtime/assistant.mjs 操作 [JSON] [--state 相对路径]');
  let state = 'state.json';
  let raw = null;
  for (let index = 0; index < parameters.length; index += 1) {
    const parameter = parameters[index];
    if (parameter === '--state') state = parameters[++index];
    else if (parameter === '--stdin' && raw === null) raw = readFileSync(0, 'utf8');
    else if (raw === null) raw = parameter;
    else throw new LedgerError('请把操作参数写在一个 JSON 对象中');
  }
  const input = raw === null ? {} : JSON.parse(raw.replace(/^\uFEFF/, ''));
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new LedgerError('参数必须是 JSON 对象');
  return { command, input, path: location(state) };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    const { command, input, path } = args(process.argv.slice(2));
    const result = command === 'status' ? describeState(readState(path), input) : command === 'verify-receipt-archive'
      ? verifySubmissionReceiptArchive({ path: input.path, sha256: input.sha256, projectDir: dirname(path) })
      : mutate(path, command, input);
    process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  } catch (error) {
    const message = error instanceof LedgerError ? error.message : error instanceof SyntaxError ? 'JSON 参数或任务记录无法读取' :
      error.errcode === 5 ? '任务记录暂时忙，请稍后重试' : error.message;
    process.stderr.write(JSON.stringify({ error: message }) + '\n');
    process.exitCode = 1;
  }
}
