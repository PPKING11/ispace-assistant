import { createHash, randomUUID } from 'node:crypto';
import { closeSync, fsyncSync, fstatSync, lstatSync, mkdirSync, openSync, readSync, realpathSync, renameSync, rmdirSync, unlinkSync, writeFileSync } from 'node:fs';
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';

const archiveFolder = '回执';
const statuses = ['submitted', 'draft', 'not_submitted', 'unknown'];
const sha256Pattern = /^[a-f0-9]{64}$/;
const fileLimit = 8 * 1024 * 1024;
const manifestLimit = 64 * 1024;
const pngSignature = Buffer.from('89504e470d0a1a0a0000000d49484452', 'hex');
const pngEnd = Buffer.from('0000000049454e44ae426082', 'hex');

function check(condition, message) {
  if (!condition) throw new Error(message);
}

function digest(data) {
  return createHash('sha256').update(data).digest('hex');
}

function boundedText(value, name, limit) {
  check(typeof value === 'string' && value.trim() && value.length <= limit &&
    !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(value), '无效的' + name);
  check(!/\b(?:wstoken|sesskey|password|authorization|cookie|access_token)\s*[:=]\s*\S/iu.test(value),
    '回执仅需学校状态，请移除凭据字段');
  return value.trim();
}

function time(value, name) {
  if (value === undefined || value === null) return null;
  check(typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/u.test(value) &&
    Number.isFinite(Date.parse(value)), '无效的' + name + '，需包含时区');
  return new Date(value).toISOString();
}

function inside(base, path) {
  const value = relative(base, path);
  return Boolean(value && value !== '..' && !value.startsWith('..' + sep) && !isAbsolute(value));
}

function regularBytes(path, limit, label) {
  let info;
  try {
    info = lstatSync(path);
  } catch (error) {
    if (error.code === 'ENOENT') throw new Error('找不到' + label);
    throw error;
  }
  check(info.isFile() && !info.isSymbolicLink() && info.nlink === 1, label + '须是普通独立文件');
  check(info.size > 0 && info.size <= limit, label + '大小超限或为空');
  const fd = openSync(path, 'r');
  try {
    const opened = fstatSync(fd);
    check(opened.isFile() && opened.dev === info.dev && opened.ino === info.ino && opened.size === info.size,
      label + '在读取前已变化');
    const bytes = Buffer.alloc(info.size);
    let offset = 0;
    while (offset < bytes.length) {
      const length = readSync(fd, bytes, offset, bytes.length - offset, offset);
      check(length > 0, label + '在读取时已变化');
      offset += length;
    }
    const after = fstatSync(fd);
    check(after.size === info.size && after.mtimeMs === info.mtimeMs, label + '在读取时已变化');
    return bytes;
  } finally {
    closeSync(fd);
  }
}

function dir(parent, name, create, missing = false) {
  const path = join(parent, name);
  if (create) {
    try {
      mkdirSync(path, { mode: 0o700 });
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
    }
  }
  let info;
  try {
    info = lstatSync(path);
  } catch (error) {
    if (missing && error.code === 'ENOENT') return null;
    throw error;
  }
  check(info.isDirectory() && !info.isSymbolicLink() && realpathSync(path) === path, '回执目录须为项目内普通目录');
  return path;
}

function writeExclusive(path, bytes) {
  const fd = openSync(path, 'wx', 0o600);
  try {
    writeFileSync(fd, bytes);
    fsyncSync(fd);
  } finally {
    closeSync(fd);
  }
}

function publishArchive(parent, status, contents, image) {
  const staging = join(parent, '.receipt-' + randomUUID());
  mkdirSync(staging, { mode: 0o700 });
  const stagedFiles = [join(staging, 'receipt.json')];
  if (image) stagedFiles.push(join(staging, image.info.name));
  let moved = false;
  try {
    writeExclusive(stagedFiles[0], contents);
    if (image) writeExclusive(stagedFiles[1], image.bytes);
    const next = join(parent, status);
    check(realpathSync(staging) === staging && dirname(staging) === parent && dirname(next) === parent,
      '回执暂存目录须位于指定尝试目录');
    if (!dir(parent, status, false, true)) {
      try {
        renameSync(staging, next);
        moved = true;
      } catch (error) {
        if (!dir(parent, status, false, true)) throw error;
      }
    }
  } finally {
    if (!moved) {
      for (const file of stagedFiles) {
        try {
          unlinkSync(file);
        } catch (error) {
          if (error.code !== 'ENOENT') throw error;
        }
      }
      rmdirSync(staging);
    }
  }
}

function filename(value) {
  const name = boundedText(value, '文件名', 240);
  check(name === value && name !== '.' && name !== '..' && !/[/\\:\u0009\u000a\u000d]/u.test(name), '无效的文件名');
  return name;
}

function byteCount(value) {
  check(Number.isSafeInteger(value) && value >= 0, '无效的文件大小');
  return value;
}

function taskBinding(task, attempt, status) {
  const assignment = /^([1-9]\d{0,15}):assignment:([1-9]\d{0,15})$/u.exec(task?.id);
  const schoolUrl = /^https:\/\/ispace\.bnbu\.edu\.cn\/mod\/assign\/view\.php\?id=([1-9]\d{0,15})$/u.exec(task?.source);
  check(assignment && schoolUrl, '回执任务须绑定正式 iSpace 作业和学校原页');
  check(statuses.includes(status), '无效的回执状态');
  check(typeof attempt?.id === 'string' && /^[a-z0-9][a-z0-9._:-]{0,179}$/iu.test(attempt.id),
    '无效的提交尝试编号');
  check(typeof attempt.file?.path === 'string' && sha256Pattern.test(attempt.file.sha256), '提交尝试缺少有效的文件信息');
  const course = typeof task.course === 'string' ? boundedText(task.course, '课程名称', 80) : null;
  const courseFolder = course && /^[a-z][a-z0-9_-]{0,20}$/iu.test(course) &&
    !/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])$/iu.test(course) ? course.toUpperCase() : '课程-' + assignment[1];
  const attemptPrefix = attempt.id.slice(0, 26).toLowerCase().replace(/[^a-z0-9_-]/gu, '-');
  return {
    folders: [archiveFolder, courseFolder, assignment[1] + '-assignment-' + assignment[2],
      '提交-' + attemptPrefix + '-' + digest(attempt.id).slice(0, 24)],
    task: {
      id: task.id, course, title: boundedText(task.title, '作业名', 240), schoolUrl: task.source,
    },
    attempt: { id: attempt.id, startedAt: time(attempt.startedAt, '尝试开始时间') },
    submittedFile: {
      name: filename(basename(attempt.file.path)), version: boundedText(attempt.file.version, '文件版本', 160),
      sha256: attempt.file.sha256, bytes: attempt.file.bytes === undefined ? null : byteCount(attempt.file.bytes),
    },
  };
}

function schoolObservation(value, binding, status) {
  check(value && typeof value === 'object' && !Array.isArray(value), '无效的学校回执');
  const { text, observedAt, schoolTime, schoolTimeText, files } = value;
  let schoolFiles = null;
  if (files !== undefined && files !== null) {
    check(Array.isArray(files) && files.length <= 25, '无效的学校文件清单');
    schoolFiles = files.map(file => ({ name: filename(file?.name), bytes: file?.bytes == null ? null : byteCount(file.bytes) }));
    schoolFiles.sort((a, b) => a.name < b.name ? -1 : a.name > b.name ? 1 : (a.bytes ?? -1) - (b.bytes ?? -1));
  }
  const proof = status === 'unknown' ? 'unconfirmed' :
    (status === 'submitted' || status === 'draft') && schoolFiles?.length === 1 && binding.bytes !== null &&
    schoolFiles[0].name === binding.name && schoolFiles[0].bytes === binding.bytes ? 'file_metadata_match' : 'school_status';
  return {
    text: boundedText(text, '学校页面状态文字', 2800),
    observedAt: time(observedAt, '现场读取时间'),
    schoolTime: time(schoolTime, '学校记录时间'),
    schoolTimeText: schoolTimeText == null ? null : boundedText(schoolTimeText, '学校时间原文', 180),
    files: schoolFiles,
    proof,
    verifiedBytes: false,
  };
}

function screenshot(project, value) {
  const path = resolve(project, boundedText(value, '截图路径', 1200));
  const archiveRoot = join(project, archiveFolder);
  check(inside(project, path) && !inside(archiveRoot, path), '截图须先保存在项目内的草稿目录');
  const actual = realpathSync(path);
  check(inside(project, actual) && !inside(archiveRoot, actual) && actual === path, '截图须是项目内的普通文件');
  const bytes = regularBytes(actual, fileLimit, '学校回执截图');
  const png = bytes.subarray(0, pngSignature.length).equals(pngSignature) && bytes.subarray(-pngEnd.length).equals(pngEnd);
  const jpeg = bytes.length >= 8 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff &&
    bytes.at(-2) === 0xff && bytes.at(-1) === 0xd9;
  const name = png ? 'school.png' : jpeg ? 'school.jpg' : null;
  check(name && (png ? /\.png$/iu : /\.jpe?g$/iu).test(path), '学校回执截图仅接受有效的 PNG 或 JPEG');
  return { bytes, info: { name, bytes: bytes.length, sha256: digest(bytes) } };
}

function readManifest(path) {
  const bytes = regularBytes(path, manifestLimit, '回执 JSON');
  let receipt;
  try {
    receipt = JSON.parse(bytes);
  } catch {
    throw new Error('回执 JSON 已损坏');
  }
  check(receipt?.schemaVersion === 1 && statuses.includes(receipt.status) &&
    ['unconfirmed', 'school_status', 'file_metadata_match'].includes(receipt.school?.proof) &&
    receipt.school.verifiedBytes === false, '回执 JSON 结构无效');
  return { receipt, sha256: digest(bytes) };
}

function archiveInfo(path, manifest) {
  const { receipt, sha256 } = manifest;
  let image;
  if (receipt.screenshot) {
    const metadata = receipt.screenshot;
    check(['school.png', 'school.jpg'].includes(metadata.name) && sha256Pattern.test(metadata.sha256),
      '回执截图记录无效');
    const imagePath = join(dirname(path), metadata.name);
    const bytes = regularBytes(imagePath, fileLimit, '已存档截图');
    check(bytes.length === metadata.bytes && digest(bytes) === metadata.sha256, '回执截图校验失败');
    image = { path: imagePath, sha256: metadata.sha256, bytes: metadata.bytes };
  }
  return {
    path, sha256, ...(image ? { screenshot: image } : {}), proof: receipt.school.proof, verifiedBytes: false,
    observedAt: receipt.school.observedAt, schoolTime: receipt.school.schoolTime,
  };
}

export function verifySubmissionReceiptArchive({ projectDir, path, sha256 }) {
  check(sha256Pattern.test(sha256), '需要回执 JSON 的 SHA-256');
  const project = realpathSync(projectDir);
  const absolute = resolve(project, path);
  const root = dir(project, archiveFolder, false);
  check(inside(root, absolute) && basename(absolute) === 'receipt.json', '回执须位于项目归档目录');
  const segments = relative(root, absolute).split(sep);
  check(segments.length === 5, '回执须位于课程与作业的归档目录');
  const directory = segments.slice(0, -1).reduce((parent, name) => dir(parent, name, false), root);
  const archivePath = join(directory, 'receipt.json');
  const manifest = readManifest(archivePath);
  check(manifest.sha256 === sha256, '回执 JSON 校验失败');
  return archiveInfo(archivePath, manifest);
}

export function archiveSubmissionReceipt({ projectDir, task, attempt, status, evidence, schoolReceipt, now = new Date().toISOString() }) {
  const recordedAt = time(now, '归档时间');
  check(recordedAt, '归档时间不能为空');
  const binding = taskBinding(task, attempt, status);
  const notes = boundedText(evidence, '回执依据', 1600);
  const school = schoolObservation(schoolReceipt ?? { text: notes }, binding.submittedFile, status);
  const { screenshotPath, screenshotUnavailableReason } = schoolReceipt ?? {};
  check(screenshotPath == null || screenshotUnavailableReason == null, '请填写截图路径或截图缺失原因其中一项');
  const absentReason = screenshotUnavailableReason == null ? '本次回读未保存学校回执截图' :
    boundedText(screenshotUnavailableReason, '截图缺失原因', 400);
  const project = realpathSync(projectDir);
  const image = screenshotPath == null ? null : screenshot(project, screenshotPath);
  const attemptDirectory = binding.folders.reduce((parent, name) => dir(parent, name, true), project);
  const existingDirectory = dir(attemptDirectory, status, false, true);
  const path = join(attemptDirectory, status, 'receipt.json');
  const existing = existingDirectory ? readManifest(path) : null;
  const receipt = {
    schemaVersion: 1, task: binding.task, attempt: binding.attempt, status, submittedFile: binding.submittedFile,
    notes, school, recordedAt: existing?.receipt.recordedAt ?? recordedAt,
    screenshot: image?.info ?? null, screenshotUnavailableReason: image ? null : absentReason,
  };
  if (!existing) publishArchive(attemptDirectory, status, Buffer.from(JSON.stringify(receipt, null, 2) + '\n', 'utf8'), image);
  const manifest = existing ?? readManifest(path);
  // An identical retry may run later or race another ledger. Preserve the original archive time.
  receipt.recordedAt = manifest.receipt.recordedAt;
  const contents = Buffer.from(JSON.stringify(receipt, null, 2) + '\n', 'utf8');
  check(manifest.sha256 === digest(contents), '这次提交的同一状态已有不同证据，无法覆盖');
  return archiveInfo(path, manifest);
}

