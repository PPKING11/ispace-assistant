import { randomUUID } from 'node:crypto';
import { parseSchoolSubmissionUrl, verifyLocalSubmissionFile } from './submission-precheck.mjs';

export const policy = Object.freeze({
  main: Object.freeze({ title: 'ispace助手', oldPrefix: '过时主聊天', rounds: 40, days: 7 }),
  worker: Object.freeze({ title: '默默工作的后台员工', oldPrefix: '过时副聊天', rounds: 25, days: 3 }),
});

const dayMs = 24 * 60 * 60 * 1000;
const taskStatuses = ['todo', 'active', 'blocked', 'ready', 'done'];
const receiptStatuses = ['submitted', 'draft', 'not_submitted', 'unknown'];
const submissionModes = ['individual', 'group'];
const schoolCheckMaxAgeMs = 2 * 60 * 1000;
const openSubmission = task => ['sending', 'unknown'].includes(task.submission?.phase);
const unresolvedTask = task => task.status !== 'done';

export class LedgerError extends Error {}

function requireThat(condition, message) {
  if (!condition) throw new LedgerError(message);
}

function string(value, name, limit = 1000) {
  requireThat(typeof value === 'string' && value.trim() && value.length <= limit, `无效的 ${name}`);
  return value;
}

function identity(value, name) {
  const id = string(value, name, 180);
  requireThat(/^[a-z0-9][a-z0-9._:-]*$/i.test(id) && !Object.hasOwn(Object.prototype, id), `无效的 ${name}`);
  return id;
}

function timestamp(value, name) {
  requireThat(typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T.*(?:Z|[+-]\d{2}:\d{2})$/.test(value) &&
    Number.isFinite(Date.parse(value)), `无效的 ${name}，需包含时区`);
  return new Date(value).toISOString();
}

function dueDate(value) {
  if (value === null) return null;
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
    const parsed = new Date(value);
    requireThat(Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value, '无效的截止日期');
    return value;
  }
  return timestamp(value, '截止时间');
}

function boolean(value, name) {
  requireThat(typeof value === 'boolean', `无效的 ${name}`);
  return value;
}

function sha256(value) {
  requireThat(typeof value === 'string' && /^[a-f0-9]{64}$/i.test(value), '无效的文件 SHA-256');
  return value.toLowerCase();
}

function artifactInfo(value) {
  requireThat(value && typeof value === 'object' && !Array.isArray(value), '无效的文件记录');
  const result = {
    path: string(value.path, '文件路径', 1200),
    version: string(value.version, '文件版本', 160),
    sha256: sha256(value.sha256),
  };
  if (value.bytes !== undefined) {
    requireThat(Number.isSafeInteger(value.bytes) && value.bytes > 0, '无效的文件字节数');
    result.bytes = value.bytes;
  }
  return result;
}

export function emptyState() {
  return {
    schemaVersion: 1,
    revision: 0,
    mainChatId: null,
    chats: {},
    tasks: {},
    rotations: {},
    oldChatPolicy: { asked: false, choice: null },
    oldChatCounts: { main: 0, worker: 0 },
  };
}

function chatFor(state, chatId) {
  const id = identity(chatId, '聊天 ID');
  const chat = state.chats[id];
  requireThat(chat, '找不到这个聊天');
  return chat;
}

function activeChat(state, chatId, requiredRole) {
  const chat = chatFor(state, chatId);
  requireThat(chat.status === 'active' && (!requiredRole || chat.role === requiredRole), '这不是符合要求的当前工作聊天');
  return chat;
}

function taskFor(state, taskId) {
  const id = identity(taskId, '任务 ID');
  const task = state.tasks[id];
  requireThat(task, '找不到这个任务');
  return task;
}

function taskActor(state, task, chatId) {
  const chat = activeChat(state, chatId);
  requireThat(chat.role === 'main' || chat.id === task.workerId, '这项任务由另一个副聊天负责');
  return chat;
}

function rotationFor(state, id) {
  const rotation = state.rotations[identity(id, '交接 ID')];
  requireThat(rotation, '找不到这个交接');
  return rotation;
}

function openRotation(state, chatId) {
  return Object.values(state.rotations).find(rotation => rotation.oldChatId === chatId &&
    ['planned', 'attached', 'acknowledged'].includes(rotation.phase));
}

function chatRecord(id, role, createdAt, status = 'active') {
  return { id, role, title: policy[role].title, createdAt, status, rounds: 0, working: false, contextStrained: false };
}

export function rotationStatus(state, chat, { now, workPending = false }) {
  const limits = policy[chat.role];
  const elapsedDays = Math.floor(Math.max(0, Date.parse(now) - Date.parse(chat.createdAt)) / dayMs);
  const reason = chat.contextStrained ? '上下文需要整理' : chat.rounds >= limits.rounds ? '轮数已到' : elapsedDays >= limits.days ? '天数已到' : null;
  const tasks = Object.values(state.tasks).filter(task => unresolvedTask(task) && (chat.role === 'main' || task.workerId === chat.id));
  const blockers = [];
  if (chat.working) blockers.push('当前操作尚未到安全交接点');
  if (tasks.some(openSubmission)) blockers.push('还有学校提交状态待核实');
  if (!workPending && !tasks.length) blockers.push('当前没有要接续的任务');
  return { chatId: chat.id, role: chat.role, rounds: chat.rounds, elapsedDays, due: Boolean(reason), reason, canRotate: Boolean(reason) && blockers.length === 0,
    blockers, taskIds: tasks.map(task => task.id) };
}

export function describeState(state, input = {}, now = new Date().toISOString()) {
  if (input.workPending !== undefined) boolean(input.workPending, '有待处理工作');
  const chats = input.chatId ? [activeChat(state, input.chatId)] : Object.values(state.chats).filter(chat => chat.status === 'active');
  return { state, rotationChecks: chats.map(chat => rotationStatus(state, chat, { now, workPending: input.workPending })) };
}

function registerChat(state, { role, chatId, createdAt }, now) {
  const id = identity(chatId, '聊天 ID');
  requireThat(Object.hasOwn(policy, role), '聊天角色必须是 main 或 worker');
  if (state.chats[id]) {
    requireThat(state.chats[id].role === role && state.chats[id].status === 'active', '该聊天 ID 已有不同职责');
    return state.chats[id];
  }
  if (role === 'main') requireThat(!state.mainChatId, '已有主聊天，请走交接流程');
  const start = createdAt === undefined ? now : timestamp(createdAt, '开始时间');
  requireThat(start <= now, '开始时间不能晚于当前时间');
  const chat = chatRecord(id, role, start);
  state.chats[id] = chat;
  if (role === 'main') state.mainChatId = id;
  return chat;
}

function observeRounds(state, { chatId, rounds, working, contextStrained }) {
  const chat = activeChat(state, chatId);
  requireThat(Number.isSafeInteger(rounds) && rounds >= 0, '轮数必须是非负整数');
  chat.rounds = Math.max(chat.rounds, rounds);
  if (working !== undefined) chat.working = boolean(working, '工作中');
  if (contextStrained !== undefined) chat.contextStrained = boolean(contextStrained, '上下文过长');
  return chat;
}

function addTask(state, { taskId, title, course, dueAt, source, nextStep }) {
  const id = identity(taskId, '任务 ID');
  if (state.tasks[id]) return state.tasks[id];
  const task = { id, title: string(title, '作业名', 240), status: 'todo', workerId: null, artifact: null, submission: null,
    course: course === undefined ? null : string(course, '课程', 80),
    dueAt: dueAt === undefined ? null : dueDate(dueAt),
    source: source === undefined ? null : string(source, '来源'),
    nextStep: nextStep === undefined ? '核对题目、课件和作业要求' : string(nextStep, '下一步', 1600),
  };
  state.tasks[id] = task;
  return task;
}

function assignTask(state, { taskId, chatId }) {
  const task = taskFor(state, taskId);
  const worker = activeChat(state, chatId, 'worker');
  requireThat(unresolvedTask(task), '任务已完成');
  requireThat(!openRotation(state, worker.id), '该副聊天正在交接');
  requireThat(!task.workerId || task.workerId === worker.id, '这个作业已经有负责修改的副聊天');
  if (task.workerId === worker.id) return task;
  task.workerId = worker.id;
  if (task.status === 'todo') task.status = 'active';
  return task;
}

function updateTask(state, { taskId, chatId, status, nextStep, artifact, dueAt, source }) {
  const task = taskFor(state, taskId);
  const actor = taskActor(state, task, chatId);
  requireThat(!openSubmission(task), '提交结果还未核实，请先记录学校状态');
  requireThat(task.submission?.phase !== 'submitted', '学校已确认提交，本次提交记录保留');
  requireThat(artifact === undefined || !task.workerId || task.workerId === actor.id, '只有当前的文件负责人能登记新版');
  const nextArtifact = artifact === undefined ? null : artifactInfo(artifact);
  if (nextStep !== undefined) task.nextStep = string(nextStep, '下一步', 1600);
  if (dueAt !== undefined) task.dueAt = dueDate(dueAt);
  if (source !== undefined) task.source = string(source, '来源');
  if (status !== undefined) {
    requireThat(taskStatuses.includes(status), '无效的任务状态');
    task.status = status;
    if (status !== 'ready' && task.submission?.phase === 'approved') {
      task.submission = { ...task.submission, phase: 'revoked', approval: null };
    }
  }
  if (nextArtifact) {
    if (task.artifact && (task.artifact.sha256 !== nextArtifact.sha256 || task.artifact.path !== nextArtifact.path ||
      task.artifact.version !== nextArtifact.version || task.artifact.bytes !== nextArtifact.bytes) &&
      task.submission?.phase === 'approved') {
      task.submission = { ...task.submission, phase: 'revoked', approval: null };
    }
    task.artifact = nextArtifact;
  }
  return task;
}

function releaseTask(state, { taskId, chatId }) {
  const task = taskFor(state, taskId);
  taskActor(state, task, chatId);
  requireThat(!openSubmission(task), '提交结果还未核实，暂不能释放任务');
  task.workerId = null;
  if (task.status === 'active') task.status = 'todo';
  return task;
}

function submissionTarget(task) {
  const ids = /^([1-9][0-9]*):assignment:([1-9][0-9]*)$/.exec(task.id);
  const page = parseSchoolSubmissionUrl(task.source);
  requireThat(ids && page, '请先登记这项作业的课程、作业编号和学校原页');
  const courseId = Number(ids[1]);
  const assignmentId = Number(ids[2]);
  requireThat(Number.isSafeInteger(courseId) && Number.isSafeInteger(assignmentId), '学校课程或作业编号无效');
  return { courseId, assignmentId, ...page };
}

function approveSubmission(state, { taskId, chatId, fileSha256, authorizationRef, workScope, finalizeDraft = false }, now) {
  const task = taskFor(state, taskId);
  activeChat(state, chatId, 'main');
  requireThat(!openSubmission(task) && task.submission?.phase !== 'submitted', '现有的提交尝试须先核实');
  requireThat(task.status === 'ready' && task.artifact, '请先确定待提交的最终文件');
  const hash = sha256(fileSha256);
  requireThat(task.artifact.sha256 === hash, '本次确认与最终文件不匹配');
  requireThat(submissionModes.includes(workScope), '先核对题面明确要求个人还是小组完成');
  const target = submissionTarget(task);
  boolean(finalizeDraft, '仅正式提交已有草稿');
  if (task.submission?.phase === 'draft') {
    requireThat(finalizeDraft && task.submission.attempt?.file.sha256 === hash, '先核对已存学校草稿，确认相同文件后才可继续正式提交');
  } else {
    requireThat(!finalizeDraft || (task.submission?.phase === 'approved' && task.submission.approval?.finalizeDraft), '没有可继续的学校草稿');
  }
  const ref = string(authorizationRef, '用户确认记录', 400);
  if (task.submission?.phase === 'approved' && task.submission.approval?.authorizationRef === ref &&
    task.submission.approval.file.sha256 === hash) {
    const approval = task.submission.approval;
    requireThat(approval.finalizeDraft === finalizeDraft && (!approval.workScope || approval.workScope === workScope),
      '提交方式或作业范围发生变化，请重新确认');
    requireThat(!approval.target || approval.target.url === target.url, '学校作业页面已变，请重新确认');
    approval.workScope = workScope;
    approval.target = target;
    return task.submission;
  }
  requireThat(task.submission?.attempt?.authorizationRef !== ref, '再次提交需要对具体文件重新确认');
  task.submission = {
    phase: 'approved', attempt: task.submission?.attempt ?? null,
    approval: { at: now, authorizationRef: ref, file: { ...task.artifact }, workScope, target, finalizeDraft },
  };
  return task.submission;
}

function observeSchoolSubmission(target, school, workScope, now) {
  requireThat(submissionModes.includes(workScope), '请先在提交确认中补上题面的个人或小组要求');
  requireThat(school && typeof school === 'object' && !Array.isArray(school), '请先读回学校页面的当前提交状态');
  const page = parseSchoolSubmissionUrl(school.url);
  requireThat(page && school.courseId === target.courseId && school.assignmentId === target.assignmentId &&
    school.moduleId === target.moduleId && page.moduleId === target.moduleId, '学校课程、作业或页面与任务记录不符');
  const observedAt = timestamp(school.observedAt, '学校页面核对时间');
  const ageMs = Date.parse(now) - Date.parse(observedAt);
  requireThat(ageMs >= 0 && ageMs <= schoolCheckMaxAgeMs, '学校页面核对已过时，请重新读取');
  requireThat(school.status !== 'submitted', '学校已有提交，暂停操作');
  requireThat(['not_submitted', 'draft'].includes(school.status), '学校提交状态不明确，暂停操作');
  requireThat(school.canAct === true, '学校未开放本阶段操作，或仍有本人确认事项，暂停操作');
  requireThat(submissionModes.includes(school.submissionMode), '学校上传入口类型不明确，暂停操作');
  requireThat(Number.isSafeInteger(school.savedFileCount) && school.savedFileCount >= 0, '学校已存文件数量不明确，暂停操作');
  const check = {
    ...target, observedAt, canAct: true,
    status: school.status, submissionMode: school.submissionMode, hasSeparateSubmit: boolean(school.hasSeparateSubmit, '是否有独立提交按钮'),
    savedFileCount: school.savedFileCount, evidence: string(school.evidence, '学校页面依据', 1000),
  };
  if (workScope === 'group' || check.submissionMode === 'group') {
    requireThat(school.groupStatus !== 'conflict', '组内已有冲突的提交或草稿，暂停操作');
    requireThat(school.groupStatus === 'clear', '组内提交情况或上传人不明确，暂停操作');
    check.groupStatus = 'clear';
    check.groupEvidence = string(school.groupEvidence, '本组上传人与已有提交核对依据', 1000);
  }
  if (check.status === 'draft' && school.draftSha256 !== undefined) check.draftSha256 = sha256(school.draftSha256);
  return check;
}

function checkExpectedSchoolFiles(check, file, needsDraft) {
  if (needsDraft) {
    requireThat(check.hasSeparateSubmit && check.status === 'draft' && check.savedFileCount === 1 && check.draftSha256 === file.sha256,
      '请从学校草稿原件核对唯一文件的 SHA-256，确认是同一版本后才能正式提交');
  } else {
    requireThat(check.status === 'not_submitted' && check.savedFileCount === 0, '学校已有草稿或文件，暂停覆盖');
  }
}

function startSubmission(state, { taskId, chatId, attemptId, school }, now) {
  const task = taskFor(state, taskId);
  const worker = activeChat(state, chatId, 'worker');
  requireThat(task.workerId === worker.id, '只有该作业的负责人能执行已确认的提交');
  const id = identity(attemptId, '提交尝试 ID');
  const previous = task.submission;
  if (previous?.attempt?.id === id) return { shouldAct: false, submission: previous };
  requireThat(!openRotation(state, worker.id), '负责人正在交接，暂不开始提交');
  requireThat(task.status === 'ready' && previous?.phase === 'approved', '没有可以执行的明确提交确认');
  const { file, authorizationRef, workScope, target, finalizeDraft } = previous.approval;
  requireThat(task.artifact.sha256 === file.sha256 && task.artifact.path === file.path && task.artifact.version === file.version &&
    task.artifact.bytes === file.bytes, '文件已变化，请重新确认');
  const currentTarget = submissionTarget(task);
  requireThat(target && target.url === currentTarget.url, '学校作业页面尚未绑定或已经变化，请重新核对提交确认');
  const check = observeSchoolSubmission(currentTarget, school, workScope, now);
  checkExpectedSchoolFiles(check, file, finalizeDraft);
  const verified = verifyLocalSubmissionFile(file);
  requireThat(verified, '本机最终文件无法读取，或文件 SHA-256／大小与确认不符，暂停操作');
  task.submission = { phase: 'sending', approval: null,
    attempt: { id, workerId: worker.id, startedAt: now, file: verified, authorizationRef, workScope, finalizeDraft,
      uploadCheck: { ...check, checkedAt: now } } };
  return { shouldAct: true, action: finalizeDraft ? 'finalize_draft' : 'attach', submission: task.submission };
}

function authorizeSubmit(state, { taskId, chatId, attemptId, school }, now) {
  const task = taskFor(state, taskId);
  const worker = activeChat(state, chatId, 'worker');
  const attempt = task.submission?.attempt;
  requireThat(attempt && attempt.id === identity(attemptId, '提交尝试 ID') &&
    task.workerId === worker.id && attempt.workerId === worker.id, '只有本次提交的负责人可以核对正式提交');
  if (attempt.finalCheck) return { shouldSubmit: false, submission: task.submission };
  requireThat(task.submission.phase === 'sending' && attempt.uploadCheck, '请先核对附件上传阶段；已有尝试状态不明时请回读学校回执');
  const initial = attempt.uploadCheck;
  const target = submissionTarget(task);
  requireThat(target.url === initial.url, '学校作业页面已经变化，暂停操作');
  const check = observeSchoolSubmission(target, school, attempt.workScope, now);
  requireThat(check.observedAt > initial.observedAt && check.observedAt >= initial.checkedAt, '正式提交前请重新读取学校当前状态');
  requireThat(check.submissionMode === initial.submissionMode && check.hasSeparateSubmit === initial.hasSeparateSubmit, '学校提交方式发生变化，暂停操作');
  checkExpectedSchoolFiles(check, attempt.file, check.hasSeparateSubmit);
  requireThat(verifyLocalSubmissionFile(attempt.file), '本机最终文件无法读取，或文件 SHA-256／大小与确认不符，暂停操作');
  attempt.finalCheck = { ...check, checkedAt: now };
  return { shouldSubmit: true, submission: task.submission };
}

function receiptEvidence(attempt, status, proof, observation, now) {
  if (status === 'unknown' && observation === undefined) {
    return { text: proof, observedAt: now, screenshotUnavailableReason: '学校页面暂未返回可保存的回执' };
  }
  requireThat(observation && typeof observation === 'object' && !Array.isArray(observation), '请保留同一个作业的学校回读依据');
  const target = attempt.uploadCheck;
  requireThat(observation.courseId === target.courseId && observation.assignmentId === target.assignmentId &&
    observation.moduleId === target.moduleId && observation.url === target.url &&
    observation.submissionMode === target.submissionMode && observation.status === status, '学校回执与目标作业、提交入口或状态不一致');
  if (status === 'submitted') {
    requireThat(attempt.finalCheck, '这次提交缺少正式提交前核对，请先保留所见并报告异常');
  }
  const observedAt = timestamp(observation.observedAt, '学校回执读取时刻');
  const earliest = status === 'submitted' ? attempt.finalCheck.checkedAt : attempt.startedAt;
  requireThat(Date.parse(observedAt) >= Date.parse(earliest) && Date.parse(observedAt) <= Date.parse(now) + 30_000,
    '学校回执读取时刻与本次提交尝试不一致');
  if (['submitted', 'draft'].includes(status) && observation.files !== undefined) {
    const name = attempt.file.path.split(/[\\/]/).at(-1);
    requireThat(Array.isArray(observation.files) && observation.files.length === 1 &&
      observation.files[0]?.name === name && (observation.files[0].bytes == null || observation.files[0].bytes === attempt.file.bytes),
    '学校所示的文件名或大小与本次授权不一致，请先按状态不明留档');
  }
  const { text, schoolTime, schoolTimeText, files, screenshotPath, screenshotUnavailableReason } = observation;
  return { text, observedAt, schoolTime, schoolTimeText, files, screenshotPath, screenshotUnavailableReason };
}

function recordReceipt(state, { taskId, chatId, attemptId, status, evidence, schoolReceipt }, now, runtime) {
  const task = taskFor(state, taskId);
  taskActor(state, task, chatId);
  const attempt = task.submission?.attempt;
  requireThat(attempt && attempt.id === identity(attemptId, '提交尝试 ID'), '回执与这次提交不匹配');
  requireThat(receiptStatuses.includes(status), '无效的学校回执状态');
  const proof = string(evidence, '学校状态依据', 1600);
  if (attempt.receipt?.status === status) return task.submission;
  requireThat(openSubmission(task), '这次提交已有明确结果');
  let archive;
  if (attempt.uploadCheck) {
    const observed = receiptEvidence(attempt, status, proof, schoolReceipt, now);
    requireThat(typeof runtime.archiveReceipt === 'function', '学校回执归档暂不可用，请保留当前页面和尝试编号');
    archive = runtime.archiveReceipt({ task: { ...task, source: attempt.uploadCheck.url }, attempt, status, evidence: proof, schoolReceipt: observed, now });
  }
  attempt.receipt = { status, evidence: proof, at: now, ...(archive ? { archive } : {}) };
  task.submission.phase = status;
  task.status = status === 'submitted' ? 'done' : status === 'draft' ? 'ready' : 'blocked';
  return task.submission;
}

function planRotation(state, { chatId, workPending }, now) {
  if (workPending !== undefined) boolean(workPending, '有待处理工作');
  const chat = activeChat(state, chatId);
  const existing = openRotation(state, chat.id);
  if (existing) return { shouldCreate: false, rotation: existing };
  const check = rotationStatus(state, chat, { now, workPending });
  requireThat(check.canRotate, check.due ? check.blockers.join('，') : '还未达到交接门槛');
  const id = randomUUID();
  const rotation = { id, role: chat.role, oldChatId: chat.id, newChatId: null, phase: 'planned', createdAt: now,
    reason: check.reason, workPending: Boolean(workPending), candidateTitle: `待接班${chat.role === 'main' ? '主聊天' : '副聊天'}｜${id.slice(0, 8)}` };
  state.rotations[id] = rotation;
  return { shouldCreate: true, rotation };
}

function retryRotationCreate(state, { rotationId, verifiedFailureRef }, now) {
  const rotation = rotationFor(state, rotationId);
  requireThat(rotation.phase === 'planned' && !rotation.newChatId, '只有尚未关联接班聊天的交接可重试');
  if (rotation.createRetry) return { shouldCreate: false, rotation };
  const oldChat = activeChat(state, rotation.oldChatId, rotation.role);
  requireThat(rotationStatus(state, oldChat, { now, workPending: rotation.workPending }).canRotate, '旧聊天还未到安全交接点');
  rotation.createRetry = { verifiedFailureRef: string(verifiedFailureRef, '已核实的创建失败记录'), at: now };
  return { shouldCreate: true, rotation };
}

function attachRotation(state, { rotationId, newChatId }, now) {
  const rotation = rotationFor(state, rotationId);
  const id = identity(newChatId, '新聊天 ID');
  if (rotation.newChatId === id) return rotation;
  requireThat(rotation.phase === 'planned' && !state.chats[id], '该交接已经关联聊天，或新聊天已有职责');
  state.chats[id] = chatRecord(id, rotation.role, now, 'standby');
  rotation.newChatId = id;
  rotation.phase = 'attached';
  return rotation;
}

function acknowledgeRotation(state, { rotationId, chatId }, now) {
  const rotation = rotationFor(state, rotationId);
  requireThat(rotation.newChatId === identity(chatId, '新聊天 ID'), '只有这次交接的新聊天可以确认接续');
  if (rotation.acknowledgedAt) return rotation;
  requireThat(rotation.phase === 'attached', '请先关联待接续的新聊天');
  rotation.phase = 'acknowledged';
  rotation.acknowledgedAt = now;
  return rotation;
}

function commitRotation(state, { rotationId }, now) {
  const rotation = rotationFor(state, rotationId);
  if (rotation.committedAt) return rotation;
  requireThat(rotation.phase === 'acknowledged', '新聊天还未确认能够接续');
  const oldChat = activeChat(state, rotation.oldChatId, rotation.role);
  requireThat(rotationStatus(state, oldChat, { now, workPending: rotation.workPending }).canRotate, '旧聊天还未到安全交接点');
  const newChat = chatFor(state, rotation.newChatId);
  requireThat(newChat.status === 'standby', '新聊天状态不能接续');
  if (rotation.role === 'main') state.mainChatId = newChat.id;
  else for (const task of Object.values(state.tasks)) {
    if (unresolvedTask(task) && task.workerId === oldChat.id) task.workerId = newChat.id;
  }
  oldChat.status = 'retiring';
  oldChat.title = policy[rotation.role].oldPrefix + (++state.oldChatCounts[rotation.role]);
  newChat.status = 'active';
  newChat.title = policy[rotation.role].title;
  rotation.phase = 'committed';
  rotation.committedAt = now;
  rotation.oldTitle = oldChat.title;
  rotation.newTitle = newChat.title;
  return rotation;
}

function confirmRotationScheduleCleanup(state, { rotationId, oldChatId }, now) {
  const rotation = rotationFor(state, rotationId);
  requireThat(rotation.committedAt, '新聊天还没有接管');
  requireThat(rotation.oldChatId === identity(oldChatId, '旧聊天 ID'), '旧聊天 ID 与这次交接不一致');
  rotation.scheduleCleanupVerifiedAt ??= now;
  return rotation;
}

function finishRotation(state, { rotationId, actual }, now) {
  const rotation = rotationFor(state, rotationId);
  if (rotation.finishedAt) return rotation;
  requireThat(rotation.phase === 'committed', '新聊天还没有接管');
  requireThat(rotation.scheduleCleanupVerifiedAt, '请先回读确认旧聊天的定时任务已关闭');
  const oldChatPolicy = state.oldChatPolicy.choice ?? 'keep';
  requireThat(actual === oldChatPolicy, '实际旧聊天处理方式与设置不同');
  chatFor(state, rotation.oldChatId).status = 'retired';
  rotation.phase = 'finished';
  rotation.finishedAt = now;
  rotation.cleanup = actual;
  return rotation;
}

export function applyCommand(state, command, input, now = new Date().toISOString(), runtime = {}) {
  requireThat(input && typeof input === 'object' && !Array.isArray(input), '参数必须是 JSON 对象');
  switch (command) {
    case 'register-chat': return registerChat(state, input, now);
    case 'observe-rounds': return observeRounds(state, input);
    case 'add-task': return addTask(state, input);
    case 'assign-task': return assignTask(state, input);
    case 'update-task': return updateTask(state, input);
    case 'release-task': return releaseTask(state, input);
    case 'approve-submission': return approveSubmission(state, input, now);
    case 'start-submission': return startSubmission(state, input, now);
    case 'authorize-submit': return authorizeSubmit(state, input, now);
    case 'record-receipt': return recordReceipt(state, input, now, runtime);
    case 'plan-rotation': return planRotation(state, input, now);
    case 'retry-rotation-create': return retryRotationCreate(state, input, now);
    case 'attach-rotation': return attachRotation(state, input, now);
    case 'acknowledge-rotation': return acknowledgeRotation(state, input, now);
    case 'commit-rotation': return commitRotation(state, input, now);
    case 'confirm-rotation-schedule-cleanup': return confirmRotationScheduleCleanup(state, input, now);
    case 'finish-rotation': return finishRotation(state, input, now);
    case 'request-old-chat-policy': {
      const shouldAsk = !state.oldChatPolicy.asked &&
        Object.values(state.rotations).some(rotation => rotation.committedAt);
      if (shouldAsk) state.oldChatPolicy.asked = true;
      return { shouldAsk, policy: state.oldChatPolicy.choice };
    }
    case 'set-old-chat-policy': {
      requireThat(['archive', 'keep'].includes(input.policy), '保留方式必须为 archive 或 keep');
      state.oldChatPolicy = { asked: true, choice: input.policy };
      return state.oldChatPolicy;
    }
    default: throw new LedgerError(`未知操作：${command}`);
  }
}
