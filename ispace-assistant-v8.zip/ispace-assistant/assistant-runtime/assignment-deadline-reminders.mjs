import { createHash } from 'node:crypto';
import { lstatSync, readFileSync } from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { defaultAssignmentLeadHours, readAssistantPreferences } from './setup-preferences.mjs';

const journalPath = fileURLToPath(new URL('../.assignment-deadline-reminders.sqlite', import.meta.url));
const minuteMs = 60_000;
const maxLeadMinutes = 30 * 24 * 60;
const retentionMs = 30 * 24 * 60 * minuteMs;
const sendLeaseMs = 5 * minuteMs;
const assignmentId = /^assignment:[1-9]\d{0,14}$/u;
const noticeId = /^assignment-due-[a-f0-9]{32}$/u;
const unfinished = new Set(['not_submitted', 'draft', 'reopened']);

function configuredLeads(preferences) {
  if (preferences.reminders?.assignments === 'off' || preferences.permissions?.readSchool === 'ask' ||
      preferences.permissions?.backgroundReminders === 'ask') return [];
  const leads = preferences.reminders?.assignmentLeadMinutes;
  if (leads === undefined) return [defaultAssignmentLeadHours * 60];
  if (!Array.isArray(leads) ||
      leads.some(minute => !Number.isSafeInteger(minute) || minute < 1 || minute > maxLeadMinutes)) return [];
  return [...new Set(leads)].sort((first, second) => first - second);
}

function schoolTime(seconds) {
  return Number.isSafeInteger(seconds) && seconds > 0 && seconds < 8e12 ? seconds * 1000 : null;
}

function oneLine(value, maxLength) {
  return typeof value === 'string' ? value.replace(/\s+/gu, ' ').trim().slice(0, maxLength) : '';
}

function deadlineCandidates(snapshot, preferences, nowMs) {
  const leads = configuredLeads(preferences);
  if (!leads.length || snapshot?.verified !== true || snapshot.freshness !== 'fresh') return [];
  if (!Number.isFinite(Date.parse(snapshot.verifiedAt)) || !Array.isArray(snapshot.courses) ||
      !Array.isArray(snapshot.items)) throw new TypeError('作业巡检缺少已核验的课程清单');

  const trackedCodes = Array.isArray(preferences.courses) ? new Set(preferences.courses) : null;
  const allowedCourses = new Map();
  for (const course of snapshot.courses) {
    if (!course || !Number.isSafeInteger(course.id) || course.id < 1) continue;
    const code = oneLine(course.code, 80);
    if (code && (!trackedCodes || trackedCodes.has(code))) allowedCourses.set(course.id, code);
  }

  const candidates = [];
  const seen = new Set();
  for (const item of snapshot.items) {
    if (!item || !allowedCourses.has(item.courseId) || typeof item.id !== 'string' || !assignmentId.test(item.id) ||
        (item.kind !== undefined && item.kind !== 'assignment')) continue;
    const target = `${item.courseId}:${item.id}`;
    if (seen.has(target)) throw new TypeError('作业巡检清单有重复项目');
    seen.add(target);
    if (!unfinished.has(item.learningState?.submission) || item.learningState.completion === 'complete') continue;

    // Prefer the official personal extension. Course text and date-only labels do not supply an exact due time.
    const dueMs = schoolTime(item.rawSubmission?.attempt?.extensionduedate) ?? schoolTime(item.rawDates?.duedate);
    const leadMinutes = dueMs !== null && dueMs > nowMs ? leads.find(lead => dueMs - nowMs <= lead * minuteMs) : undefined;
    const title = oneLine(item.title, 240);
    if (leadMinutes === undefined || !title) continue;
    const dueAt = new Date(dueMs).toISOString();
    const id = 'assignment-due-' + createHash('sha256').update(`${target}|${dueAt}|${leadMinutes}`).digest('hex').slice(0, 32);
    candidates.push({ id, courseId: item.courseId, itemId: item.id, courseCode: allowedCourses.get(item.courseId), title, dueAt, leadMinutes });
  }
  return candidates.sort((first, second) => first.dueAt.localeCompare(second.dueAt) || first.id.localeCompare(second.id));
}

function existsAsPlainFile(path) {
  try {
    const info = lstatSync(path);
    if (!info.isFile() || info.isSymbolicLink() || info.nlink !== 1) throw new Error('作业提醒记录必须是独立文件');
    return true;
  } catch (error) {
    if (error.code === 'ENOENT') return false;
    throw error;
  }
}

function withJournal(path, action) {
  const db = new DatabaseSync(path);
  try {
    db.exec(`PRAGMA busy_timeout = 6000; BEGIN IMMEDIATE;
      CREATE TABLE IF NOT EXISTS assignment_deadline_notices (
        id TEXT PRIMARY KEY NOT NULL,
        due_ms INTEGER NOT NULL,
        lease_until_ms INTEGER NOT NULL,
        sent_at_ms INTEGER
      ) STRICT`);
    const result = action(db);
    db.exec('COMMIT');
    return result;
  } finally {
    db.close();
  }
}

export function observeAssignmentDeadlines({ path = journalPath, snapshot, preferences = {}, now = new Date() }) {
  const nowMs = now.getTime();
  const candidates = deadlineCandidates(snapshot, preferences, nowMs);
  if (!candidates.length) return { alerts: [] };
  existsAsPlainFile(path);
  return withJournal(path, db => {
    db.prepare('DELETE FROM assignment_deadline_notices WHERE due_ms < ?').run(nowMs - retentionMs);
    const lease = db.prepare(`INSERT INTO assignment_deadline_notices (id, due_ms, lease_until_ms) VALUES (?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET lease_until_ms = excluded.lease_until_ms
      WHERE sent_at_ms IS NULL AND lease_until_ms <= ?`);
    const alerts = candidates.filter(item => {
      const dueMs = Date.parse(item.dueAt);
      return lease.run(item.id, dueMs, Math.min(dueMs, nowMs + sendLeaseMs), nowMs).changes > 0;
    });
    return { alerts };
  });
}

export function confirmAssignmentDeadline({ path = journalPath, id, now = new Date() }) {
  if (typeof id !== 'string' || !noticeId.test(id) || !existsAsPlainFile(path)) throw new Error('找不到该作业截止提醒');
  return withJournal(path, db => {
    const statement = db.prepare('UPDATE assignment_deadline_notices SET sent_at_ms = COALESCE(sent_at_ms, ?) WHERE id = ?');
    if (statement.run(now.getTime(), id).changes === 0) throw new Error('找不到该作业截止提醒');
    return { id, confirmed: true };
  });
}

async function execute([command, arg, ...extra]) {
  if (command === 'observe' && arg === '--stdin' && !extra.length) {
    const preferences = await readAssistantPreferences();
    const snapshot = JSON.parse(readFileSync(0, 'utf8'));
    return observeAssignmentDeadlines({ preferences, snapshot });
  }
  if (command === 'confirm' && arg && !extra.length) return confirmAssignmentDeadline({ id: arg });
  throw new Error('用法：assignment-deadline-reminders.mjs observe --stdin 或 confirm 提醒编号');
}

if (process.argv[1] && pathToFileURL(process.argv[1]).href === import.meta.url) {
  try {
    console.log(JSON.stringify(await execute(process.argv.slice(2))));
  } catch (error) {
    console.error(JSON.stringify({ error: error.message }));
    process.exitCode = 1;
  }
}
