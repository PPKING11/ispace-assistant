import { randomBytes } from 'node:crypto';
import { lstat, readFile, rename, unlink, writeFile } from 'node:fs/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { normalizeSchedule, unionRrule } from './setup-schedule.mjs';

const profiles = new URL('../', import.meta.url);
const identityName = '本人资料.json';
const preferencesName = '助手设置.json';
const pendingName = '首次设置待应用.json';
const reasoningEfforts = new Set(['none', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max', 'ultra']);
export const recommendedBackgroundModel = 'gpt-6.2-sol';
export const defaultAssignmentLeadHours = 12;

function file(name, project) {
  return fileURLToPath(new URL(name, project));
}

async function readLocalJson(path) {
  try {
    const stat = await lstat(path);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.size > 65536) throw new Error('本机配置格式异常');
    return JSON.parse(await readFile(path, 'utf8'));
  } catch (error) {
    if (error.code === 'ENOENT') return {};
    throw error;
  }
}

async function atomicJson(path, data) {
  const stage = path + '.setup-' + randomBytes(12).toString('hex') + '.tmp';
  try {
    await writeFile(stage, JSON.stringify(data, null, 2) + '\n', { flag: 'wx', encoding: 'utf8', mode: 0o600 });
    await rename(stage, path);
  } finally {
    await unlink(stage).catch(() => {});
  }
}

function mergeChoices(existing, requested) {
  return { ...existing, ...Object.fromEntries(Object.entries(requested).filter(([, value]) => value !== 'inherit')) };
}

function applyModelChoices(existing, requested) {
  const models = { ...existing };
  for (const [role, choice] of Object.entries(requested)) {
    if (choice === 'system') delete models[role];
    else if (choice !== undefined && choice !== 'inherit') models[role] = choice;
  }
  return models;
}

function backgroundModelTarget(choice) {
  if (!choice || choice === 'inherit') return null;
  return choice === 'system' ? recommendedBackgroundModel : choice;
}

function modelEffort(value) {
  if (value === undefined || value === 'inherit') return null;
  if (!reasoningEfforts.has(value)) throw new Error('助手模型的推理强度无效');
  return value;
}

export async function readAssistantPreferences(project = profiles) {
  return await readLocalJson(file(preferencesName, project));
}

// The browser passes a validated form. External changes stay in the submitted request for independent readback.
export async function applyLocalSetup(request, project = profiles) {
  if (request.schemaVersion !== 2) throw new Error('本机设置版本不匹配');
  const { identity, settings, createdAt } = request;
  const current = await readAssistantPreferences(project);
  const archive = settings.archive;
  if (archive.downloadMode !== undefined && !['off', 'manual', 'auto'].includes(archive.downloadMode)) {
    throw new Error('课程文件下载方式无效');
  }
  const courseDownloadMode = archive.downloadMode ?? current.courseDownloadMode;
  const activeSchedule = normalizeSchedule(current.schedule);
  const requestedSchedule = { ...activeSchedule, ...normalizeSchedule(settings.schedule) };
  const requestedRrule = unionRrule(requestedSchedule).rrule;
  const needsSchedule = unionRrule(activeSchedule).rrule !== requestedRrule;
  const requestedEfforts = settings.modelEfforts ?? {};
  const backgroundModel = backgroundModelTarget(settings.models.background);
  const backgroundEffort = modelEffort(requestedEfforts.background);
  if (backgroundEffort !== null && backgroundModel === null) throw new Error('缺少推理强度对应的后台模型');
  const needsBackgroundModel = backgroundModel !== null && (
    backgroundModel !== current.models?.background || settings.models.background === 'system' ||
    (backgroundEffort !== null && backgroundEffort !== current.modelEfforts?.background)
  );
  const modelEfforts = { ...current.modelEfforts };
  for (const role of ['main', 'worker']) {
    const effort = modelEffort(requestedEfforts[role]);
    if (effort !== null) modelEfforts[role] = effort;
    else if (settings.models[role] === 'system') delete modelEfforts[role];
  }
  const preferences = {
    schemaVersion: 1,
    updatedAt: createdAt,
    courses: settings.courses ?? current.courses ?? null,
    reminders: mergeChoices(current.reminders, settings.reminders),
    permissions: mergeChoices(current.permissions, settings.permissions),
    ...(courseDownloadMode === undefined ? {} : { courseDownloadMode }),
    attendance: settings.attendance === 'inherit' ? current.attendance ?? 'inherit' : settings.attendance,
    oldChatPolicy: settings.oldChatPolicy === 'inherit' ? current.oldChatPolicy ?? null : settings.oldChatPolicy,
    models: applyModelChoices(current.models, { main: settings.models.main, worker: settings.models.worker }),
    ...(Object.keys(modelEfforts).length > 0 && { modelEfforts }),
    schedule: needsSchedule ? activeSchedule : requestedSchedule,
  };
  if (identity) {
    const path = file(identityName, project);
    await readLocalJson(path);
    await atomicJson(path, identity);
  }
  await atomicJson(file(preferencesName, project), preferences);
  return {
    identity: Boolean(identity),
    needsArchive: archive.directoryChoice !== 'inherit' || archive.year !== null || archive.semester !== null ||
      archive.autoDownload !== 'inherit' || archive.autoScheduleChanged === true,
    needsAttendance: settings.attendance !== 'inherit',
    needsOldChatPolicy: settings.oldChatPolicy !== 'inherit',
    needsBackgroundModel,
    needsSchedule,
    pendingBackgroundModel: needsBackgroundModel ? backgroundModel : null,
    pendingBackgroundEffort: needsBackgroundModel ? backgroundEffort : null,
    pendingAutomationRrule: needsSchedule ? requestedRrule : null,
  };
}

export async function keepComponentChanges(path, request, application) {
  const pending = Object.entries(application).filter(([key, needed]) => key.startsWith('needs') && needed);
  if (pending.length === 0) await unlink(path);
  else await atomicJson(path, {
    ...request, identity: null, localPreferencesApplied: true,
    pendingAutomationRrule: application.pendingAutomationRrule ?? null,
    pendingBackgroundModel: application.pendingBackgroundModel ?? null,
    pendingBackgroundEffort: application.pendingBackgroundEffort ?? null,
  });
  return pending.length > 0;
}

export async function activateSetupSchedule(verifiedRrule, project = profiles) {
  const path = file(pendingName, project);
  const pending = await readLocalJson(path);
  if (!verifiedRrule || !pending.localPreferencesApplied || verifiedRrule !== pending.pendingAutomationRrule) {
    throw new Error('后台任务回读的时间与待应用设置不一致');
  }
  const current = await readAssistantPreferences(project);
  const schedule = { ...normalizeSchedule(current.schedule), ...normalizeSchedule(pending.settings.schedule) };
  if (unionRrule(schedule).rrule !== verifiedRrule) throw new Error('后台任务回读的时间与待应用设置不一致');
  await atomicJson(file(preferencesName, project), { ...current, schedule });
  await atomicJson(path, { ...pending, pendingAutomationRrule: null });
  return { applied: true };
}

export async function activateBackgroundModel(verifiedModel, project = profiles, verifiedEffort) {
  const path = file(pendingName, project);
  const pending = await readLocalJson(path);
  const selected = pending.settings?.models?.background;
  const target = backgroundModelTarget(selected);
  const targetEffort = modelEffort(pending.settings?.modelEfforts?.background);
  if (!pending.localPreferencesApplied || !target || verifiedModel !== target ||
      (Object.hasOwn(pending, 'pendingBackgroundModel') && pending.pendingBackgroundModel !== target)) {
    throw new Error('后台任务回读的模型与待应用设置不一致');
  }
  if ((targetEffort !== null && verifiedEffort !== targetEffort) ||
      (Object.hasOwn(pending, 'pendingBackgroundEffort') && pending.pendingBackgroundEffort !== targetEffort)) {
    throw new Error('后台任务回读的推理强度与待应用设置不一致');
  }
  const current = await readAssistantPreferences(project);
  const models = applyModelChoices(current.models, { background: selected });
  const effort = modelEffort(verifiedEffort);
  const modelEfforts = effort === null ? current.modelEfforts : { ...current.modelEfforts, background: effort };
  await atomicJson(file(preferencesName, project), { ...current, models, modelEfforts });
  await atomicJson(path, { ...pending, pendingBackgroundModel: null, pendingBackgroundEffort: null });
  return { applied: true };
}

if (process.argv[1] && pathToFileURL(process.argv[1]).href === import.meta.url) {
  try {
    const [command, verifiedValue, verifiedEffort, ...extra] = process.argv.slice(2);
    if (!verifiedValue || extra.length || (command === 'activate-schedule' && verifiedEffort !== undefined)) {
      throw new Error('缺少已核对的后台任务设置');
    }
    if (command === 'activate-schedule') console.log(JSON.stringify(await activateSetupSchedule(verifiedValue)));
    else if (command === 'activate-background-model') {
      console.log(JSON.stringify(await activateBackgroundModel(verifiedValue, profiles, verifiedEffort)));
    }
    else throw new Error('不支持的首次设置操作');
  } catch (error) {
    console.error(JSON.stringify({ error: error.message }));
    process.exitCode = 1;
  }
}

