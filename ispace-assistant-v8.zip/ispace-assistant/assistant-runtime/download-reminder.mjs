import { randomUUID } from 'node:crypto';
import { existsSync, lstatSync, readFileSync, realpathSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { basename, dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

const projectRoot = realpathSync(fileURLToPath(new URL('../', import.meta.url)));
const statePath = join(projectRoot, 'download-reminder-state.json');
const previewPath = /^(?:assistant-runtime[/\\])?download-reminder-[a-z0-9][a-z0-9._-]*\.json$/i;
const statuses = ['downloaded', 'not_downloaded', 'skipped', 'failed'];
const noticeId = /^download-\d{4}-\d{2}-\d{2}-\d+$/;
const maxChatLength = 6500;
const checkKey = 'check';
const fileKey = id => `file:${id}`;

export function emptyReminderState() {
  return { version: 1, lastCheckId: null, lastCompleteCheckId: null, complete: false, checkReason: null,
    files: {}, courseIds: null, unreportedChanges: {}, reported: {}, initialConfirmed: false,
    lastSummaryCheckId: null, lastSummaryComplete: false, nextNumber: 1, confirmed: [], pending: null };
}

function shortText(value, maximum) {
  if (typeof value !== 'string') return null;
  const text = value.replace(/\s+/gu, ' ').trim();
  return text && text.length <= maximum ? text : null;
}

function dailyId(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error('检查日期必须是北京时间的 YYYY-MM-DD');
  const date = new Date(value);
  if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value) throw new Error('无效的检查日期');
  return value;
}

function parseReport(report) {
  if (!report || typeof report.complete !== 'boolean') throw new Error('报告缺少完整性状态');
  const checkId = dailyId(report.checkId);
  if (!report.complete) return { checkId, complete: false, reason: shortText(report.reason, 300) || 'not_verified' };
  if (!Array.isArray(report.files) || report.files.length > 3000) throw new Error('已核验的报告需要文件列表');
  const courseIds = report.courseIds ?? null;
  if (courseIds !== null && (!Array.isArray(courseIds) || courseIds.some(id => !Number.isSafeInteger(id) || id <= 0) ||
      new Set(courseIds).size !== courseIds.length)) throw new Error('文件列表的课程范围无效');
  const scope = courseIds && new Set(courseIds);
  const files = new Map();
  for (const file of report.files) {
    const id = typeof file?.id === 'string' && file.id.length <= 700 && file.id.trim() && !/[\u0000-\u001f\u007f]/u.test(file.id) ? file.id : null;
    const filename = shortText(file?.filename, 400);
    if (!id || !filename || !statuses.includes(file.status) || files.has(fileKey(id))) throw new Error('文件状态、名称或唯一编号无效');
    const courseId = file.courseId ?? null;
    if (scope && !scope.has(courseId)) throw new Error('文件所属课程超出已核验的范围');
    const sourceId = /^[a-f0-9]{64}$/.test(file.sourceId ?? '') ? file.sourceId : null;
    files.set(fileKey(id), { id, filename, courseId, sourceId, course: shortText(file.course, 160),
      status: file.status, reason: shortText(file.reason, 300) });
  }
  return { checkId, complete: true, files, courseIds };
}

function fileIssue(file) {
  if (file.status === 'downloaded' || (file.status === 'not_downloaded' && file.checks < 2)) return null;
  return { id: file.id, filename: file.filename, course: file.course, status: file.status,
    reason: file.reason };
}

function pendingChanges(state) {
  const issues = [];
  const recovered = [];
  if (!state.complete) {
    const current = { id: checkKey, filename: null, course: null, status: 'unverified', reason: state.checkReason };
    if (state.reported[checkKey]?.reason !== current.reason) issues.push({ key: checkKey, ...current });
    return { issues, recovered };
  }
  if (state.reported[checkKey]) recovered.push({ key: checkKey, status: 'check_recovered' });
  const keys = [...new Set([...Object.keys(state.files), ...Object.keys(state.reported)])].filter(key => key !== checkKey).sort();
  for (const key of keys) {
    const file = state.files[key];
    const reported = state.reported[key];
    const current = file && fileIssue(file);
    if (current) {
      if (JSON.stringify(current) !== JSON.stringify(reported)) issues.push({ key, ...current });
    } else if (reported) {
      if (file?.status === 'downloaded') recovered.push({ key, id: file.id, filename: file.filename, course: file.course, status: 'downloaded' });
      else delete state.reported[key];
    }
  }
  return { issues, recovered };
}

const reasonLabels = {
  not_verified: '目前拿不到可核实的本机下载状态',
  too_large: '超过下载上限',
  unsupported: '文件格式暂不支持',
  unsupported_format: '文件格式暂不支持',
  size_mismatch: '本地文件大小与清单不符',
  missing: '尚未找到本地文件',
  file_missing: '尚未找到本地文件',
};

function reasonLabel(reason) {
  if (!reason) return '';
  if (Object.hasOwn(reasonLabels, reason)) return reasonLabels[reason];
  return /[\u3400-\u9fff]/u.test(reason) ? reason : '原因待核对';
}

function appendFileNames(lines, label, files) {
  if (!files.length) return;
  const heading = `${label} ${files.length} 份`;
  const entries = files.map(file => `${file.course ? file.course + ' · ' : ''}${file.filename}${file.reason ? '（' + reasonLabel(file.reason) + '）' : ''}`);
  if (entries.length === 1) lines.push(`${heading}：${entries[0]}。`);
  else lines.push(`${heading}：`, '', ...entries.map(entry => `- ${entry}`), '');
}

function sortedFiles(files) {
  return files.sort((a, b) => (a.course || '').localeCompare(b.course || '') || a.filename.localeCompare(b.filename));
}

function messageFor(notification, outstanding) {
  const lines = [`【ispace助手后台汇报】${notification.checkId} 课程文件日报（${notification.id}）`];
  const counts = notification.counts;
  if (notification.initial) {
    lines.push('首次核对已建立对照清单。之后会列出自上次有效核对以来新增或更新的文件。');
  }
  if (notification.summary && notification.complete) {
    lines.push(`共 ${counts.total} 份，已下载 ${counts.downloaded} 份，待下载 ${counts.not_downloaded} 份，已跳过 ${counts.skipped} 份，失败 ${counts.failed} 份。`);
  }
  const additions = sortedFiles(notification.changes.filter(file => file.change === 'added'));
  const revisions = sortedFiles(notification.changes.filter(file => file.change === 'updated'));
  if (!notification.initial && notification.summary && notification.complete && !additions.length) {
    lines.push('自上次有效核对以来未发现新增文件。');
  }
  appendFileNames(lines, '自上次有效核对以来新增', additions);
  appendFileNames(lines, '发现新版本', revisions);
  const unverified = notification.issues.find(file => file.status === 'unverified');
  if (!notification.complete) lines.push(`这次无法核实新增和下载情况，${reasonLabel(unverified?.reason ?? notification.reason)}。`);
  appendFileNames(lines, '下载失败', outstanding.filter(file => file.status === 'failed'));
  appendFileNames(lines, '已跳过', outstanding.filter(file => file.status === 'skipped'));
  appendFileNames(lines, '连续两次或以上检查仍未下载', outstanding.filter(file => file.status === 'not_downloaded' && file.checks >= 2));
  appendFileNames(lines, '待下载，本次未在归档中找到', outstanding.filter(file => file.status === 'not_downloaded' && file.checks < 2));
  if (notification.recovered.some(item => item.status === 'check_recovered')) lines.push('本机下载状态已恢复核对。');
  const downloaded = sortedFiles(notification.recovered.filter(item => item.status === 'downloaded'));
  appendFileNames(lines, '已补下载', downloaded);
  return lines.join('\n').trimEnd();
}

function ensurePending(state) {
  if (state.pending || !state.lastCheckId) return;
  const initial = state.complete && !state.initialConfirmed;
  const summary = state.lastCheckId !== state.lastSummaryCheckId || (state.complete && !state.lastSummaryComplete);
  const { issues, recovered } = pendingChanges(state);
  const changes = state.complete ? Object.values(state.unreportedChanges ?? {}) : [];
  if (!summary && !initial && !issues.length && !recovered.length && !changes.length) return;
  const counts = { total: 0, downloaded: 0, not_downloaded: 0, skipped: 0, failed: 0 };
  let outstanding = [];
  if (state.complete) {
    for (const file of Object.values(state.files)) counts[file.status] += 1;
    counts.total = Object.keys(state.files).length;
    outstanding = summary
      ? Object.values(state.files).filter(file => file.status !== 'downloaded')
      : issues.map(issue => state.files[issue.key]).filter(Boolean);
  }
  const notification = { id: `download-${state.lastCheckId}-${state.nextNumber++}`, checkId: state.lastCheckId,
    initial, summary, complete: state.complete, reason: state.checkReason, counts, issues, recovered, changes };
  state.pending = { ...notification, message: messageFor(notification, sortedFiles(outstanding)) };
}

export function envelope(state) {
  return { lastCheckId: state.lastCheckId, lastCompleteCheckId: state.lastCompleteCheckId,
    lastSummaryCheckId: state.lastSummaryCheckId ?? null, lastSummaryComplete: state.lastSummaryComplete ?? false,
    lastConfirmedId: state.confirmed.at(-1) ?? null, pending: state.pending };
}

export function observeReport(state, value) {
  const report = parseReport(value);
  if (state.lastCheckId && report.checkId < state.lastCheckId) throw new Error('这份报告早于已记录的检查');
  state.lastCheckId = report.checkId;
  state.complete = report.complete;
  state.checkReason = report.complete ? null : report.reason;
  if (report.complete) {
    const previousFiles = Object.values(state.files);
    const previousSourceIds = new Set(previousFiles.map(file => file.sourceId).filter(Boolean));
    const legacyNames = new Set(previousFiles.filter(file => !file.sourceId)
      .map(file => JSON.stringify([file.course, file.filename])));
    const previousCourseIds = state.courseIds && new Set(state.courseIds);
    state.unreportedChanges ??= {};
    const next = [];
    for (const [key, file] of report.files) {
      const previous = state.files[key];
      const inComparisonScope = !previousCourseIds || file.courseId === null || previousCourseIds.has(file.courseId);
      if (state.lastCompleteCheckId && !previous && inComparisonScope && !Object.hasOwn(state.unreportedChanges, key)) {
        const sameSource = previousSourceIds.has(file.sourceId) ||
          legacyNames.has(JSON.stringify([file.course, file.filename]));
        const change = sameSource ? 'updated' : 'added';
        state.unreportedChanges[key] = { key, filename: file.filename, course: file.course, change };
      }
      let checks = file.status === 'not_downloaded' ? 1 : 0;
      if (checks && previous?.status === 'not_downloaded') {
        checks = previous.checks + Number(previous.checkId !== report.checkId);
      }
      next.push([key, { ...file, checks, checkId: report.checkId }]);
    }
    state.files = Object.fromEntries(next);
    state.courseIds = report.courseIds;
    state.lastCompleteCheckId = report.checkId;
  }
  ensurePending(state);
  return envelope(state);
}

export function confirmNotice(state, id) {
  if (typeof id !== 'string' || !noticeId.test(id)) throw new Error('无效的提醒编号');
  if (state.confirmed.includes(id)) return envelope(state);
  const notification = state.pending;
  if (notification?.id !== id) throw new Error('编号没有对应待确认的提醒');
  for (const { key, ...issue } of notification.issues) state.reported[key] = issue;
  for (const { key } of notification.recovered) delete state.reported[key];
  for (const { key } of notification.changes ?? []) delete state.unreportedChanges[key];
  if (notification.initial) state.initialConfirmed = true;
  if (notification.summary) {
    state.lastSummaryCheckId = notification.checkId;
    state.lastSummaryComplete = notification.complete;
  }
  state.confirmed = [...state.confirmed.slice(-31), id];
  state.pending = null;
  ensurePending(state);
  return envelope(state);
}

function safeFile(path) {
  try {
    const info = lstatSync(path);
    if (!info.isFile() || info.isSymbolicLink() || info.nlink > 1) throw new Error('提醒记录必须是独立普通文件');
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
}

function load(path) {
  safeFile(path);
  try {
    const state = JSON.parse(readFileSync(path, 'utf8'));
    if (state.version !== 1 || !state.files || !state.reported || !Array.isArray(state.confirmed)) throw new Error('提醒记录格式不匹配');
    return state;
  } catch (error) {
    if (error.code === 'ENOENT') return emptyReminderState();
    throw error;
  }
}

export function withReminderLock(path, action) {
  const lockPath = `${path}.lock.sqlite`;
  safeFile(lockPath);
  const lock = new DatabaseSync(lockPath);
  try {
    lock.exec('PRAGMA busy_timeout = 6000; BEGIN IMMEDIATE');
    const state = load(path);
    const previous = JSON.stringify(state);
    const result = action(state);
    if (previous !== JSON.stringify(state)) {
      const temporary = `${path}.${randomUUID()}.tmp`;
      try {
        writeFileSync(temporary, JSON.stringify(state, null, 2) + '\n', { encoding: 'utf8', flag: 'wx', flush: true });
        renameSync(temporary, path);
      } finally {
        if (existsSync(temporary)) rmSync(temporary);
      }
    }
    lock.exec('COMMIT');
    return result;
  } finally {
    lock.close();
  }
}

function selectedState(value) {
  if (!previewPath.test(value ?? '')) throw new Error('请选项目内的 download-reminder-*.json 预览记录');
  const path = resolve(projectRoot, value);
  const parent = realpathSync(dirname(path));
  if (parent !== projectRoot && parent !== join(projectRoot, 'assistant-runtime')) throw new Error('提醒记录位置超出项目');
  return join(parent, basename(path));
}

function deliveryResult(result, stateFile) {
  const pending = result.pending;
  if (!pending || (pending.message.length <= maxChatLength && JSON.stringify(pending).length <= 17000)) return result;
  if (!noticeId.test(pending.id)) throw new Error('待发日报的编号无效');
  const path = join(dirname(stateFile), `${pending.id}.txt`);
  const content = pending.message + '\n';
  safeFile(path);
  if (existsSync(path)) {
    if (readFileSync(path, 'utf8') !== content) throw new Error('完整日报文件已被另一个文件占用');
  } else {
    const temporary = `${path}.${randomUUID()}.tmp`;
    try {
      writeFileSync(temporary, content, { encoding: 'utf8', flag: 'wx', flush: true });
      renameSync(temporary, path);
    } finally {
      if (existsSync(temporary)) rmSync(temporary);
    }
  }
  const { id, checkId, initial, summary, complete, counts } = pending;
  const headings = pending.message.split('\n').filter(line => line && !line.startsWith('- '));
  const reportLink = `[打开完整文件名单](<${path.replace(/\\/g, '/')}>)`;
  return { ...result, pending: { id, checkId, initial, summary, complete, counts, reportFile: path,
    message: [...headings, '', reportLink].join('\n') } };
}

function execute(args) {
  const flag = args.indexOf('--state');
  if (flag !== -1 && flag !== args.length - 2) throw new Error('--state 必须是最后一个选项');
  const destination = flag === -1 ? statePath : selectedState(args[flag + 1]);
  const [operation, input, ...extra] = flag === -1 ? args : args.slice(0, flag);
  if (extra.length) throw new Error('多余的参数');
  if ((operation === 'pending' || operation === 'status') && !input) return deliveryResult(envelope(load(destination)), destination);
  if (operation === 'observe' && input) {
    const value = JSON.parse(input === '--stdin' ? readFileSync(0, 'utf8').replace(/^\ufeff/, '') : input);
    return deliveryResult(withReminderLock(destination, state => observeReport(state, value)), destination);
  }
  if (operation === 'confirm' && input) return deliveryResult(withReminderLock(destination, state => confirmNotice(state, input)), destination);
  throw new Error('用法：download-reminder.mjs pending | observe --stdin | confirm 提醒编号 [--state 相对预览路径]');
}

if (process.argv[1] && pathToFileURL(process.argv[1]).href === import.meta.url) {
  try {
    console.log(JSON.stringify(execute(process.argv.slice(2)), null, 2));
  } catch (error) {
    console.error(JSON.stringify({ error: error instanceof SyntaxError ? '无法读取 JSON 报告' : error.message }));
    process.exitCode = 1;
  }
}
