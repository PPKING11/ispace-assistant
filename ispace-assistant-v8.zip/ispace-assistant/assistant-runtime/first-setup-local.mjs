import { createServer } from 'node:http';
import { randomBytes } from 'node:crypto';
import { lstatSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { applyLocalSetup, defaultAssignmentLeadHours, keepComponentChanges, readAssistantPreferences } from './setup-preferences.mjs';
import { inferArchiveTerm } from './setup-onboarding.mjs';
import { describeSetupComponent } from './setup-components.mjs';
import { loadSetupCopy } from './setup-copy.mjs';
import { atomicWrite, withLedgerLock } from './assistant.mjs';

const destination = fileURLToPath(new URL('../首次设置待应用.json', import.meta.url));
const formPath = '/' + randomBytes(24).toString('hex');
const copyPath = formPath + '/copy';
const scriptNonce = randomBytes(20).toString('base64');

function startContext() {
  const args = process.argv.slice(2);
  if (args.length === 0) return {};
  if (args.length !== 2 || args[0] !== '--context-base64' ||
      args[1].length > 40000 || !/^[a-zA-Z0-9_-]+$/.test(args[1])) {
    throw new Error('首次设置启动参数异常。');
  }
  const data = JSON.parse(Buffer.from(args[1], 'base64url').toString('utf8'));
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('首次设置启动信息异常。');
  return data;
}

const context = startContext();
const copyEditingEnabled = context.enableCopyEditing === true;
const preferences = await readAssistantPreferences().catch(() => ({}));
const setupCopy = await loadSetupCopy();
const connected = describeSetupComponent(context, 'privateSite').state === 'ready';
const courses = connected && Array.isArray(context.courses)
  ? [...new Set(context.courses.filter(code => typeof code === 'string' && /^[\w][\w. -]{0,47}$/u.test(code)))].slice(0, 100)
  : [];
const termOptions = { today: context.today, currentAcademicTerm: context.currentAcademicTerm };
const chromeDownloadKnown = typeof context.autoDownloadEnabled === 'boolean';
const initialLocalDownloads = chromeDownloadKnown ? context.autoDownloadEnabled : preferences.courseDownloadMode !== 'off';
const downloadInterval = boundedInteger(context.autoIntervalMinutes, 5, 1440) ?? 15;
const downloadDailyLimit = boundedInteger(context.autoDailyLimit, 0, 288) ?? 0;
const switchFields = new Set(['localDownloads', 'assignments']);
const limits = new Map([
  ['name', 100], ['studentId', 64], ['localDownloads', 1], ['assignments', 1], ['autoIntervalMinutes', 4],
]);

const css = `
  :root{color-scheme:light;--ink:#202a28;--muted:#586460;--line:#dce3df;--wash:#f5f7f6;--green:#1c604f}
  *{box-sizing:border-box}
  [hidden]{display:none!important}
  html{background:var(--wash)}
  body{margin:0;color:var(--ink);font:15px/1.55 "Microsoft YaHei UI","PingFang SC",system-ui,sans-serif}
  main{max-width:840px;margin:0 auto;padding:32px 24px}
  header{margin:0 0 18px}
  .page-head{display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px 16px}
  .page-head h1{min-width:0;overflow-wrap:anywhere}
  .copy-text{min-width:0;overflow-wrap:anywhere}
${copyEditingEnabled ? `  .copy-actions,.copy-dialog-buttons{display:flex;align-items:center;flex-wrap:wrap;gap:8px}
  .copy-status:empty{display:none}
  .copy-editing [data-copy-key],.copy-editing [data-copy-target]{outline:1px dashed #94b8a8;outline-offset:2px;cursor:pointer;overflow-wrap:anywhere}
  .copy-editing [data-copy-key]:is(:hover,:focus-visible),.copy-editing [data-copy-target]:is(:hover,:focus-visible){outline:2px solid #237d66}
  .copy-editing .hint:is(:hover,:focus-within) .tip{visibility:hidden}
  .copy-dialog{width:min(430px,calc(100% - 28px));border:1px solid var(--line);border-radius:14px;padding:22px;font:inherit;color:var(--ink)}
  .copy-dialog::backdrop{background:rgba(32,42,40,.38)}
  .copy-dialog form{border:0}
  .copy-dialog textarea{display:block;width:100%;min-height:90px;margin:10px 0 14px;padding:9px;border:1px solid #b9c5bf;border-radius:7px;resize:vertical;font:inherit;color:inherit}
  .copy-dialog-buttons{justify-content:flex-end}
  .copy-dialog-buttons #copyDefault{margin-right:auto}` : ''}
  h1{font-size:30px;line-height:1.25;font-weight:700;margin:0 0 12px}
  h2{font-size:18px;line-height:1.4;font-weight:700;margin:0}
  p{margin:0}
  form{background:#fff;border:1px solid var(--line);border-radius:14px}
  section,footer{padding:22px 27px}
  section+section,footer{border-top:1px solid var(--line)}
  .heading{display:flex;flex-wrap:wrap;align-items:baseline;gap:6px 12px;margin:0 0 13px}
  .caption{color:var(--muted);font-size:14px}
  .cols{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px 18px}
  .field-title{display:flex;align-items:center;gap:7px;font-weight:600;margin:0 0 5px}
  .choice,.choice label{display:flex;align-items:center;gap:7px;min-width:0;min-height:30px}
  .choice label{cursor:pointer}
  input,button{font:inherit;color:inherit}
  input:not([type=checkbox]){
    display:block;width:100%;min-height:38px;padding:6px 9px;background:#fff;border:1px solid #b9c5bf;border-radius:7px
  }
  input[type=checkbox]{flex:none;accent-color:var(--green);width:17px;height:17px;margin:0}
  :focus-visible{outline:2px solid #237d66;outline-offset:2px}
  .download-interval{margin-top:12px}
  .interval-value{display:flex;align-items:center;gap:8px}
  .interval-value input{width:105px}
  .hint{position:relative;display:inline-flex;align-items:center;flex:none}
  .help{display:grid;place-items:center;width:19px;height:19px;padding:0;background:#fff;border:1px solid #b5c2bb;
    border-radius:50%;font:600 12px/1 system-ui,sans-serif;color:var(--muted)}
  .tip{visibility:hidden;position:fixed;z-index:5;inset:auto auto var(--tip-bottom,16px) var(--tip-left,16px);
    max-width:min(256px,calc(100vw - 24px));width:max-content;padding:8px 11px;border-radius:7px;
    background:#25332f;color:#fff;font-size:14px;font-weight:400;pointer-events:none}
  .hint:hover .tip,.hint:focus-within .tip{visibility:visible}
  footer{display:flex;justify-content:flex-end}
  button{cursor:pointer}
  .primary,.secondary{min-height:38px;padding:7px 13px;border:1px solid transparent;border-radius:7px;font-weight:600}
  .primary{background:var(--green);color:#fff;padding-inline:24px}
  .secondary{background:#fff;color:var(--green);border-color:#b9c5bf}
  .secondary:hover{background:var(--wash)}
  button:disabled{cursor:default;opacity:.55}
  @media(max-width:560px){
    main{padding:20px 13px}h1{font-size:26px}section,footer{padding:17px 15px}
    .cols{grid-template-columns:1fr}
  }
`;

function html(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[character]);
}

function copyText(key, fallback) {
  const marker = copyEditingEnabled ? ` data-copy-key="${html(key)}" data-copy-default="${html(fallback)}"` : '';
  return `<span${marker} class="copy-text">${html(setupCopy.text(key, fallback))}</span>`;
}

function sectionTitle(id, label) {
  return `<h2>${copyText(`section.${id}`, label)}</h2>`;
}

function document(title, content, script = '') {
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>${html(title)}</title><style>${css}</style></head>
<body><main>${content}</main>${script ? `<script nonce="${scriptNonce}">${script}</script>` : ''}</body></html>`;
}

function hint(id, label, explain) {
  const tipId = `${id}-help`;
  const marker = copyEditingEnabled ? ` data-copy-target="${id}.help"` : '';
  return `<span class="hint"><button type="button" class="help" aria-label="了解${html(label)}" aria-describedby="${tipId}"${marker}>?</button><span class="tip" role="tooltip" id="${tipId}">${copyText(`${id}.help`, explain)}</span></span>`;
}

function fieldTitle(id, label, explain) {
  return `<div class="field-title"><label for="${id}">${copyText(`${id}.label`, label)}</label>${explain ? hint(id, label, explain) : ''}</div>`;
}

function input(id, label, explain) {
  return `${fieldTitle(id, label, explain)}<input id="${id}" name="${id}" maxlength="${limits.get(id)}" spellcheck="false">`;
}

function checkbox(id, label, checked, explain) {
  return `<div class="choice"><label><input type="checkbox" id="${id}" name="${id}" value="1"${checked ? ' checked' : ''}>${copyText(`${id}.label`, label)}</label>
${hint(id, label, explain)}</div>`;
}

function boundedInteger(value, minimum, maximum) {
  if (typeof value === 'string' && /^\d+$/u.test(value)) value = Number(value);
  return Number.isInteger(value) && value >= minimum && value <= maximum ? value : null;
}

const script = `
const localDownloads = document.getElementById('localDownloads');
const downloadInterval = document.getElementById('autoIntervalMinutes');
const downloadIntervalRow = document.getElementById('downloadInterval');
const nameInput = document.getElementById('name');
const studentId = document.getElementById('studentId');
const setupForm = document.querySelector('form');

function updateDownloadControls() {
  downloadInterval.disabled = !localDownloads.checked;
  downloadIntervalRow.hidden = !localDownloads.checked;
}

localDownloads.addEventListener('change', updateDownloadControls);
window.addEventListener('pageshow', updateDownloadControls);
updateDownloadControls();

setupForm.addEventListener('submit', event => {
  if (Boolean(studentId.value.trim()) === Boolean(nameInput.value.trim())) return;
  event.preventDefault();
  const missing = nameInput.value.trim() ? studentId : nameInput;
  missing.setCustomValidity('请一起填写姓名和学号，也可以都留空。');
  missing.reportValidity();
  missing.setCustomValidity('');
});

document.querySelectorAll('.hint').forEach(anchor => {
  const button = anchor.querySelector('button');
  const tip = anchor.querySelector('.tip');
  function placeTip() {
    const box = button.getBoundingClientRect();
    const left = Math.max(12, Math.min(innerWidth - tip.offsetWidth - 12, box.left - 8));
    const bottom = box.top > tip.offsetHeight + 14 ? innerHeight - box.top + 6 : innerHeight - box.bottom - tip.offsetHeight - 6;
    tip.style.setProperty('--tip-left', left + 'px');
    tip.style.setProperty('--tip-bottom', Math.max(6, bottom) + 'px');
  }
  anchor.addEventListener('pointerenter', placeTip);
  anchor.addEventListener('focusin', placeTip);
});
`;

const copyEditorScript = `
const copyMode = document.getElementById('copyMode');
const copyCancel = document.getElementById('copyCancel');
const copyStatus = document.getElementById('copyStatus');
const copyDialog = document.getElementById('copyDialog');
const copyField = document.getElementById('copyField');
const copyNodes = new Map(Array.from(document.querySelectorAll('[data-copy-key]'), node => [node.dataset.copyKey, node]));
const savedCopy = new Map(Array.from(copyNodes, ([key, node]) => [key, node.textContent]));
let editingCopy = false;
let pendingCopy = false;
let selectedCopy = null;
let returnFocus = null;

function showCopy(key, value) {
  copyNodes.get(key).textContent = value;
  if (key === 'page.title') document.title = value;
}

function setCopyMode(active, message = '') {
  editingCopy = active;
  document.body.classList.toggle('copy-editing', active);
  copyMode.textContent = active ? '保存文案' : '编辑文案';
  copyMode.setAttribute('aria-pressed', String(active));
  copyCancel.hidden = !active;
  copyStatus.textContent = message;
  for (const node of copyNodes.values()) {
    if (node.closest('button, a, .tip')) continue;
    if (active) {
      node.tabIndex = 0;
      node.setAttribute('role', 'button');
    } else {
      node.removeAttribute('tabindex');
      node.removeAttribute('role');
    }
  }
}

copyMode.addEventListener('click', async () => {
  if (!editingCopy) {
    setCopyMode(true, '点一下标题、名称或问号即可编辑。');
    return;
  }
  const changes = Object.fromEntries(Array.from(copyNodes, ([key, node]) => [key, node.textContent])
    .filter(([key, value]) => value !== savedCopy.get(key)));
  if (!Object.keys(changes).length) {
    setCopyMode(false);
    return;
  }
  pendingCopy = true;
  copyMode.disabled = copyCancel.disabled = true;
  copyStatus.textContent = '正在保存文案…';
  try {
    const response = await fetch('${copyPath}', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ changes }),
    });
    const result = await response.json();
    if (!response.ok || !result.ok) throw new Error(result.message || '暂时无法保存文案。');
    for (const [key, value] of Object.entries(changes)) savedCopy.set(key, value);
    setCopyMode(false, '文案已保存。');
  } catch (error) {
    copyStatus.textContent = error.message || '暂时无法保存文案。';
  } finally {
    pendingCopy = false;
    copyMode.disabled = copyCancel.disabled = false;
    copyMode.focus();
  }
});

copyCancel.addEventListener('click', () => {
  for (const [key, value] of savedCopy) showCopy(key, value);
  setCopyMode(false);
  copyMode.focus();
});

function openCopyDialog(node, focus) {
  selectedCopy = node;
  returnFocus = focus;
  copyField.value = node.textContent;
  copyField.setCustomValidity('');
  copyDialog.showModal();
  copyField.select();
}

document.addEventListener('click', event => {
  if (!editingCopy || !(event.target instanceof Element) || copyDialog.contains(event.target)) return;
  const help = event.target.closest('[data-copy-target]');
  const control = event.target.closest('button, a');
  const node = help ? copyNodes.get(help.dataset.copyTarget)
    : event.target.closest('[data-copy-key]') || control?.querySelector('[data-copy-key]');
  if (node) {
    event.preventDefault();
    event.stopPropagation();
    if (!pendingCopy) openCopyDialog(node, control || node);
  } else if (setupForm.contains(event.target) && event.target.closest('input, select, button, a, label')) {
    event.preventDefault();
    event.stopPropagation();
  }
}, true);

document.addEventListener('keydown', event => {
  if (!editingCopy || copyDialog.open || !(event.target instanceof Element)) return;
  if (event.target.matches('[data-copy-key][tabindex]') && (event.key === 'Enter' || event.key === ' ')) {
    event.preventDefault();
    if (!pendingCopy) openCopyDialog(event.target, event.target);
  } else if (event.target.matches('form input, form select') && event.key !== 'Tab') {
    event.preventDefault();
  }
}, true);

setupForm.addEventListener('submit', event => {
  if (!editingCopy) return;
  event.preventDefault();
  event.stopImmediatePropagation();
}, true);

document.getElementById('copyDefault').addEventListener('click', () => {
  copyField.value = selectedCopy.dataset.copyDefault;
  copyField.setCustomValidity('');
  copyField.focus();
});
document.getElementById('copyDismiss').addEventListener('click', () => copyDialog.close());
copyField.addEventListener('input', () => copyField.setCustomValidity(''));
copyDialog.querySelector('form').addEventListener('submit', event => {
  event.preventDefault();
  const value = copyField.value.replace(/[\\r\\n\\t]+/g, ' ').trim();
  if (!value) {
    copyField.setCustomValidity('请输入文案，或恢复默认。');
    copyField.reportValidity();
    return;
  }
  showCopy(selectedCopy.dataset.copyKey, value);
  copyDialog.close();
});
copyDialog.addEventListener('close', () => {
  selectedCopy = null;
  returnFocus?.focus();
  returnFocus = null;
});
`;

function renderForm() {
  const copyControls = copyEditingEnabled ? `<div class="copy-actions"><button type="button" class="secondary" id="copyMode" aria-pressed="false">编辑文案</button>
<button type="button" class="secondary" id="copyCancel" hidden>取消编辑</button></div>` : '';
  const copyStatus = copyEditingEnabled ? '<p id="copyStatus" class="caption copy-status" role="status"></p>' : '';
  const copyDialog = copyEditingEnabled ? `<dialog class="copy-dialog" id="copyDialog" aria-labelledby="copyDialogTitle">
<form method="dialog"><h2 id="copyDialogTitle">编辑文案</h2>
<textarea id="copyField" rows="3" maxlength="240" required aria-labelledby="copyDialogTitle"></textarea>
<div class="copy-dialog-buttons"><button type="button" class="secondary" id="copyDefault">恢复默认</button>
<button type="button" class="secondary" id="copyDismiss">取消</button><button class="primary" type="submit">确定</button></div>
</form></dialog>` : '';
  return document(setupCopy.text('page.title', 'iSpace 首次设置'), `<header><div class="page-head">
<h1>${copyText('page.title', 'iSpace 首次设置')}</h1>${copyControls}</div>
${copyStatus}${context.demo === true ? '<p class="caption">示例预览</p>' : ''}</header>
<form method="post" action="${formPath}" autocomplete="off">
<section><div class="heading">${sectionTitle('identity', '本人资料')}</div><div class="cols">
<div>${input('name', '姓名')}</div>
<div>${input('studentId', '学号', '名字和学号用于在课程名单中识别你。请填写完整学号。')}</div>
</div></section>
<section><div class="heading">${sectionTitle('download', '课件下载')}</div>
${checkbox('localDownloads', '是否下载到本地电脑', initialLocalDownloads, '开启后，Chrome 会按间隔查找新课件，并保存到本机课程目录。')}
<div class="download-interval" id="downloadInterval"${initialLocalDownloads ? '' : ' hidden'}>
${fieldTitle('autoIntervalMinutes', '检查间隔', 'Chrome 开启时，每隔这么多分钟检查一次新课件。')}
<div class="interval-value"><input type="number" id="autoIntervalMinutes" name="autoIntervalMinutes" min="5" max="1440" value="${downloadInterval}" required${initialLocalDownloads ? '' : ' disabled'}>
<span>${copyText('downloadInterval.unit', '分钟')}</span></div></div></section>
<section><div class="heading">${sectionTitle('reminders', '提醒')}</div>
${checkbox('assignments', '作业提醒', preferences.reminders?.assignments !== 'off',
    `新作业和截止时间变动会在聊天里提醒。仍待交的作业默认在截止前 ${defaultAssignmentLeadHours} 小时内提醒一次。`)}</section>
<footer><button type="submit" class="primary">${copyText('settings.save', '保存设置')}</button></footer></form>
${copyDialog}`, copyEditingEnabled ? script + copyEditorScript : script);
}

function reply(res, status, body, extra = {}) {
  res.writeHead(status, {
    'Content-Type': 'text/html; charset=utf-8',
    'Cache-Control': 'no-store',
    'Referrer-Policy': 'same-origin',
    'X-Content-Type-Options': 'nosniff',
    'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-" + scriptNonce +
      "'; connect-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'",
    ...extra,
  });
  res.end(body);
}

function json(res, status, data) {
  reply(res, status, JSON.stringify(data), { 'Content-Type': 'application/json; charset=utf-8' });
}

function parse(text) {
  const values = new URLSearchParams(text);
  const entries = [...values.entries()];
  const autoDownloadRequested = values.has('localDownloads');
  if (entries.length !== new Set(entries.map(([key]) => key)).size ||
      !values.has('name') || !values.has('studentId') ||
      autoDownloadRequested !== values.has('autoIntervalMinutes') ||
      entries.some(([key, value]) => !limits.has(key) || value.length > limits.get(key) ||
        /[\u0000-\u001F\u007F]/u.test(value) || (switchFields.has(key) && value !== '1'))) return null;

  const name = values.get('name').trim();
  const studentId = values.get('studentId').trim();
  if (Boolean(name) !== Boolean(studentId)) return null;

  const autoIntervalMinutes = autoDownloadRequested ? boundedInteger(values.get('autoIntervalMinutes'), 5, 1440) : downloadInterval;
  if (autoIntervalMinutes === null) throw new RangeError('检查间隔请填写 5 到 1440 分钟之间的整数。');
  const autoDownload = chromeDownloadKnown && autoDownloadRequested === context.autoDownloadEnabled
    ? 'inherit' : autoDownloadRequested ? 'on' : 'off';
  const term = autoDownload === 'on' ? inferArchiveTerm(studentId, termOptions) : null;
  const tracked = Array.isArray(preferences.courses) && preferences.courses.length
    ? courses.filter(code => preferences.courses.includes(code)) : courses;

  return {
    schemaVersion: 2,
    createdAt: new Date().toISOString(),
    identity: name ? { name, studentId } : null,
    settings: {
      courses: tracked.length ? tracked : courses.length ? courses : null,
      reminders: {
        assignments: values.has('assignments') ? 'on' : 'off',
        assignmentLeadMinutes: [defaultAssignmentLeadHours * 60],
        changes: 'on',
        downloadDigest: 'on',
      },
      schedule: null,
      archive: {
        directoryChoice: 'inherit',
        directory: '',
        downloadMode: autoDownloadRequested ? 'auto' : 'off',
        year: term?.year ?? null,
        semester: term?.semester ?? null,
        autoDownload,
        autoIntervalMinutes,
        autoDailyLimit: downloadDailyLimit,
        autoScheduleChanged: autoIntervalMinutes !== downloadInterval,
      },
      attendance: preferences.attendance === 'assist' ? 'inherit' : 'assist',
      oldChatPolicy: 'inherit',
      permissions: {
        readSchool: 'allow',
        downloadFiles: autoDownloadRequested ? 'allow' : 'ask',
        backgroundReminders: 'allow',
        coordinateChats: 'allow',
      },
      models: { main: 'gpt-6.2-sol', worker: 'gpt-6.2-sol', background: 'gpt-6.1-terra' },
      modelEfforts: { main: 'high', worker: 'high', background: 'high' },
    },
  };
}

function save(data) {
  withLedgerLock(destination, () => {
    try {
      lstatSync(destination);
      throw Object.assign(new Error('已有待应用的首次设置'), { code: 'EEXIST' });
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
    atomicWrite(destination, JSON.stringify(data, null, 2) + '\n');
  });
}

function result(title, message, pending = []) {
  const details = pending.length ? `<p>以下设置待应用，回到聊天可继续。</p>
<ul>${pending.map(label => `<li>${html(label)}</li>`).join('')}</ul>` : '';
  return document(title, `<h1>${html(title)}</h1><p>${html(message)}</p>${details}`);
}

const pendingLabels = {
  needsArchive: 'Chrome 课件归档和自动下载',
  needsAttendance: '签到设置',
  needsOldChatPolicy: '旧聊天处理',
  needsBackgroundModel: '后台检查模型',
  needsSchedule: '后台检查时间',
};

async function readBody(req, limit) {
  const length = Number(req.headers['content-length']);
  if (!Number.isInteger(length) || length < 0 || length > limit) return null;
  const blocks = [];
  let received = 0;
  for await (const block of req) {
    received += block.length;
    if (received > limit) return null;
    blocks.push(block);
  }
  return received === length ? Buffer.concat(blocks).toString('utf8') : null;
}

async function handleCopy(req, res) {
  if (!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type'] ?? '')) {
    json(res, 415, { message: '请从当前设置页操作。' });
    return;
  }
  let data;
  try {
    const payload = await readBody(req, 196608);
    if (payload === null) throw new Error();
    data = JSON.parse(payload);
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error();
  } catch {
    json(res, 400, { message: '设置请求无法读取。' });
    return;
  }
  try {
    await setupCopy.save(data.changes);
    json(res, 200, { ok: true });
  } catch (error) {
    const invalid = error instanceof TypeError;
    json(res, invalid ? 400 : 500, { message: invalid ? error.message : '文案暂时无法保存，请重试。' });
  }
}

const server = createServer(async (req, res) => {
  const host = '127.0.0.1:' + server.address().port;
  const validPath = req.url === formPath || (copyEditingEnabled && req.url === copyPath);
  if (req.headers.host !== host || !validPath) {
    reply(res, 404, result('页面不存在', '请从当前聊天打开首次设置链接。'));
    return;
  }
  if (req.method === 'GET' && req.url === formPath) {
    reply(res, 200, renderForm());
    return;
  }
  if (req.method !== 'POST') {
    reply(res, 405, '', { Allow: req.url === formPath ? 'GET, POST' : 'POST' });
    return;
  }
  if (req.headers.origin !== 'http://' + host) {
    json(res, 403, { message: '请从当前设置页操作。' });
    return;
  }
  if (req.url !== formPath) {
    await handleCopy(req, res);
    return;
  }
  if (!/^application\/x-www-form-urlencoded(?:\s*;|$)/i.test(req.headers['content-type'] ?? '')) {
    reply(res, 415, result('来源无法确认', '请从当前设置页直接提交。'));
    return;
  }
  let payload;
  try {
    payload = await readBody(req, 12000);
  } catch {
    return;
  }
  let data;
  try {
    data = payload === null ? null : parse(payload);
  } catch (error) {
    reply(res, 400, result('请检查设置', (error instanceof RangeError ? error.message.replace(/。$/u, '') + '。' : '') + '请返回上一页调整。'));
    return;
  }
  if (!data) {
    reply(res, 400, result('请检查填写内容', '请检查姓名、学号和检查间隔。姓名和学号须一起填写，也可以都留空。'));
    return;
  }
  try {
    save(data);
  } catch (error) {
    reply(res, error.code === 'EEXIST' ? 409 : 500, result('这次设置尚未保存', '请回到聊天确认是否已有待应用的设置。'));
    return;
  }
  let message = '选项已保存到本机，设置应用待核对。请回到聊天继续。';
  let pending = [];
  try {
    const application = await applyLocalSetup(data);
    pending = Object.entries(pendingLabels).filter(([key]) => application[key]).map(([, label]) => label);
    message = '本机助手设置已应用。请回到聊天核对这次保存状态。';
    await keepComponentChanges(destination, data, application);
    message = pending.length ? '本机助手设置已应用。' : '本次设置已生效。你可以回到聊天继续。';
  } catch {
    pending = [];
  }
  reply(res, 200, result('已保存设置', message, pending), { Connection: 'close' });
  console.log('SAVED');
  server.close();
});

server.requestTimeout = 10000;
server.headersTimeout = 5000;
server.keepAliveTimeout = 1000;
const timer = setTimeout(() => {
  server.close();
  server.closeAllConnections();
  console.log('TIMED_OUT');
}, 10 * 60 * 1000);
server.once('close', () => clearTimeout(timer));
server.once('error', () => {
  clearTimeout(timer);
  console.log('UNAVAILABLE');
  process.exitCode = 1;
});
server.listen(0, '127.0.0.1', () => console.log('URL=http://127.0.0.1:' + server.address().port + formPath));

