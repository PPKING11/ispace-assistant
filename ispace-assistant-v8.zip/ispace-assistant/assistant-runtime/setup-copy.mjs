import { lstat } from 'node:fs/promises';
import { basename, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';

const filename = '首设文案.sqlite';
const defaultPath = fileURLToPath(new URL('../' + filename, import.meta.url));
const keyPattern = /^[a-zA-Z0-9_.:-]{1,96}$/u;
const copyLimit = 240;

function validText(value) {
  return typeof value === 'string' && Boolean(value.trim()) && value.length <= copyLimit &&
    !/[\u0000-\u001F\u007F\u2028\u2029]/u.test(value);
}

async function existsAsFile(path) {
  try {
    const stat = await lstat(path);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1) throw new Error('本机文案文件异常');
    return true;
  } catch (error) {
    if (error.code === 'ENOENT') return false;
    throw error;
  }
}

async function readOverrides(path) {
  if (!await existsAsFile(path)) return [];
  const { DatabaseSync } = await import('node:sqlite');
  const db = new DatabaseSync(path, { readOnly: true });
  try {
    db.exec('PRAGMA busy_timeout = 2500');
    const table = db.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'setup_copy'").get();
    if (!table) return [];
    const rows = db.prepare('SELECT copy_key, copy_text FROM setup_copy').all();
    return rows.filter(({ copy_key, copy_text }) => keyPattern.test(copy_key) && validText(copy_text))
      .map(({ copy_key, copy_text }) => [copy_key, copy_text]);
  } finally {
    db.close();
  }
}

export async function loadSetupCopy(path = process.env.ISPACE_SETUP_COPY_PATH || defaultPath) {
  if (!isAbsolute(path) || basename(path) !== filename) throw new Error('首设文案文件路径异常');
  const defaults = new Map();
  const overrides = new Map(await readOverrides(path).catch(() => []));

  return {
    text(key, fallback) {
      if (!keyPattern.test(key)) throw new Error('首设文案编号异常');
      defaults.set(key, fallback);
      return overrides.get(key) ?? fallback;
    },

    async save(changes) {
      if (!changes || typeof changes !== 'object' || Array.isArray(changes)) throw new TypeError('没有可保存的文案。');
      const entries = Object.entries(changes);
      if (entries.some(([key, text]) => !defaults.has(key) || !validText(text))) {
        throw new TypeError('文案须为 1 至 240 个字符的单行文字。');
      }
      if (!entries.length) return;

      await existsAsFile(path);
      const { DatabaseSync } = await import('node:sqlite');
      const db = new DatabaseSync(path);
      try {
        db.exec(`PRAGMA busy_timeout = 2500;
          BEGIN IMMEDIATE;
          CREATE TABLE IF NOT EXISTS setup_copy (copy_key TEXT PRIMARY KEY, copy_text TEXT NOT NULL) STRICT`);
        const update = db.prepare(`INSERT INTO setup_copy (copy_key, copy_text) VALUES (?, ?)
          ON CONFLICT(copy_key) DO UPDATE SET copy_text = excluded.copy_text`);
        const remove = db.prepare('DELETE FROM setup_copy WHERE copy_key = ?');
        for (const [key, text] of entries) {
          if (text.trim() === defaults.get(key)) remove.run(key);
          else update.run(key, text.trim());
        }
        db.exec('COMMIT');
      } finally {
        db.close();
      }

      for (const [key, text] of entries) {
        if (text.trim() === defaults.get(key)) overrides.delete(key);
        else overrides.set(key, text.trim());
      }
    },
  };
}
