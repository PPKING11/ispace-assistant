import { lstatSync, readFileSync, realpathSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const timeZone = 'Asia/Shanghai';
const maxWakeSlots = 16;
const maxDelayMinutes = 10;
const jobNames = ['assignments', 'downloadDigest'];
const defaultTimes = {
  assignments: ['08:10', '20:10'],
  downloadDigest: ['20:10'],
};
const catchUpTime = '08:10';
const clockFormat = new Intl.DateTimeFormat('en-GB', {
  timeZone, year: 'numeric', month: '2-digit', day: '2-digit',
  hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
});
const jobLabels = { assignments: '作业巡检', downloadDigest: '课件核对' };

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

export function normalizeSchedule(raw) {
  if (raw == null) return {};
  if (!isRecord(raw)) throw new TypeError('日程格式异常');
  const selected = {};
  for (const job of jobNames) {
    if (raw[job] == null) continue;
    const proposed = raw[job];
    const label = jobLabels[job];
    if (!isRecord(proposed) || !Array.isArray(proposed.times) || !proposed.times.length || proposed.times.length > 4 ||
      proposed.times.some(time => typeof time !== 'string' || !/^(?:[01]\d|2[0-3]):[0-5]\d$/u.test(time))) {
      throw new RangeError(label + '请选择 1 至 4 个有效的北京时间');
    }
    if (!Number.isInteger(proposed.maxRuns) || proposed.maxRuns < 1 || proposed.maxRuns > 12) {
      throw new RangeError(label + '每日上限应为 1 至 12 次');
    }
    selected[job] = { times: [...new Set(proposed.times)].sort(), maxRuns: proposed.maxRuns };
  }
  return selected;
}

function compileSchedule(raw) {
  const selected = normalizeSchedule(raw);
  const schedule = Object.fromEntries(jobNames.map(job => [
    job,
    selected[job] ?? { times: [...defaultTimes[job]], maxRuns: 2 },
  ]));
  const { times: downloadTimes } = schedule.downloadDigest;
  const downloadCatchUp = downloadTimes.length === 1 && downloadTimes[0] === defaultTimes.downloadDigest[0];
  const intended = new Set(jobNames.flatMap(job => schedule[job].times));
  if (downloadCatchUp) intended.add(catchUpTime);
  const times = [...intended].sort();
  const hours = [...new Set(times.map(time => time.slice(0, 2)))];
  const minutes = [...new Set(times.map(time => time.slice(3)))].sort();
  if (hours.length * minutes.length > maxWakeSlots) {
    throw new RangeError('时间组合过多，请少选几个不同分钟的时间');
  }
  const wakeTimes = hours.flatMap(hour => minutes.map(minute => hour + ':' + minute));
  return {
    timeZone, schedule, downloadCatchUp, wakeTimes,
    extraTimes: wakeTimes.filter(time => !intended.has(time)),
    rrule: 'FREQ=DAILY;BYHOUR=' + hours.map(Number).join(',') +
      ';BYMINUTE=' + minutes.map(Number).join(',') + ';BYSECOND=0',
  };
}

export function describeSchedule(raw) {
  return compileSchedule(raw);
}

export function unionRrule(raw) {
  const { rrule, wakeTimes, extraTimes } = compileSchedule(raw);
  return { rrule, wakeTimes, extraTimes };
}

function localTime(now) {
  const parts = Object.fromEntries(clockFormat.formatToParts(now).map(({ type, value }) => [type, value]));
  return { day: parts.year + '-' + parts.month + '-' + parts.day, minute: 60 * Number(parts.hour) + Number(parts.minute) };
}

function daysBefore(day, days) {
  const anchor = Date.parse(day + 'T00:00:00Z');
  return new Date(anchor - days * 86400000).toISOString().slice(0, 10);
}

function mostRecentWake(wakeTimes, clock) {
  const now = clock.minute;
  let best = null;
  for (const slot of wakeTimes) {
    const minute = 60 * Number(slot.slice(0, 2)) + Number(slot.slice(3));
    const delay = (now - minute + 1440) % 1440;
    if (delay <= maxDelayMinutes && (best === null || delay < best.delay)) {
      best = { slot, checkId: now < minute ? daysBefore(clock.day, 1) : clock.day, delay };
    }
  }
  return best;
}

function assertPlainFile(path, maximum) {
  try {
    const stat = lstatSync(path);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1 || stat.size > maximum) {
      throw new Error('本机配置或巡检记录格式异常');
    }
    return true;
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    return false;
  }
}

async function applyClaim(path, occurrence, job, maxRuns, now) {
  assertPlainFile(path, 8 * 1024 * 1024);
  const { DatabaseSync } = await import('node:sqlite');
  const db = new DatabaseSync(path);
  try {
    db.exec('PRAGMA busy_timeout = 6000; BEGIN IMMEDIATE');
    db.exec(`CREATE TABLE IF NOT EXISTS claims (
      check_id TEXT NOT NULL, job TEXT NOT NULL, slot TEXT NOT NULL, taken_at TEXT NOT NULL,
      PRIMARY KEY (check_id, job, slot)
    ) STRICT`);
    const { checkId, slot } = occurrence;
    const counter = db.prepare('SELECT count(*) AS n FROM claims WHERE check_id = ? AND job = ?');
    const runsToday = counter.get(checkId, job).n;
    const exists = db.prepare('SELECT 1 FROM claims WHERE check_id = ? AND job = ? AND slot = ?').get(checkId, job, slot);
    const reason = exists ? 'already-claimed' : runsToday >= maxRuns ? 'daily-limit' : 'claimed';
    const allowed = reason === 'claimed';
    if (allowed) {
      db.prepare('INSERT INTO claims (check_id, job, slot, taken_at) VALUES (?, ?, ?, ?)').run(checkId, job, slot, now.toISOString());
      db.prepare('DELETE FROM claims WHERE check_id < ?').run(daysBefore(checkId, 14));
    }
    db.exec('COMMIT');
    return { allowed, reason, slot, checkId, runsToday: runsToday + Number(allowed), maxRuns };
  } finally {
    db.close();
  }
}

export async function claimScheduledRun({ preferences = {}, ledgerPath, job, catchUp = false, now = new Date() }) {
  if (!jobNames.includes(job)) throw new TypeError('巡检任务无效');
  const compiled = compileSchedule(preferences.schedule);
  const clock = localTime(now);
  const wake = mostRecentWake(compiled.wakeTimes, clock);
  const { times, maxRuns } = compiled.schedule[job];
  const skipped = reason => ({ allowed: false, reason, slot: wake?.slot ?? null, checkId: wake?.checkId ?? clock.day,
    runsToday: null, maxRuns });
  if (preferences.permissions?.readSchool === 'ask' || preferences.permissions?.backgroundReminders === 'ask' ||
    (job === 'downloadDigest' && (preferences.courseDownloadMode === 'off' || preferences.reminders?.downloadDigest === 'off'))) {
    return skipped('disabled');
  }
  if (!wake) return skipped('outside-schedule');
  const isCatchUp = job === 'downloadDigest' && compiled.downloadCatchUp && wake.slot === catchUpTime;
  if (!times.includes(wake.slot) && !(isCatchUp && catchUp)) return skipped('other-slot');
  return applyClaim(ledgerPath, wake, job, maxRuns, now);
}

function readPreferences(root) {
  const path = join(root, '助手设置.json');
  if (!assertPlainFile(path, 65536)) return {};
  const settings = JSON.parse(readFileSync(path, 'utf8'));
  if (!isRecord(settings)) throw new TypeError('助手设置格式异常');
  return settings;
}

async function execute(args) {
  const [command, job, flag, ...rest] = args;
  const root = realpathSync(fileURLToPath(new URL('../', import.meta.url)));
  if (command === 'plan' && args.length === 1) return describeSchedule(readPreferences(root).schedule);
  if (command === 'claim' && job && (!flag || (flag === '--catch-up' && job === 'downloadDigest')) && !rest.length) {
    return claimScheduledRun({
      preferences: readPreferences(root),
      ledgerPath: join(root, '.setup-schedule.sqlite'),
      job,
      catchUp: flag === '--catch-up',
    });
  }
  throw new Error('用法：setup-schedule.mjs plan | claim assignments | claim downloadDigest [--catch-up]');
}

if (process.argv[1] && pathToFileURL(process.argv[1]).href === import.meta.url) {
  try {
    console.log(JSON.stringify(await execute(process.argv.slice(2))));
  } catch (error) {
    console.error(JSON.stringify({ error: error.message }));
    process.exitCode = 1;
  }
}

