const statusLabels = {
  ready: '已就绪',
  installed: '已安装',
  disabled: '待启用',
  unpaired: '待配对',
  downloaded: '已下载，待安装',
  missing: '待下载',
  unknown: '待检查',
  disconnected: '待连接',
  read_failed: '读取待核对',
  optional: '按需下载',
};

const legacyStates = {
  无需下载: 'installed',
  需要下载: 'missing',
  按需下载: 'optional',
  待检查: 'unknown',
};

function privateConnectionState(context) {
  if (context.connection === 'read_failed') return 'read_failed';
  if (['missing_credential', 'connection_unverified'].includes(context.connection)) return 'disconnected';
  if (context.connection === 'verified' || context.connected === true) return 'ready';
  return context.connected === false ? 'disconnected' : 'unknown';
}

export function describeSetupComponent(context, key) {
  const info = context.components?.[key];
  let state = key === 'attendance' ? 'optional' : 'unknown';
  if (key === 'privateSite') {
    state = privateConnectionState(context);
  } else if (Object.hasOwn(statusLabels, info?.state)) {
    state = info.state;
  } else if (Object.hasOwn(legacyStates, info?.downloadStatus)) {
    state = legacyStates[info.downloadStatus];
  }
  if (key !== 'attendance' && state === 'missing' &&
      ['downloaded', 'already_downloaded'].includes(context.componentPackageStatus)) {
    state = 'downloaded';
  }
  return { state, label: statusLabels[state], href: info?.href };
}
