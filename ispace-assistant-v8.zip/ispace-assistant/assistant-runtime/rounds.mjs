import { createReadStream } from 'node:fs';
import { readFile, readdir } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { createInterface } from 'node:readline';
import { fileURLToPath, pathToFileURL } from 'node:url';

const idPattern = /^[a-f0-9]{8}-[a-f0-9]{4}-7[a-f0-9]{3}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const bookkeeping = /^【ispace助手(?:后台汇报|交接核对|维护)】/;
const dayMs = 24 * 60 * 60 * 1000;

async function sessionLog(chatId, sessions) {
  if (!idPattern.test(chatId)) return null;
  const epoch = Number.parseInt(chatId.replaceAll('-', '').slice(0, 12), 16);
  const days = [0, -1, 1].map(shift => new Date(epoch + shift * dayMs).toISOString().slice(0, 10).split('-'));
  for (const day of days) {
    const folder = join(sessions, ...day);
    try {
      const files = await readdir(folder, { withFileTypes: true });
      const match = files.find(entry => entry.isFile() && entry.name.endsWith(chatId + '.jsonl'));
      if (match) return join(folder, match.name);
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
  }
  return null;
}

function messageIsWork(payload) {
  if (payload.type === 'user_message' && typeof payload.message === 'string') {
    return !bookkeeping.test(payload.message.trimStart());
  }
  if (payload.role !== 'user' || !Array.isArray(payload.content)) return null;
  const text = payload.content.find(part => part?.type === 'input_text' && typeof part.text === 'string' && part.text.trim())?.text;
  if (!text) return payload.content.some(part => part?.type === 'input_image') ? true : null;
  if (/^\s*<(environment_context|permissions instructions)>/.test(text)) return null;
  return !bookkeeping.test(text.trimStart());
}

export async function summarizeRounds(lines, enabledAt) {
  const boundary = Date.parse(enabledAt);
  const counted = new Set();
  let active = null;
  let contextStrained = false;
  for await (const line of lines) {
    // Skip tool arguments and outputs before parsing. User text is never retained or returned.
    if (!/task_started|task_complete|turn_aborted|compacted|user_message|"role":"user"/.test(line)) continue;
    let event;
    try { event = JSON.parse(line); } catch { continue; }
    const data = event.payload;
    if (event.type === 'event_msg' && data?.type === 'task_started') {
      const at = typeof data.started_at === 'number' ? data.started_at * 1000 : Date.parse(event.timestamp);
      // Host start timestamps may have second-wide precision.
      active = at >= Math.floor(boundary / 1000) * 1000
        ? { id: data.turn_id, root: data.root_turn_id ?? data.turn_id, substantive: null }
        : null;
    } else if (active && event.type === 'compacted') {
      contextStrained = true;
    } else if (active && active.substantive === null && (
      (event.type === 'event_msg' && data?.type === 'user_message') ||
      (event.type === 'response_item' && data?.type === 'message' && data.role === 'user')
    )) {
      active.substantive = messageIsWork(data);
    } else if (active && event.type === 'event_msg' && data?.turn_id === active.id) {
      if (data.type === 'task_complete' && active.substantive && data.last_agent_message?.trim()) counted.add(active.root);
      if (data.type === 'task_complete' || data.type === 'turn_aborted') active = null;
    }
  }
  return { rounds: counted.size, contextStrained };
}

async function currentObservations() {
  const statePath = fileURLToPath(new URL('../state.json', import.meta.url));
  const state = JSON.parse(await readFile(statePath, 'utf8'));
  const sessions = join(process.env.CODEX_HOME ?? join(homedir(), '.codex'), 'sessions');
  return Promise.all(Object.values(state.chats).filter(chat => chat.status === 'active').map(async chat => {
    try {
      const log = await sessionLog(chat.id, sessions);
      if (!log) return { chatId: chat.id, verified: false };
      const lines = createInterface({ input: createReadStream(log, { encoding: 'utf8' }), crlfDelay: Infinity });
      const { rounds, contextStrained } = await summarizeRounds(lines, chat.createdAt);
      return { chatId: chat.id, verified: true, rounds, contextStrained };
    } catch {
      return { chatId: chat.id, verified: false };
    }
  }));
}

if (process.argv[1] && pathToFileURL(process.argv[1]).href === import.meta.url) {
  console.log(JSON.stringify(await currentObservations(), null, 2));
}
