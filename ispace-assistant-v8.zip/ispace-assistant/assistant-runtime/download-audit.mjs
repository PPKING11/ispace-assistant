import { createHash } from 'node:crypto';
import { lstat, readFile, readdir } from 'node:fs/promises';
import { isAbsolute, join, relative, resolve } from 'node:path';
import { stdin } from 'node:process';
import { pathToFileURL } from 'node:url';
import { MAX_FILE_BYTES } from '../../ispace-site/lib/course-download.mjs';
import { safeFileUrl } from '../../ispace-site/lib/course-resources.mjs';
import { buildLocalFileManifest, courseFileCategory } from '../../ispace-site/lib/local-course-files.mjs';
import { snapshotFreshness } from '../../ispace-site/lib/sync-policy.mjs';
import { assertOwner, nativeSettings, ownerScope, readOwnerConfig } from './portable-config.mjs';

const categories = {
  lectures: 'Lectures', assignments: 'Assignments', 'group-projects': 'Group Projects',
  labs: 'Labs', tutorials: 'Tutorials', exams: 'Exams', other: 'Other',
};
const ownerMarker = '.ispace-course-owner';
const internalPrefix = '.ispace-course-';
const hashPattern = /^[a-f0-9]{64}$/;
const maxInputBytes = 8 * 1024 * 1024;
const utcTimestamp = /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,3})?Z$/;
const dateFormatter = new Intl.DateTimeFormat('sv-SE', { timeZone: 'Asia/Shanghai' });
const hash = value => createHash('sha256').update(value).digest('hex');
const caseKey = value => value.toUpperCase();

function validDate(value) {
  return typeof value === 'string' && /^\d{4}-\d\d-\d\d$/.test(value) &&
    Number.isFinite(Date.parse(value)) && new Date(value).toISOString().startsWith(value);
}

function result(checkId, verifiedAt, files = [], problem) {
  const totals = { downloaded: 0, not_downloaded: 0, skipped: 0, failed: 0 };
  for (const file of files) totals[file.status]++;
  return { checkId, verifiedAt, complete: !problem, ...problem, totals, files };
}

function problem(reasonCode, reason) {
  return { reasonCode, reason };
}

async function inspect(path) {
  try {
    return await lstat(path, { bigint: true });
  } catch (error) {
    if (error.code === 'ENOENT') return null;
    throw error;
  }
}

async function directoryExists(path) {
  const metadata = await inspect(path);
  if (metadata && !metadata.isDirectory()) throw new Error('directory_required');
  return Boolean(metadata);
}

async function smallMetadata(path, maxBytes) {
  const metadata = await inspect(path);
  if (!metadata) return null;
  if (!metadata.isFile() || metadata.size > BigInt(maxBytes)) throw new Error('invalid_metadata');
  return readFile(path, 'utf8');
}

function archiveExtension(name) {
  const dot = name.lastIndexOf('.');
  return dot >= 0 && dot < name.length - 1 ? name.slice(dot) : '';
}

// Match the Windows native host's safe filename and collision naming.
function fileComponent(input, maxLength) {
  let name = input.normalize('NFC').replace(/[<>:"/\\|?*\p{Cc}\p{Cf}]/gu, '_').trim().replace(/\.+$/, '');
  if (!name || /^(?:CON|PRN|AUX|NUL|CONIN\$|CONOUT\$|COM[0-9¹²³]|LPT[0-9¹²³])(?:\.|$)/i.test(name) ||
      name.toLowerCase().startsWith(internalPrefix)) name = '_' + name;
  if (name.length <= maxLength) return name;
  const hostExtension = archiveExtension(name);
  const extension = hostExtension.length <= 15 ? hostExtension : '';
  const suffix = '-' + hash(name).slice(0, 8);
  let prefix = name.slice(0, maxLength - extension.length - suffix.length);
  if (/[\uD800-\uDBFF]$/.test(prefix)) prefix = prefix.slice(0, -1);
  return prefix.replace(/[ .]+$/, '') + suffix + extension;
}

async function courseDirectory(termDirectory, courseId, code) {
  let path = join(termDirectory, fileComponent(code, 50));
  if (await directoryExists(path)) {
    const marker = await smallMetadata(join(path, '.ispace-course-code'), 64);
    if (marker !== null && marker !== String(courseId)) {
      path += '-' + hash(String(courseId)).slice(0, 8);
      if (await directoryExists(path)) {
        const claimed = await smallMetadata(join(path, '.ispace-course-code'), 64);
        if (claimed !== null && claimed !== String(courseId)) throw new Error('wrong_course_directory');
      }
    }
  }
  return path;
}

function localFileName(name) {
  return typeof name === 'string' && /^[^<>:"/\\|?*\x00-\x1f]+$/.test(name) && name !== '.' && name !== '..' &&
    !name.toLowerCase().startsWith(internalPrefix) && !name.toLowerCase().endsWith('.partial');
}

async function folderInventory(path) {
  if (!await directoryExists(path)) return new Map();
  const files = new Map();
  for (const entry of await readdir(path, { withFileTypes: true })) {
    if (!entry.isFile() || !localFileName(entry.name)) continue;
    const absolutePath = join(path, entry.name);
    const metadata = await inspect(absolutePath);
    if (!metadata?.isFile()) continue;
    const key = caseKey(entry.name);
    files.set(key, files.has(key) ? null : { absolutePath, size: metadata.size, mtimeNs: metadata.mtimeNs });
  }
  return files;
}

function locator(courseId, itemId, resourceIndex) {
  return JSON.stringify([courseId, itemId, Number(resourceIndex)]);
}

async function skippedFiles(items, courses, manifest) {
  const courseById = new Map(courses.map(course => [course.id, course.code]));
  const known = new Set(manifest.files.map(file => {
    const params = new URLSearchParams(file.downloadUrl.split('?')[1]);
    return locator(file.courseId, params.get('itemId'), params.get('resourceIndex'));
  }));
  const files = [];
  const counts = { unsupported: 0, tooLarge: 0 };
  for (const item of items) {
    const metadata = item.resourceMetadata;
    const course = courseById.get(item.courseId);
    if (!course || !['module', 'assignment'].includes(item.kind) ||
        !['assign', 'folder', 'resource'].includes(metadata?.moduleType)) continue;
    for (const [index, resource] of (metadata.resources ?? []).entries()) {
      if (index > 99 || resource?.kind !== 'file' || typeof resource.name !== 'string' ||
          known.has(locator(item.courseId, item.id, index))) continue;
      // Prefer the shared manifest policy for exclusions and extension/size limits.
      const diagnostic = await buildLocalFileManifest({
        items: [{ ...item, resourceMetadata: { ...metadata, resources: [resource] } }],
        courses, verifiedAt: manifest.verifiedAt, profileId: 'download-audit',
      });
      if (!(diagnostic.skipped.unsupported || diagnostic.skipped.tooLarge)) continue;
      const link = safeFileUrl(resource.fileUrl);
      let reason;
      if (diagnostic.skipped.tooLarge) {
        counts.tooLarge++;
        reason = problem('too_large', '超过自动下载上限（' + (MAX_FILE_BYTES / 1024 / 1024) + ' MiB）');
      } else {
        counts.unsupported++;
        reason = link
          ? problem('unsupported_extension', '自动下载暂不支持此文件格式')
          : problem('unavailable_file_link', '文件链接暂不可用于自动下载');
      }
      const id = hash(JSON.stringify([item.courseId, item.id, index, resource.name, link,
        resource.size ?? null, resource.modifiedAt ?? item.rawDates?.timemodified ?? null]));
      const identityPath = link ? new URL(link).pathname
        .replace(/^\/webservice\/pluginfile\.php\//, '/pluginfile.php/')
        .replace(/(\/mod_(?:resource|folder)\/content\/)\d+\//, '$1') : resource.name;
      files.push({
        id: 'skipped:' + id, fileId: hash(JSON.stringify([item.courseId, item.id, identityPath])),
        courseId: item.courseId, courseCode: course,
        filename: resource.name, category: courseFileCategory(item, resource.name), skip: reason,
        ...(Number.isSafeInteger(resource.size) && resource.size > 0 ? { bytes: resource.size } : {}),
      });
    }
  }
  if (counts.tooLarge !== manifest.skipped.tooLarge || counts.unsupported !== manifest.skipped.unsupported) {
    throw new Error('skip_count_mismatch');
  }
  return files;
}

async function receiptMatch(receiptDirectory, identity, root, termName, inventory, bytes) {
  if (!receiptDirectory) return null;
  const receiptName = hash(caseKey(root) + '\0' + termName + '\0' + identity) + '.json';
  const content = await smallMetadata(join(receiptDirectory, receiptName), 4096);
  if (content === null) return null;
  // Native .NET ticks do not fit in JavaScript's number type.
  let receipt;
  try {
    receipt = JSON.parse(content.replace(/("LastWriteUtcTicks"\s*:\s*)(\d+)/, '$1"$2"'));
  } catch {
    return null;
  }
  if (!localFileName(receipt?.Filename) || !Number.isSafeInteger(receipt.Bytes) || receipt.Bytes <= 0 ||
      (bytes !== undefined && bytes !== receipt.Bytes) || !hashPattern.test(receipt.Sha256 ?? '') ||
      typeof receipt.LastWriteUtcTicks !== 'string' || !/^\d{1,19}$/.test(receipt.LastWriteUtcTicks)) return null;
  const local = inventory.get(caseKey(receipt.Filename));
  if (!local || local.size !== BigInt(receipt.Bytes)) return null;
  const ticks = local.mtimeNs / 100n + 621355968000000000n;
  return ticks === BigInt(receipt.LastWriteUtcTicks) ? local : null;
}

function expectedCandidates(localName, identity) {
  const extension = archiveExtension(localName);
  const stem = localName.slice(0, localName.length - extension.length);
  return Array.from({ length: 99 }, (_, index) => {
    const number = index === 0 ? '' : '-' + (index + 1);
    return caseKey(stem + ' (' + identity.slice(0, 8) + number + ')' + extension);
  });
}

async function compareLocal(root, term, profileHash, stateDirectory, files) {
  const termName = 'Year ' + term.year + ' Semester ' + term.semester;
  const termDirectory = join(root, termName);
  if (!await directoryExists(root) || !await directoryExists(termDirectory)) throw new Error('folder_missing');
  const owner = await smallMetadata(join(root, ownerMarker), 64);
  if ((owner !== null && !hashPattern.test(owner)) || (profileHash !== undefined && owner !== profileHash)) {
    throw new Error('profile_mismatch');
  }
  let receiptDirectory;
  if (owner && stateDirectory && await directoryExists(stateDirectory)) {
    const path = join(stateDirectory, owner + '-receipts');
    if (await directoryExists(path)) receiptDirectory = path;
  }
  const coursePaths = new Map();
  const inventories = new Map();
  const candidates = [];
  const nameCounts = new Map();
  for (const file of files) {
    const identity = file.id ?? hash(String(file.courseId) + '\0' + file.fileId + '\0' + file.revision);
    if (!coursePaths.has(file.courseId)) {
      coursePaths.set(file.courseId, await courseDirectory(termDirectory, file.courseId, file.courseCode));
    }
    const directory = join(coursePaths.get(file.courseId), categories[file.category]);
    const nameLimit = Math.min(130, 240 - directory.length - 25);
    if (!file.skip && nameLimit < 20) throw new Error('archive_path_too_long');
    if (!inventories.has(directory)) inventories.set(directory, await folderInventory(directory));
    const inventory = inventories.get(directory);
    const localName = file.skip ? file.filename : fileComponent(file.filename, nameLimit);
    const localKey = caseKey(directory) + '\0' + caseKey(localName);
    const receipt = file.skip ? null : await receiptMatch(receiptDirectory, identity, root, termName, inventory, file.bytes);
    const named = localFileName(localName) ? inventory.get(caseKey(localName)) : null;
    const collision = !file.skip && file.bytes && expectedCandidates(localName, identity)
      .map(name => inventory.get(name)).find(candidate => candidate?.size === BigInt(file.bytes));
    const sameNameAndSize = named && file.bytes && named.size === BigInt(file.bytes);
    if (sameNameAndSize) nameCounts.set(localKey, (nameCounts.get(localKey) ?? 0) + 1);
    candidates.push({ identity, file, localKey, receipt, collision, named, sameNameAndSize });
  }
  const identifiedPaths = new Set(candidates.flatMap(({ receipt, collision }) =>
    [receipt, collision].filter(Boolean).map(item => caseKey(item.absolutePath))));
  return candidates.map(({ identity, file, localKey, receipt, collision, named, sameNameAndSize }) => {
    const base = { id: identity, sourceId: file.fileId, courseId: file.courseId, course: file.courseCode, filename: file.filename };
    if (file.bytes !== undefined) base.bytes = file.bytes;
    if (receipt) return { ...base, status: 'downloaded', evidence: 'receipt', localPath: relative(root, receipt.absolutePath) };
    if (collision) return { ...base, status: 'downloaded', evidence: 'versioned_name_and_size', localPath: relative(root, collision.absolutePath) };
    if (sameNameAndSize && nameCounts.get(localKey) === 1 && !identifiedPaths.has(caseKey(named.absolutePath))) {
      return { ...base, status: 'downloaded', evidence: 'name_and_size', localPath: relative(root, named.absolutePath) };
    }
    if (file.skip) return { ...base, status: 'skipped', ...file.skip };
    const reason = !named ? problem('missing_from_archive', '课程文件夹还没有这份文件')
      : !file.bytes ? problem('unverified_size', '本地有同名文件，iSpace 未提供大小，暂时无法确认')
      : !sameNameAndSize ? problem('size_mismatch', '本地同名文件大小和 iSpace 不一致')
      : problem('ambiguous_match', '本地同名文件对应多个资源，暂时无法确认');
    return { ...base, status: 'not_downloaded', ...reason };
  });
}

export async function auditDownloads(input, { now = Date.now(), checkId: preferredDate } = {}) {
  const checkId = preferredDate ?? input?.checkId ?? dateFormatter.format(now);
  const verifiedAt = typeof input?.verifiedAt === 'string' && utcTimestamp.test(input.verifiedAt) &&
    Number.isFinite(Date.parse(input.verifiedAt)) ? input.verifiedAt : null;
  const incomplete = (code, reason) => result(validDate(checkId) ? checkId : dateFormatter.format(now),
    verifiedAt, [], problem(code, reason));
  if (!validDate(checkId)) return incomplete('invalid_check_date', '检查日期格式无效');
  if (!input || input.verified !== true || !verifiedAt || (input.connection && input.connection !== 'verified')) {
    return incomplete('source_unavailable', '这次未取得已验证的 iSpace 文件清单');
  }
  if (input.freshness === 'stale' || snapshotFreshness(verifiedAt, now).freshness === 'stale') {
    return incomplete('source_stale', 'iSpace 文件清单上次验证已超过 13 小时');
  }
  if (input.sourceComplete === false || input.nextOffset != null || !Array.isArray(input.items) ||
      (input.total !== undefined && input.items.length !== input.total) ||
      input.items.some(item => !item || !Number.isSafeInteger(item.courseId) || typeof item.id !== 'string' ||
        (item.resourceMetadata?.resources != null && !Array.isArray(item.resourceMetadata.resources))) ||
      new Set(input.items.map(item => locator(item.courseId, item.id, 0))).size !== input.items.length) {
    return incomplete('source_incomplete', 'iSpace 文件清单没有完整读到');
  }
  const courses = input.courses;
  if (!Array.isArray(courses) || courses.length === 0 ||
      courses.some(course => !course || !Number.isSafeInteger(course.id) || course.id <= 0 ||
        typeof course.code !== 'string' || !course.code.trim()) ||
      new Set(courses.map(course => course.id)).size !== courses.length) {
    return incomplete('invalid_course_mapping', '课程与本地文件夹的对应关系无效');
  }
  const courseIds = new Set(courses.map(course => course.id));
  if (input.items.some(item => !courseIds.has(item.courseId))) {
    return incomplete('source_scope_mismatch', '附件清单中含有本次未选择的课程');
  }
  const term = input.term;
  const state = input.stateDirectory ?? (process.env.LOCALAPPDATA && join(process.env.LOCALAPPDATA, 'iSpaceCourseSync'));
  if (typeof input.localRoot !== 'string' || !isAbsolute(input.localRoot) ||
      !Number.isSafeInteger(term?.year) || term.year < 1 || term.year > 12 ||
      !Number.isSafeInteger(term?.semester) || term.semester < 1 || term.semester > 3 ||
      (input.profileHash !== undefined && (typeof input.profileHash !== 'string' || !hashPattern.test(input.profileHash))) ||
      (state && (typeof state !== 'string' || !isAbsolute(state)))) {
    return incomplete('invalid_local_settings', '本地下载路径或学期设置无效');
  }
  const items = [...input.items].sort((a, b) => a.courseId - b.courseId || a.id.localeCompare(b.id));
  let manifest;
  let skipped;
  try {
    manifest = await buildLocalFileManifest({ items, verifiedAt, courses, profileId: 'download-audit' });
    skipped = await skippedFiles(items, courses, manifest);
  } catch {
    return incomplete('source_incomplete', 'iSpace 文件清单有无法核对的项目');
  }
  try {
    const local = await compareLocal(resolve(input.localRoot), term, input.profileHash, state, [...manifest.files, ...skipped]);
    return { ...result(checkId, verifiedAt, local), courseIds: courses.map(({ id }) => id) };
  } catch (error) {
    if (error.message === 'profile_mismatch') {
      return incomplete('local_profile_mismatch', '课程文件夹与本次 iSpace 账户配置不一致');
    }
    return incomplete('local_unavailable', '本地课程文件夹或学期文件夹暂时无法读取');
  }
}

async function main(args) {
  let inputPath;
  let checkId;
  try {
    for (let index = 0; index < args.length; index += 2) {
      if (!args[index + 1]) throw new Error('argument_required');
      if (args[index] === '--input' && inputPath === undefined) inputPath = args[index + 1];
      else if (args[index] === '--checkId' && checkId === undefined) checkId = args[index + 1];
      else throw new Error('invalid_argument');
    }
    let raw;
    if (inputPath) {
      const metadata = await lstat(inputPath);
      if (!metadata.isFile() || metadata.size > maxInputBytes) throw new Error('invalid_input_file');
      raw = await readFile(inputPath, 'utf8');
    } else {
      const chunks = [];
      let size = 0;
      for await (const chunk of stdin) {
        size += chunk.length;
        if (size > maxInputBytes) throw new Error('input_limit');
        chunks.push(chunk);
      }
      raw = Buffer.concat(chunks).toString('utf8');
    }
    const input = JSON.parse(raw.replace(/^\uFEFF/, ''));
    if (!checkId && validDate(input?.checkId)) checkId = input.checkId;
    const date = checkId ?? dateFormatter.format(Date.now());
    let local, courses;
    try {
      const status = input?.syncStatus;
      const scope = ownerScope(status);
      const { profileHash } = readOwnerConfig();
      assertOwner(profileHash, scope.profileHash);
      if (status.connection !== 'verified' || status.lastVerifiedRead !== input.verifiedAt || status.itemCount !== input.total) {
        throw new Error('iSpace 课程状态与附件清单不一致，请完成同步后再核对');
      }
      local = await nativeSettings(profileHash);
      courses = scope.courses;
    } catch (error) {
      return result(date, null, [], problem('owner_setup_or_snapshot_changed', error.message));
    }
    return await auditDownloads({ ...input, ...local, courses }, { checkId: date });
  } catch {
    return result(validDate(checkId) ? checkId : dateFormatter.format(Date.now()), null, [],
      problem('invalid_input', '这次未能读取 iSpace 下载核对输入'));
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  process.stdout.write(JSON.stringify(await main(process.argv.slice(2))) + '\n');
}
