const calendar = [
  { academicYear: 2025, semester: 2, start: '2026-02-24', end: '2026-06-19' },
  { academicYear: 2025, semester: 3, start: '2026-06-29', end: '2026-08-18' },
  { academicYear: 2026, semester: 1, start: '2026-09-01', end: '2027-01-11' },
];

function beijingDate(now) {
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(now).map(({ type, value }) => [type, value]));
  return parts.year + '-' + parts.month + '-' + parts.day;
}

function dateParts(date) {
  if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/u.test(date)) return null;
  const parsed = new Date(date + 'T00:00:00.000Z');
  return Number.isFinite(parsed.valueOf()) && parsed.toISOString().slice(0, 10) === date
    ? { year: parsed.getUTCFullYear(), month: parsed.getUTCMonth() + 1 }
    : null;
}

function activeTerm(today, parts, schoolTerm) {
  if (Number.isInteger(schoolTerm?.academicYear) &&
    [parts.year, parts.year - 1].includes(schoolTerm.academicYear) &&
    [1, 2, 3].includes(schoolTerm.semester)) return schoolTerm;
  const published = calendar.find(term => today >= term.start && today <= term.end);
  if (published) return published;
  if (parts.month >= 9) return { academicYear: parts.year, semester: 1 };
  if (parts.month >= 3 && parts.month <= 5) return { academicYear: parts.year - 1, semester: 2 };
  return null;
}

export function inferArchiveTerm(studentId, { today = beijingDate(new Date()), currentAcademicTerm } = {}) {
  const match = typeof studentId === 'string' ? /^(\d{2})/u.exec(studentId.normalize('NFKC').trim()) : null;
  const parts = dateParts(today);
  if (!match || !parts) return null;
  const term = activeTerm(today, parts, currentAcademicTerm);
  if (!term) return null;
  const admissionYear = 2000 + Number(match[1]);
  const year = term.academicYear - admissionYear + 1;
  return year >= 1 && year <= 12
    ? { year, semester: term.semester, admissionYear }
    : null;
}

