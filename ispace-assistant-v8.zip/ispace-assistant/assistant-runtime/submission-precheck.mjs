import { createHash } from 'node:crypto';
import { closeSync, fstatSync, lstatSync, openSync, readSync, realpathSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const schoolOrigin = 'https://ispace.bnbu.edu.cn';
const assignmentPath = '/mod/assign/view.php';
const project = fileURLToPath(new URL('../', import.meta.url));

export function parseSchoolSubmissionUrl(value) {
  try {
    const url = new URL(value);
    const ids = url.searchParams.getAll('id');
    if (url.origin !== schoolOrigin || url.username || url.password || url.pathname !== assignmentPath ||
      ids.length !== 1 || !/^[1-9][0-9]*$/.test(ids[0])) return null;
    const moduleId = Number(ids[0]);
    if (!Number.isSafeInteger(moduleId)) return null;
    return { moduleId, url: `${schoolOrigin}${assignmentPath}?id=${moduleId}` };
  } catch {
    return null;
  }
}

function samePath(left, right) {
  return process.platform === 'win32' ? left.toLowerCase() === right.toLowerCase() : left === right;
}

function sameFile(left, right) {
  return left.isFile() && right.isFile() && left.dev === right.dev && left.ino === right.ino &&
    left.size === right.size && left.mtimeNs === right.mtimeNs && left.ctimeNs === right.ctimeNs;
}

export function verifyLocalSubmissionFile(file) {
  const path = resolve(project, file.path);
  const options = { bigint: true };
  let handle;
  try {
    const before = lstatSync(path, options);
    if (!before.isFile() || !samePath(path, realpathSync(path)) || before.size <= 0n ||
      before.size > BigInt(Number.MAX_SAFE_INTEGER) ||
      (file.bytes !== undefined && before.size !== BigInt(file.bytes))) return null;
    handle = openSync(path, 'r');
    const opened = fstatSync(handle, options);
    if (!sameFile(before, opened)) return null;
    const hash = createHash('sha256');
    const buffer = Buffer.allocUnsafe(1024 * 1024);
    let remaining = opened.size;
    while (remaining > 0n) {
      const length = remaining >= BigInt(buffer.length) ? buffer.length : Number(remaining);
      const count = readSync(handle, buffer, 0, length, null);
      if (count === 0) return null;
      hash.update(buffer.subarray(0, count));
      remaining -= BigInt(count);
    }
    const matches = sameFile(opened, fstatSync(handle, options)) && sameFile(opened, lstatSync(path, options)) &&
      samePath(path, realpathSync(path)) && hash.digest('hex') === file.sha256;
    return matches ? { ...file, bytes: Number(opened.size) } : null;
  } catch {
    return null;
  } finally {
    if (handle !== undefined) closeSync(handle);
  }
}

