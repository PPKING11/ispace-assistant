import { lstatSync, readFileSync, realpathSync } from 'node:fs';
import { lstat, readFile } from 'node:fs/promises';
import { isAbsolute, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

export const projectRoot = realpathSync(fileURLToPath(new URL('../', import.meta.url)));
export const ownerFile = join(projectRoot, 'assistant-config.json');
const profileHashPattern = /^[0-9a-f]{64}$/;
const validProfile = value => typeof value === 'string' && profileHashPattern.test(value);
const validCourseId = value => Number.isSafeInteger(value) && value > 0;
const ownerError = '本次 iSpace 账号与该助手项目绑定的账号不一致';

export function ownerScope(status) {
  if (!validProfile(status?.localSyncProfileHash)) throw new Error('请连接支持本机配对的私人 iSpace 插件副本');
  const { courses, courseIds } = status;
  if (!Array.isArray(courses) || courses.length === 0 || courses.length > 12 ||
      courses.some(course => !validCourseId(course?.id) || typeof course.code !== 'string' ||
        !/^[A-Z0-9][A-Z0-9-]{0,47}$/.test(course.code)) ||
      new Set(courses.map(course => course.id)).size !== courses.length ||
      (courseIds !== undefined && (!Array.isArray(courseIds) || courseIds.length !== courses.length ||
        new Set(courseIds).size !== courses.length || courseIds.some(id => !courses.some(course => course.id === id))))) {
    throw new Error('请先在你的私人 iSpace 插件中保存要同步的课程');
  }
  return { profileHash: status.localSyncProfileHash, courses: courses.map(({ id, code }) => ({ id, code })) };
}

export function readOwnerConfig({ optional = false } = {}) {
  try {
    const metadata = lstatSync(ownerFile);
    if (!metadata.isFile() || metadata.nlink !== 1 || metadata.size > 4096) throw new Error('本机助手配置无效');
    const config = JSON.parse(readFileSync(ownerFile, 'utf8'));
    if (config?.version !== 1 || !validProfile(config.profileHash)) throw new Error('本机助手配置无效');
    return config;
  } catch (error) {
    if (error.code === 'ENOENT') {
      if (optional) return null;
      throw new Error('请先运行 setup.mjs 初始化本机助手');
    }
    throw error;
  }
}

export function assertOwner(knownHash, receivedHash) {
  if (!validProfile(knownHash) || !validProfile(receivedHash) || receivedHash !== knownHash) throw new Error(ownerError);
}

function stateDirectories() {
  const { LOCALAPPDATA: local, USERPROFILE: profile } = process.env;
  const preferred = local && isAbsolute(local) ? join(local, 'iSpaceCourseSync') : null;
  // In some managed Windows sessions LOCALAPPDATA points to the app sandbox instead of the native host.
  const native = process.platform === 'win32' && profile && isAbsolute(profile)
    ? join(profile, 'AppData', 'Local', 'iSpaceCourseSync') : null;
  return [...new Set([preferred, native].filter(Boolean))];
}

async function smallOrdinaryFile(path, maxBytes) {
  const metadata = await lstat(path);
  if (!metadata.isFile() || metadata.nlink !== 1 || metadata.size > maxBytes) throw new Error('配套下载配置文件无效');
  return (await readFile(path, 'utf8')).replace(/^\uFEFF/, '');
}

export async function nativeSettings(profileHash, stateDirectory) {
  if (!validProfile(profileHash)) throw new Error(ownerError);
  let settings;
  const candidates = stateDirectory ? [stateDirectory] : stateDirectories();
  for (const directory of candidates) {
    try {
      settings = JSON.parse(await smallOrdinaryFile(join(directory, profileHash + '.json'), 8192));
      stateDirectory = directory;
      break;
    } catch (error) {
      if (error.code !== 'ENOENT') throw new Error('下载扩展的本机配置无法读取，请在扩展里重新保存');
    }
  }
  if (settings === undefined) throw new Error('请在 Chrome 下载扩展中连接同一个 iSpace 私人副本并保存课程目录');
  const { Root: localRoot, Term: term } = settings ?? {};
  if (typeof localRoot !== 'string' || !isAbsolute(localRoot) ||
      !Number.isSafeInteger(term?.year) || term.year < 1 || term.year > 12 ||
      !Number.isSafeInteger(term?.semester) || term.semester < 1 || term.semester > 3) {
    throw new Error('下载扩展的课程目录或学期无效，请在扩展里重新保存');
  }
  try {
    const equivalent = (a, b) => process.platform === 'win32' ? a.toUpperCase() === b.toUpperCase() : a === b;
    if (!equivalent(realpathSync(localRoot), resolve(localRoot))) throw new Error();
    const marker = await smallOrdinaryFile(join(localRoot, '.ispace-course-owner'), 64);
    assertOwner(profileHash, marker);
  } catch {
    throw new Error('课程文件夹无法读取或与当前 iSpace 账号的下载配对不一致');
  }
  return { localRoot, term: { year: term.year, semester: term.semester }, profileHash, stateDirectory };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    const [command, ...extra] = process.argv.slice(2);
    if (extra.length || !['path', 'local'].includes(command)) throw new Error('用法：portable-config.mjs path | local');
    const { profileHash } = readOwnerConfig();
    const output = command === 'path' ? { projectRoot } : await nativeSettings(profileHash);
    process.stdout.write(JSON.stringify(output) + '\n');
  } catch (error) {
    process.stderr.write(JSON.stringify({ error: error.message }) + '\n');
    process.exitCode = 1;
  }
}
