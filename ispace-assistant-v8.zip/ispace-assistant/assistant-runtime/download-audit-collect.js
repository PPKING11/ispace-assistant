// Evaluate the function in functions.exec with the recipient's project and private Site tools.
async (tools, { project, readSyncStatus, readLatestItems, preview = false } = {}) => {
  if (typeof project !== 'string' || !/^(?:[A-Z]:[\\/]|\/)/i.test(project) || /[\r\n]/.test(project) ||
      typeof readSyncStatus !== 'function' || typeof readLatestItems !== 'function') {
    throw new Error('请提供解压后的助手目录绝对路径及同一个私人 iSpace 副本的两个读取工具');
  }
  const clock = Object.fromEntries(new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(new Date()).map(part => [part.type, part.value]));
  let checkId = [clock.year, clock.month, clock.day].join('-');

  async function command(cmd) {
    const run = await tools.exec_command({
      cmd: "$OutputEncoding = [Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)\n" + cmd,
      workdir: project, max_output_tokens: 16000,
    });
    if (run.exit_code !== 0) throw new Error('本机助手命令未完成，请检查初始化和文件权限');
    return JSON.parse(run.output.trim());
  }

  if (!preview) {
    const permissions = await command(String.raw`
$preferences = if (Test-Path -LiteralPath '助手设置.json') {
    Get-Content -LiteralPath '助手设置.json' -Raw | ConvertFrom-Json -ErrorAction Stop
}
$times = @($preferences.schedule.downloadDigest.times | Where-Object { $_ })
[pscustomobject]@{
    allowed=($preferences.courseDownloadMode -ne 'off' -and $preferences.reminders.downloadDigest -ne 'off' -and $preferences.permissions.backgroundReminders -ne 'ask' -and $preferences.permissions.readSchool -ne 'ask')
    defaultTimes=($times.Count -eq 0 -or ($times.Count -eq 1 -and $times[0] -eq '20:10'))
} | ConvertTo-Json -Compress
`);
    if (!permissions.allowed) return { checkId, observed: false, pending: null };
    const state = await command('node --no-warnings assistant-runtime/download-reminder.mjs pending');
    const previousDay = new Date(Date.parse(checkId + 'T00:00:00Z') - 86400000).toISOString().slice(0, 10);
    const catchUp = state.lastCheckId !== checkId && (!state.lastCompleteCheckId || state.lastCompleteCheckId < previousDay);
    const sentCompleteSummary = state.lastCompleteCheckId === checkId && state.lastSummaryCheckId === checkId && state.lastSummaryComplete;
    if (state.pending || (permissions.defaultTimes && sentCompleteSummary)) {
      return { checkId, ...state, observed: false };
    }
    const claim = await command('node --no-warnings assistant-runtime/setup-schedule.mjs claim downloadDigest' +
      (catchUp ? ' --catch-up' : ''));
    if (!claim.allowed) return { checkId, ...state, observed: false };
    checkId = claim.checkId;
  }

  async function read(tool, args, message) {
    try {
      const response = await tool(args);
      if (response?.isError) throw new Error();
      const text = response?.content?.find(part => part.type === 'text')?.text;
      const payload = typeof text === 'string' ? JSON.parse(text) : (response?.structuredContent ?? response);
      if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw new Error();
      return payload;
    } catch {
      throw new Error(message);
    }
  }

  function matchingCounts(a, b) {
    const ids = Object.keys(a ?? {});
    return ids.length > 0 && ids.length === Object.keys(b ?? {}).length && ids.every(id => a[id] === b[id]);
  }

  async function snapshotPage(offset, status) {
    const data = await read(readLatestItems, { limit: 50, offset, expectedVerifiedAt: status.lastVerifiedRead },
      'iSpace 附件清单有分页无法读取');
    const count = Math.min(50, status.itemCount - offset);
    const next = offset + count < status.itemCount ? offset + count : null;
    if (data.verified !== true || data.connection !== 'verified' || data.verifiedAt !== status.lastVerifiedRead ||
        data.total !== status.itemCount || data.nextOffset !== next || data.items?.length !== count ||
        !Array.isArray(data.items) || !matchingCounts(status.courseCounts, data.courseCounts)) {
      throw new Error('iSpace 附件清单或所选课程在检查中发生变化，请稍后重新核对');
    }
    return data;
  }

  let input;
  try {
    const status = await read(readSyncStatus, {}, '无法读取当前私人 iSpace 副本的同步状态');
    if (!/^[0-9a-f]{64}$/.test(status.localSyncProfileHash ?? '') ||
        !Array.isArray(status.courses) || !status.courses.length) {
      throw new Error('请先连接支持本机配对的私人副本并保存所选课程');
    }
    if (status.connection !== 'verified' || typeof status.lastVerifiedRead !== 'string' ||
        !Number.isSafeInteger(status.itemCount) || status.itemCount < 0 || status.itemCount > 10050) {
      throw new Error('没有取得已验证的完整 iSpace 附件清单');
    }
    const pages = [await snapshotPage(0, status)];
    for (let start = 50; start < status.itemCount; start += 200) {
      const offsets = [start, start + 50, start + 100, start + 150].filter(offset => offset < status.itemCount);
      pages.push(...await Promise.all(offsets.map(offset => snapshotPage(offset, status))));
    }
    const items = pages.flatMap(page => page.items);
    const first = pages[0];
    if (items.length !== status.itemCount ||
        new Set(items.map(item => JSON.stringify([item.courseId, item.id]))).size !== items.length) {
      throw new Error('iSpace 附件清单有缺页或重复，暂不能与本机文件对照');
    }
    input = {
      checkId, total: status.itemCount, nextOffset: null,
      syncStatus: {
        courses: status.courses.map(({ id, code }) => ({ id, code })), courseIds: status.courseIds,
        localSyncProfileHash: status.localSyncProfileHash, connection: status.connection,
        lastVerifiedRead: status.lastVerifiedRead, itemCount: status.itemCount,
      },
      verifiedAt: first.verifiedAt, verified: first.verified, freshness: first.freshness, connection: first.connection,
      items: items.map(({ courseId, id, kind, title, rawDates, rawSubmission, resourceMetadata }) => ({
        courseId, id, kind, title, rawDates: { timemodified: rawDates?.timemodified },
        rawSubmission: { settings: { teamsubmission: rawSubmission?.settings?.teamsubmission } },
        resourceMetadata: resourceMetadata && {
          moduleType: resourceMetadata.moduleType,
          resources: Array.isArray(resourceMetadata.resources) ? resourceMetadata.resources.map(resource =>
            resource?.kind === 'file' ? {
              kind: 'file', name: resource.name, fileUrl: resource.fileUrl, size: resource.size, modifiedAt: resource.modifiedAt,
            } : null) : resourceMetadata.resources,
        },
      })),
    };
  } catch (error) {
    input = { checkId, complete: false, files: [], reason: error.message };
    if (preview) return { ...input, observed: false };
  }

  const { projectRoot } = await command('node --no-warnings assistant-runtime/portable-config.mjs path');
  if (typeof projectRoot !== 'string' || /[\r\n]/.test(projectRoot)) throw new Error('助手项目路径无效');
  const file = 'assistant-runtime/.download-audit-' + Date.now() + '-' + Math.random().toString(36).slice(2) + '.json';
  const absolutePath = projectRoot.replaceAll('\\', '/') + '/' + file;
  await tools.apply_patch('*** Begin Patch\n*** Add File: ' + absolutePath + '\n+' + JSON.stringify(input) + '\n*** End Patch');
  try {
    const audit = input.complete === false
      ? "Get-Content -LiteralPath '" + file + "' -Raw -Encoding UTF8"
      : "node --no-warnings assistant-runtime/download-audit.mjs --input '" + file + "'";
    const runAudit = '$downloadAuditJson = ' + audit + '\n' +
      'if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { exit $LASTEXITCODE }\n';
    if (preview) {
      const report = await command(runAudit +
        '$downloadAuditReport = $downloadAuditJson | ConvertFrom-Json\n' +
        "$downloadSkipped = @($downloadAuditReport.files | Where-Object status -eq 'skipped' | Select-Object course,filename,reason)\n" +
        '[pscustomobject]@{complete=$downloadAuditReport.complete; reason=$downloadAuditReport.reason; totals=$downloadAuditReport.totals; skipped=$downloadSkipped} | ConvertTo-Json -Depth 5 -Compress');
      return { checkId, observed: false, ...report };
    }
    const state = await command(runAudit + '$downloadAuditJson | node --no-warnings assistant-runtime/download-reminder.mjs observe --stdin');
    return { checkId, ...state, observed: true };
  } finally {
    await tools.apply_patch('*** Begin Patch\n*** Delete File: ' + absolutePath + '\n*** End Patch');
  }
}
