import { readFileSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { setup } from './setup.mjs';
import { location, readState } from './assistant-runtime/assistant.mjs';
import { assertOwner, nativeSettings, ownerScope, readOwnerConfig } from './assistant-runtime/portable-config.mjs';
import { readAssistantPreferences } from './assistant-runtime/setup-preferences.mjs';

async function check(syncStatus) {
  const phases = {
    school: { status: 'waiting', action: '私有发布站点，使用本人学校授权，同步一次课程并在 Codex 连接站点插件' },
    archive: { status: 'waiting', action: '在 Chrome 确认配套组件已连接，保存本人课程目录和年级学期' },
    chats: { status: 'waiting', action: '在本项目创建或复用主副聊天，完成登记' },
  };
  const result = { phases, readyToRegister: false, readyForAuditPreview: false, readyForAutomation: false };
  if (process.platform !== 'win32') {
    phases.archive = { status: 'unsupported', action: '本机归档与下载核对目前需要 Windows 和 Chrome' };
  }
  if (!syncStatus) return result;

  let scope;
  let config;
  try {
    scope = ownerScope(syncStatus);
    if (syncStatus.connection !== 'verified' || syncStatus.freshness !== 'fresh' ||
        typeof syncStatus.lastVerifiedRead !== 'string' || !Number.isFinite(Date.parse(syncStatus.lastVerifiedRead))) {
      throw new Error('请在私人站点同步课程，等同步状态显示已验证且未过期后继续');
    }
    config = readOwnerConfig({ optional: true });
    if (config) assertOwner(config.profileHash, scope.profileHash);
    phases.school = { status: 'ready', courseCount: scope.courses.length, verifiedAt: syncStatus.lastVerifiedRead };
  } catch (error) {
    phases.school = { status: 'blocked', action: error instanceof SyntaxError ? '本机助手配置无效' : error.message };
    return result;
  }

  if (config) {
    const state = readState(location('state.json'));
    const mainChat = state.chats[state.mainChatId];
    const mainChatId = mainChat?.role === 'main' && mainChat.status === 'active' ? state.mainChatId : null;
    const workerChatIds = Object.values(state.chats)
      .filter(chat => chat.role === 'worker' && chat.status === 'active').map(chat => chat.id);
    phases.chats = { status: mainChatId && workerChatIds.length ? 'ready' : 'waiting', mainChatId, workerChatIds };
  }

  if ((await readAssistantPreferences()).courseDownloadMode === 'off') {
    phases.archive = { status: 'disabled', action: '已按本人设置关闭本机下载' };
    result.readyToRegister = true;
    result.readyForAutomation = phases.chats.status === 'ready';
    return result;
  }

  if (process.platform !== 'win32') return result;
  try {
    const { localRoot, term } = await nativeSettings(scope.profileHash);
    phases.archive = { status: 'ready', localRoot, term };
    result.readyToRegister = true;
    result.readyForAuditPreview = phases.chats.status === 'ready';
    result.readyForAutomation = result.readyForAuditPreview;
  } catch (error) {
    phases.archive = { status: 'blocked', action: error.message };
  }
  return result;
}

try {
  const [command, inputFlag, ...extra] = process.argv.slice(2);
  if (!['check', 'open', 'finish'].includes(command) || extra.length ||
      (command === 'check' && inputFlag !== undefined && inputFlag !== '--stdin') ||
      (command !== 'check' && inputFlag !== '--stdin')) {
    throw new Error('用法：node onboarding.mjs check [--stdin] | open --stdin | finish --stdin');
  }
  let input = {};
  if (inputFlag) {
    const raw = readFileSync(0, 'utf8');
    if (Buffer.byteLength(raw, 'utf8') > 128 * 1024) throw new Error('设置检查输入过大');
    input = JSON.parse(raw.replace(/^\uFEFF/, ''));
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('设置输入应为 JSON 对象');
  }

  let result = await check(input.syncStatus);
  if (command === 'open') {
    if (result.phases.school.status !== 'ready') throw new Error(result.phases.school.action);
    const context = { connected: true, courses: ownerScope(input.syncStatus).courses.map(course => course.code) };
    for (const key of ['autoDownloadEnabled', 'autoIntervalMinutes', 'autoDailyLimit', 'currentAcademicTerm']) {
      if (input[key] !== undefined) context[key] = input[key];
    }
    const form = fileURLToPath(new URL('./assistant-runtime/first-setup-local.mjs', import.meta.url));
    const program = spawn(process.execPath, ['--no-warnings', form, '--context-base64',
      Buffer.from(JSON.stringify(context)).toString('base64url')], { stdio: 'inherit', windowsHide: true });
    process.exitCode = await new Promise((resolve, reject) => {
      program.once('error', reject);
      program.once('close', code => resolve(code ?? 1));
    });
  } else if (command === 'finish') {
    if (result.readyToRegister && input.workerChatId) {
      setup({ mainChatId: input.mainChatId, workerChatId: input.workerChatId, syncStatus: input.syncStatus });
      result = await check(input.syncStatus);
    } else {
      result.error = '请先完成学校连接和本机下载设置，再提供实际主副聊天 ID';
      process.exitCode = 1;
    }
  }
  if (command !== 'open') process.stdout.write(JSON.stringify(result, null, 2) + '\n');
} catch (error) {
  process.stderr.write(JSON.stringify({ error: error instanceof SyntaxError ? '设置信息不是有效的 JSON' : error.message }) + '\n');
  process.exitCode = 1;
}
