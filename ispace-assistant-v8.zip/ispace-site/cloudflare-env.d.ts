declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BUCKET?: R2Bucket;
    ISPACE_OWNER_EMAIL_SHA256?: string;
    ISPACE_TOKEN?: string;
    ISPACE_COURSE_MODE?: string;
  }
}
