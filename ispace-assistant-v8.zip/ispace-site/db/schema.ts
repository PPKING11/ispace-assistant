import { sqliteTable, text, integer, primaryKey, index } from "drizzle-orm/sqlite-core";
export const ownerIdentity = sqliteTable("owner_identity", { singleton: integer("singleton").primaryKey(), ownerUserId: text("owner_user_id").notNull() });
export const syncRuns = sqliteTable("sync_runs", {
  ownerUserId: text("owner_user_id").notNull(), requestKey: text("request_key").notNull(), startedAt: text("started_at").notNull(), finishedAt: text("finished_at"), status: text("status").notNull(),
  attemptCount: integer("attempt_count").notNull().default(1), retryAllowed: integer("retry_allowed").notNull().default(0), leaseToken: text("lease_token"), leaseExpiresAt: text("lease_expires_at"),
}, table => [primaryKey({ columns: [table.ownerUserId, table.requestKey] }), index("idx_sync_runs_owner_started").on(table.ownerUserId, table.startedAt)]);
export const syncSnapshots = sqliteTable("sync_snapshots", { ownerUserId: text("owner_user_id").primaryKey(), itemsJson: text("items_json").notNull(), sourceCoverageJson: text("source_coverage_json"), itemCount: integer("item_count").notNull(), verifiedAt: text("verified_at").notNull() });

export const attachmentIndexFiles = sqliteTable("attachment_index_files", {
  ownerUserId:text("owner_user_id").notNull(), fileKey:text("file_key").notNull(), revision:text("revision").notNull(),
  status:text("status").notNull(), processedAt:text("processed_at").notNull(),
}, table=>[primaryKey({columns:[table.ownerUserId,table.fileKey]})]);

export const attachmentIndexText = sqliteTable("attachment_index_text", {
  ownerUserId:text("owner_user_id").notNull(), fileKey:text("file_key").notNull(),
  courseId:integer("course_id").notNull(), itemId:text("item_id").notNull(), resourceIndex:integer("resource_index").notNull(),
  revision:text("revision").notNull(), kind:text("kind").notNull(), page:integer("page").notNull(),
  sha256:text("sha256").notNull(), body:text("body").notNull(), normalized:text("normalized").notNull(),
  language:text("language"), updatedAt:text("updated_at").notNull(),
}, table=>[
  primaryKey({columns:[table.ownerUserId,table.fileKey,table.kind,table.page]}),
  index("idx_attachment_owner_kind_course").on(table.ownerUserId,table.kind,table.courseId),
]);

export const courseReminders = sqliteTable("course_reminders", {
  ownerUserId: text("owner_user_id").notNull(),
  eventId: text("event_id").notNull(),
  occurredAt: text("occurred_at").notNull(),
  kind: text("kind").notNull(),
  messageJson: text("message_json").notNull(),
  readAt: text("read_at"),
}, table => [
  primaryKey({ columns: [table.ownerUserId, table.eventId] }),
  index("idx_reminders_owner_occurred").on(table.ownerUserId, table.occurredAt),
]);

export const courseworkPreferences = sqliteTable("coursework_preferences", {
  ownerUserId:text("owner_user_id").primaryKey().notNull(),
  version:integer("version").notNull(),
  bodyJson:text("body_json").notNull(),
  updatedAt:text("updated_at").notNull(),
});

export const courseworkWorkspaces = sqliteTable("coursework_workspaces", {
  ownerUserId:text("owner_user_id").notNull(),
  courseId:integer("course_id").notNull(),
  itemId:text("item_id").notNull(),
  sourceVersion:text("source_version").notNull(),
  sourceJson:text("source_json").notNull(),
  verifiedAt:text("verified_at").notNull(),
  version:integer("version").notNull().default(0),
  workJson:text("work_json").notNull().default('{}'),
  updatedAt:text("updated_at").notNull(),
}, table=>[
  primaryKey({columns:[table.ownerUserId,table.courseId,table.itemId]}),
  index("idx_coursework_owner_updated").on(table.ownerUserId,table.updatedAt),
]);

export const courseProfile = sqliteTable("course_profile", {
  ownerUserId:text("owner_user_id").primaryKey().notNull(),
  sourceIdentityHash:text("source_identity_hash"),
  connectionKeyHash:text("connection_key_hash"),
  coursesJson:text("courses_json").notNull().default('[]'),
  updatedAt:text("updated_at").notNull(),
});

export const attachmentDiagnostics = sqliteTable("attachment_diagnostics", {
  ownerUserId:text("owner_user_id").notNull(),
  fileKey:text("file_key").notNull(),
  revision:text("revision").notNull(),
  sha256:text("sha256").notNull(),
  failureCode:text("failure_code"),
  totalPages:integer("total_pages"),
  pagesWithoutTextJson:text("pages_without_text_json").notNull(),
  nextPage:integer("next_page"),
  textWasShortened:integer("text_was_shortened").notNull(),
}, table=>[primaryKey({columns:[table.ownerUserId,table.fileKey]})]);

export const submissionPermits = sqliteTable("submission_permits", {
  ownerUserId:text("owner_user_id").notNull(),
  permitId:text("permit_id").notNull(),
  confirmedAt:text("confirmed_at").notNull(),
  expiresAt:text("expires_at").notNull(),
  snapshotVerifiedAt:text("snapshot_verified_at").notNull(),
  targetJson:text("target_json").notNull(),
  filesJson:text("files_json").notNull(),
}, table=>[
  primaryKey({columns:[table.ownerUserId,table.permitId]}),
  index("idx_submission_owner_confirmed").on(table.ownerUserId,table.confirmedAt),
]);
