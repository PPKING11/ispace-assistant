import { searchText } from './attachment-index.mjs';

export type IndexedFile = {
  key:string;courseId:number;itemId:string;resourceIndex:number;title:string;revision:string;image:boolean;
  resource:{kind:string;name:string;fileUrl:string;size?:number;modifiedAt?:number};
};
export type TextRow = {
  fileKey:string;courseId:number;itemId:string;resourceIndex:number;revision:string;kind:'text'|'ocr';
  sha256:string;page:number;text:string;language?:string;
};
export type FileRow = {fileKey:string;revision:string;status:string};
export type FileDiagnostics={failureCode:string|null;totalPages:number|null;pagesWithoutText:number[];nextPage:number|null;textWasShortened:boolean};
const current = 'EXISTS(SELECT 1 FROM sync_snapshots WHERE owner_user_id = ? AND verified_at = ?)';
const columns = 'file_key AS fileKey,course_id AS courseId,item_id AS itemId,resource_index AS resourceIndex,revision,kind,sha256,page';

export async function indexedFiles(db:D1Database, owner:string) {
  return (await db.prepare('SELECT file_key AS fileKey,revision,status FROM attachment_index_files WHERE owner_user_id = ?')
    .bind(owner).all<FileRow>()).results;
}

function saveText(db:D1Database, owner:string, verifiedAt:string, file:IndexedFile, row:{kind:'text'|'ocr';page:number;sha256:string;text:string;language?:string}) {
  return db.prepare(`INSERT INTO attachment_index_text (owner_user_id,file_key,course_id,item_id,resource_index,revision,kind,page,sha256,body,normalized,language,updated_at)
    SELECT ?,?,?,?,?,?,?,?,?,?,?,?,? WHERE ${current}
    ON CONFLICT(owner_user_id,file_key,kind,page) DO UPDATE SET revision=excluded.revision,sha256=excluded.sha256,
    body=excluded.body,normalized=excluded.normalized,language=excluded.language,updated_at=excluded.updated_at`)
    .bind(owner,file.key,file.courseId,file.itemId,file.resourceIndex,file.revision,row.kind,row.page,row.sha256,row.text,
      searchText(row.text),row.language??null,new Date().toISOString(),owner,verifiedAt);
}

export async function saveBrowserText(db:D1Database, owner:string, verifiedAt:string, file:IndexedFile, row:{page:number;sha256:string;text:string;language:string}) {
  return (await saveText(db,owner,verifiedAt,file,{...row,kind:'ocr'}).run()).meta.changes > 0;
}

export async function saveIndexedFile(db:D1Database, owner:string, verifiedAt:string, file:IndexedFile, status:string, sha256:string, parts:Array<{page:number;text:string}>,diagnostics?:FileDiagnostics) {
  const metadata = db.prepare(`INSERT INTO attachment_index_files (owner_user_id,file_key,revision,status,processed_at)
    SELECT ?,?,?,?,? WHERE ${current} ON CONFLICT(owner_user_id,file_key) DO UPDATE SET
    revision=excluded.revision,status=excluded.status,processed_at=excluded.processed_at`)
    .bind(owner,file.key,file.revision,status,new Date().toISOString(),owner,verifiedAt);
  const clear = db.prepare(`DELETE FROM attachment_index_text WHERE owner_user_id=? AND file_key=? AND kind='text' AND ${current}`)
    .bind(owner,file.key,owner,verifiedAt);
  const detail=diagnostics?[db.prepare(`INSERT INTO attachment_diagnostics
    (owner_user_id,file_key,revision,sha256,failure_code,total_pages,pages_without_text_json,next_page,text_was_shortened)
    SELECT ?,?,?,?,?,?,?,?,? WHERE ${current}
    ON CONFLICT(owner_user_id,file_key) DO UPDATE SET revision=excluded.revision,sha256=excluded.sha256,
    failure_code=excluded.failure_code,total_pages=excluded.total_pages,pages_without_text_json=excluded.pages_without_text_json,
    next_page=excluded.next_page,text_was_shortened=excluded.text_was_shortened`)
    .bind(owner,file.key,file.revision,sha256,diagnostics.failureCode,diagnostics.totalPages,
      JSON.stringify(diagnostics.pagesWithoutText),diagnostics.nextPage,Number(diagnostics.textWasShortened),owner,verifiedAt)]:[];
  const results=await db.batch([metadata,clear,...detail,...parts.map(part=>saveText(db,owner,verifiedAt,file,{...part,kind:'text',sha256}))]);
  return results[0].meta.changes > 0;
}

export async function indexDetails(db:D1Database,owner:string,keys:string[]) {
  if(!keys.length)return {reports:[],ocr:[]};
  const selectors=keys.map(()=>'?').join(',');
  const [reports,ocr]=await Promise.all([
    db.prepare(`SELECT file_key AS fileKey,revision,sha256,failure_code AS failureCode,total_pages AS totalPages,
      pages_without_text_json AS pagesWithoutText,next_page AS nextPage,text_was_shortened AS textWasShortened
      FROM attachment_diagnostics WHERE owner_user_id=? AND file_key IN (${selectors})`)
      .bind(owner,...keys).all<Omit<FileDiagnostics,'pagesWithoutText'|'textWasShortened'>&{
        fileKey:string;revision:string;sha256:string;pagesWithoutText:string;textWasShortened:number}>(),
    db.prepare(`SELECT file_key AS fileKey,revision,sha256,page FROM attachment_index_text
      WHERE owner_user_id=? AND kind='ocr' AND file_key IN (${selectors}) ORDER BY page LIMIT 2000`)
      .bind(owner,...keys).all<{fileKey:string;revision:string;sha256:string;page:number}>(),
  ]);
  return {reports:reports.results,ocr:ocr.results};
}

export async function previouslyVerifiedSha(db:D1Database,owner:string,file:IndexedFile,sha256:string) {
  return Boolean(await db.prepare('SELECT 1 FROM attachment_index_text WHERE owner_user_id=? AND file_key=? AND revision=? AND sha256=? LIMIT 1')
    .bind(owner,file.key,file.revision,sha256).first());
}

export async function browserTextForFile(db:D1Database,owner:string,revision:string,sha256:string,page:number,lastPage:number) {
  return (await db.prepare(`SELECT ${columns},body AS text,language FROM attachment_index_text
    WHERE owner_user_id=? AND kind='ocr' AND revision=? AND sha256=? AND page BETWEEN ? AND ?
    ORDER BY updated_at DESC LIMIT 30`).bind(owner,revision,sha256,page,lastPage).all<TextRow>()).results;
}

export async function browserDeadlineRows(db:D1Database,owner:string) {
  return (await db.prepare(`SELECT ${columns},body AS text FROM attachment_index_text
    WHERE owner_user_id=? AND kind='ocr' ORDER BY updated_at DESC LIMIT 400`).bind(owner).all<TextRow>()).results;
}

export async function findIndexedText(db:D1Database, owner:string, query:string, courseId:number|null) {
  return (await db.prepare(`SELECT ${columns},language,
    substr(normalized,max(1,instr(normalized,?)-75),325) AS text FROM attachment_index_text
    WHERE owner_user_id=? AND (? IS NULL OR course_id=?) AND instr(normalized,?)>0
    ORDER BY course_id,file_key,page,kind LIMIT 2001`).bind(query,owner,courseId,courseId,query).all<TextRow>()).results;
}
