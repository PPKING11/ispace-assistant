import { SafeError } from './sync-core.mjs';
import {
  buildCourseworkSource, courseworkExcerpts, courseworkPolicy, courseworkVersion,
  defaultCourseworkRules, emptyWork, invalidRequest, normalizedRules,
  ruleInstructions, selectCoursework, updateWork, workspaceChecklist,
  type CourseworkRules, type CourseworkSelector, type CourseworkSource, type WorkRecord,
} from './coursework-model';

type Row = {
  source_json:string; verified_at:string; version:number; work_json:string; updated_at:string;
};
type RulesRow = {body_json:string;version:number;updated_at:string};
type SavedItems = {verifiedAt:string|null;items:any[]};

function requireOwner(owner:string) {
  if(!owner)throw new SafeError('unauthenticated',401);
}
function record(row:Row):WorkRecord {
  return {
    source:JSON.parse(row.source_json),
    verifiedAt:row.verified_at,
    version:row.version,
    updatedAt:row.updated_at,
    work:{...emptyWork,...JSON.parse(row.work_json)},
  };
}
function changed() {return new SafeError('coursework_changed',409);}

export async function readCourseworkRules(db:D1Database,owner:string) {
  requireOwner(owner);
  const row=await db.prepare('SELECT body_json, version, updated_at FROM coursework_preferences WHERE owner_user_id = ?')
    .bind(owner).first<RulesRow>();
  return {rules:row?{...defaultCourseworkRules,...JSON.parse(row.body_json)} as CourseworkRules:{...defaultCourseworkRules},
    version:row?.version??0,updatedAt:row?.updated_at??null};
}
export async function saveCourseworkRules(db:D1Database,owner:string,expectedVersion:unknown,input:unknown) {
  requireOwner(owner);
  const version=courseworkVersion(expectedVersion);
  const rules=normalizedRules(input);
  const now=new Date().toISOString();
  const result=version===0
    ?await db.prepare('INSERT INTO coursework_preferences (owner_user_id, version, body_json, updated_at) VALUES (?, 1, ?, ?) ON CONFLICT DO NOTHING')
      .bind(owner,JSON.stringify(rules),now).run()
    :await db.prepare('UPDATE coursework_preferences SET version=version+1, body_json=?, updated_at=? WHERE owner_user_id=? AND version=?')
      .bind(JSON.stringify(rules),now,owner,version).run();
  if(result.meta.changes!==1)throw changed();
  return {rules,version:version+1,updatedAt:now};
}

export async function readCourseworkRecord(db:D1Database,owner:string,selector:CourseworkSelector) {
  requireOwner(owner);
  const key=selectCoursework(selector);
  const row=await db.prepare('SELECT source_json, verified_at, version, work_json, updated_at FROM coursework_workspaces WHERE owner_user_id = ? AND course_id = ? AND item_id = ?')
    .bind(owner,key.courseId,key.itemId).first<Row>();
  return row?record(row):null;
}
export async function listCoursework(db:D1Database,owner:string,offset=0,limit=24) {
  requireOwner(owner);
  if(!Number.isSafeInteger(offset)||offset<0||offset>10000||!Number.isSafeInteger(limit)||limit<1||limit>50)invalidRequest();
  const rows=await db.prepare('SELECT source_json, verified_at, version, work_json, updated_at FROM coursework_workspaces WHERE owner_user_id = ? ORDER BY updated_at DESC, course_id, item_id LIMIT ? OFFSET ?')
    .bind(owner,limit+1,offset).all<Row>();
  return {items:rows.results.slice(0,limit).map(row=>{
    const {source,work,verifiedAt,updatedAt,version}=record(row);
    return {
      courseId:source.courseId,itemId:source.itemId,title:source.title,group:source.group,dueAt:source.dueAt,
      schoolSubmission:source.schoolSubmission,stage:work.stage==='ready'&&work.draftSourceVersion!==source.sourceVersion?'in_progress':work.stage,
      verifiedAt,updatedAt,version,hasDraft:Boolean(work.draft.trim()),
    };
  }),nextOffset:rows.results.length>limit?offset+limit:null};
}

function writeSource(db:D1Database,owner:string,source:CourseworkSource,verifiedAt:string,now:string) {
  const work={...emptyWork,checklist:workspaceChecklist(emptyWork,source)};
  return db.prepare(
    'INSERT INTO coursework_workspaces (owner_user_id,course_id,item_id,source_version,source_json,verified_at,updated_at,work_json) '+
    'SELECT ?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM sync_snapshots WHERE owner_user_id=? AND verified_at=?) '+
    'ON CONFLICT(owner_user_id,course_id,item_id) DO UPDATE SET source_version=excluded.source_version,source_json=excluded.source_json,'+
    'verified_at=excluded.verified_at,'+
    'updated_at=CASE WHEN coursework_workspaces.source_version<>excluded.source_version THEN excluded.updated_at ELSE coursework_workspaces.updated_at END '+
    'WHERE coursework_workspaces.verified_at<=excluded.verified_at',
  ).bind(owner,source.courseId,source.itemId,source.sourceVersion,JSON.stringify(source),verifiedAt,now,JSON.stringify(work),owner,verifiedAt);
}

function isOpen(source:CourseworkSource,verifiedAt:string) {
  return source.schoolSubmission!=='submitted'&&(!source.dueAt||Date.parse(source.dueAt)>=Date.parse(verifiedAt));
}
export async function queueCourseworkFromSnapshot(db:D1Database,owner:string,saved:SavedItems) {
  requireOwner(owner);
  const verifiedAt=saved.verifiedAt;
  if(!verifiedAt)return {prepared:0};
  const [{rules},existing]=await Promise.all([
    readCourseworkRules(db,owner),
    db.prepare('SELECT course_id,item_id FROM coursework_workspaces WHERE owner_user_id=?')
      .bind(owner).all<{course_id:number;item_id:string}>(),
  ]);
  const keys=new Set(existing.results.map(row=>row.course_id+':'+row.item_id));
  const idOf=(source:CourseworkSource)=>source.courseId+':'+source.itemId;
  const sources=saved.items.map(item=>buildCourseworkSource(item,saved.items,verifiedAt)).filter((item):item is CourseworkSource=>Boolean(item));
  const canonicalUrls=new Set(sources.filter(source=>source.itemId.startsWith('assignment:')&&source.schoolUrl).map(source=>source.schoolUrl));
  const suitable=sources.filter(source=>keys.has(idOf(source))||
    (rules.queueNewAssignments&&isOpen(source,verifiedAt)&&!(source.itemId.startsWith('module:')&&canonicalUrls.has(source.schoolUrl))));
  const now=new Date().toISOString();
  let prepared=0;
  for(let start=0;start<suitable.length;start+=30){
    const updated=await db.batch(suitable.slice(start,start+30).map(source=>writeSource(db,owner,source,verifiedAt,now)));
    prepared+=updated.filter(result=>result.meta.changes===1).length;
  }
  return {prepared};
}

async function indexedRequirements(db:D1Database,owner:string,source:CourseworkSource){
  if(!source.attachments.length)return [];
  const selectors=source.attachments.slice(0,12);
  const conditions=selectors.map(()=>'(file_key=? AND revision=?)');
  const bindings=selectors.flatMap(file=>[source.courseId+':'+file.itemId+':'+file.resourceIndex,file.revision]);
  const rows=await db.prepare(
    'SELECT file_key,kind,page,substr(body,1,12000) AS body FROM attachment_index_text '+
    'WHERE owner_user_id=? AND course_id=? AND ('+conditions.join(' OR ')+') '+
    'AND (kind=? OR kind=?) ORDER BY page,kind LIMIT 32',
  ).bind(owner,source.courseId,...bindings,'text','ocr').all<{file_key:string;kind:string;page:number;body:string}>();
  const filename=new Map(selectors.map(file=>[source.courseId+':'+file.itemId+':'+file.resourceIndex,file.filename]));
  return rows.results.flatMap(row=>courseworkExcerpts(row.body,filename.get(row.file_key)));
}
async function requirementsFor(db:D1Database,owner:string,source:CourseworkSource) {
  const attachmentRequirements=await indexedRequirements(db,owner,source);
  const uniqueByExcerpt=new Map<string,CourseworkSource['requirements'][number]>();
  for(const entry of [...source.requirements,...attachmentRequirements]){
    if(!uniqueByExcerpt.has(entry.excerpt))uniqueByExcerpt.set(entry.excerpt,entry);
  }
  const distinct=[...uniqueByExcerpt.values()];
  return [...distinct.filter(entry=>entry.kind==='policy').slice(0,12),...distinct.filter(entry=>entry.kind!=='policy').slice(0,20)];
}
async function sourceWithRequirements(db:D1Database,owner:string,source:CourseworkSource) {
  return {...source,requirements:await requirementsFor(db,owner,source)};
}

export async function prepareCoursework(db:D1Database,owner:string,selector:CourseworkSelector,saved:SavedItems) {
  requireOwner(owner);
  const key=selectCoursework(selector);
  if(!saved.verifiedAt)throw new SafeError('connection_unverified',409);
  const found=saved.items.find(item=>item.courseId===key.courseId&&item.id===key.itemId);
  const source=buildCourseworkSource(found,saved.items,saved.verifiedAt);
  if(!source)throw new SafeError('item_not_found',404);
  const result=await writeSource(db,owner,source,saved.verifiedAt,new Date().toISOString()).run();
  if(result.meta.changes!==1)throw changed();
  return readCourseworkRecord(db,owner,key);
}

export async function saveCourseworkProgress(db:D1Database,owner:string,selector:CourseworkSelector,expectedVersion:unknown,expectedSourceVersion:unknown,patch:unknown) {
  requireOwner(owner);
  const id=selectCoursework(selector);
  const version=courseworkVersion(expectedVersion);
  if(typeof expectedSourceVersion!=='string'||!/^[a-f0-9]{64}$/.test(expectedSourceVersion))invalidRequest();
  const current=await readCourseworkRecord(db,owner,id);
  if(!current)throw new SafeError('item_not_found',404);
  if(current.version!==version||current.source.sourceVersion!==expectedSourceVersion)throw changed();
  const evidence=await sourceWithRequirements(db,owner,current.source);
  const next=updateWork(current.work,evidence,patch);
  const now=new Date().toISOString();
  const result=await db.prepare(
    'UPDATE coursework_workspaces SET version=version+1, work_json=?, updated_at=? '+
    'WHERE owner_user_id=? AND course_id=? AND item_id=? AND version=? AND source_version=? AND verified_at=? '+
    'AND EXISTS(SELECT 1 FROM sync_snapshots WHERE owner_user_id=? AND verified_at=?)',
  ).bind(JSON.stringify(next),now,owner,id.courseId,id.itemId,version,expectedSourceVersion,current.verifiedAt,owner,current.verifiedAt).run();
  if(result.meta.changes!==1)throw changed();
  return describeCoursework(db,owner,{...current,version:version+1,updatedAt:now,work:next});
}

export async function describeCoursework(db:D1Database,owner:string,current:WorkRecord) {
  requireOwner(owner);
  const [source,{rules},snapshot]=await Promise.all([
    sourceWithRequirements(db,owner,current.source),
    readCourseworkRules(db,owner),
    db.prepare('SELECT verified_at FROM sync_snapshots WHERE owner_user_id=?').bind(owner).first<{verified_at:string}>(),
  ]);
  const policy=courseworkPolicy(current.work,source);
  const sourceChangedSinceDraft=Boolean(current.work.draftSourceVersion&&current.work.draftSourceVersion!==source.sourceVersion);
  const needsReview=sourceChangedSinceDraft||current.work.draftKind==='ai_assisted'&&!policy.draftingAllowed;
  const work=current.work.stage==='ready'&&needsReview?{...current.work,stage:'in_progress' as const}:current.work;
  return {
    ...current,
    source,
    work,
    sourceCurrent:snapshot?.verified_at===current.verifiedAt,
    sourceChangedSinceDraft,
    instructions:ruleInstructions(rules),
    policy,
    checklist:work.checklist,
    untrustedCourseContent:true,
  };
}

export async function assignmentCourseworkContext(
  db:D1Database,owner:string,found:any,items:any[],verifiedAt:string,
  attachmentTexts:{filename:string;text:string}[],
) {
  const source=buildCourseworkSource(found,items,verifiedAt);
  if(!source)return null;
  const [{rules},saved]=await Promise.all([
    readCourseworkRules(db,owner),
    readCourseworkRecord(db,owner,{courseId:source.courseId,itemId:source.itemId}),
  ]);
  const work=saved?.work??emptyWork;
  const params=new URLSearchParams({courseId:String(source.courseId),itemId:source.itemId});
  return {
    instructions:ruleInstructions(rules), policy:courseworkPolicy(work,source,attachmentTexts),
    progress:saved?{stage:work.stage,role:work.role,hasDraft:Boolean(work.draft.trim()),
      version:saved.version,draftCurrent:work.draftSourceVersion===source.sourceVersion}:null,
    workspaceUrl:'/coursework?'+params,
    untrustedCourseContent:true,
  };
}
