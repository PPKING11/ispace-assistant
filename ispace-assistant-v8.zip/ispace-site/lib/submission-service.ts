import { env } from 'cloudflare:workers';
import { allSavedItems, readCourseScope } from './runtime';
import { createMoodleReader } from './moodle-reader.mjs';
import { SafeError } from './sync-core.mjs';
import {
  exactSubmissionTarget, liveSubmissionTarget, maxSubmissionFiles, parsePermitId, sameSubmissionTarget, schoolSubmissionObservation,
  submissionFiles, submissionSelector, submissionTargets, unavailableSubmissionObservation,
} from './submission-flow.mjs';

type Target = ReturnType<typeof submissionTargets>[number];
type SelectedFile = ReturnType<typeof submissionFiles>[number];
type Permit = {
  id: string; confirmedAt: string; expiresAt: string; snapshotVerifiedAt: string; target: Target; files: SelectedFile[];
};
const permitLifetime = 60 * 60 * 1000;
const submitGuidance = [
  'Use only the exact school link and logged-in school account authorized for this assignment.',
  'Before choosing files and before any school form action that may submit, check fresh school status and recheck the assignment, group impact, and state in the official Chrome page.',
  'Stop on any existing submission, unfamiliar draft, unclear state, or unresolved group conflict. An individual upload form can belong to group work.',
  'Select only local files matching the confirmed names, sizes, and SHA-256. If any detail changed, return to the private confirmation page.',
  'Use the visible iSpace form. Saving files can itself submit them. Only use a separate final-submit button if iSpace requires it and continue after matching the exact confirmed bundle.',
  'Ask the user to handle required declarations, sign-in, or verification. If iSpace does not clearly confirm receipt, inspect current status before any retry.',
];

function database() {
  if (!env.DB) throw new SafeError('storage_unavailable');
  return env.DB;
}

export async function submissionOptions(ownerId: string) {
  const [saved, scope] = await Promise.all([allSavedItems(ownerId), readCourseScope(ownerId)]);
  return { verifiedAt: saved.verifiedAt as string | null, courses: scope.courses,
    targets: submissionTargets(saved.items).filter((row: Target) => scope.courseIds.includes(row.courseId)) };
}

async function authorizedTarget(ownerId: string, source: unknown) {
  const input = submissionSelector(source);
  const [saved, scope] = await Promise.all([allSavedItems(ownerId, input.expectedVerifiedAt), readCourseScope(ownerId)]);
  if (!scope.courseIds.includes(input.courseId)) throw new SafeError('forbidden', 403);
  if (saved.verifiedAt !== input.expectedVerifiedAt) throw new SafeError('snapshot_changed', 409);
  return { target: exactSubmissionTarget(saved.items, input), scope, verifiedAt: input.expectedVerifiedAt };
}

export async function confirmSubmission(ownerId: string, input: unknown) {
  if (!input || typeof input !== 'object' || Array.isArray(input)
      || Object.keys(input).length !== 2 || !('selector' in input) || !('files' in input)) {
    throw new SafeError('invalid_request', 400);
  }
  const { target, verifiedAt } = await authorizedTarget(ownerId, input.selector);
  const files = submissionFiles(input.files);
  const id = crypto.randomUUID();
  const now = Date.now();
  const confirmedAt = new Date(now).toISOString();
  const expiresAt = new Date(now + permitLifetime).toISOString();
  const db = database();
  const results = await db.batch([
    db.prepare('DELETE FROM submission_permits WHERE owner_user_id = ? AND expires_at < ?')
      .bind(ownerId, new Date(now - 7 * 86400000).toISOString()),
    db.prepare(`INSERT INTO submission_permits
      (owner_user_id, permit_id, confirmed_at, expires_at, snapshot_verified_at, target_json, files_json)
      SELECT ?, ?, ?, ?, ?, ?, ? WHERE EXISTS (
        SELECT 1 FROM sync_snapshots WHERE owner_user_id = ? AND verified_at = ?)`)
      .bind(ownerId, id, confirmedAt, expiresAt, verifiedAt, JSON.stringify(target), JSON.stringify(files), ownerId, verifiedAt),
  ]);
  if (results[1].meta.changes !== 1) throw new SafeError('snapshot_changed', 409);
  return { status: 'confirmed_for_browser', permit: { id, confirmedAt, expiresAt, snapshotVerifiedAt: verifiedAt, target, files } satisfies Permit };
}

export async function readSubmissionPermit(ownerId: string, input: unknown) {
  if (!input || typeof input !== 'object' || Array.isArray(input)
      || Object.keys(input).length !== 1 || !('permitId' in input)) throw new SafeError('invalid_request', 400);
  const id = parsePermitId(input.permitId);
  const data = await database().prepare(`SELECT confirmed_at, expires_at, snapshot_verified_at, target_json, files_json
    FROM submission_permits WHERE owner_user_id = ? AND permit_id = ?`).bind(ownerId, id).first<{
    confirmed_at: string; expires_at: string; snapshot_verified_at: string; target_json: string; files_json: string;
  }>();
  if (!data) throw new SafeError('item_not_found', 404);
  if (Date.parse(data.expires_at) <= Date.now()) throw new SafeError('submission_confirmation_expired', 409);
  const target = JSON.parse(data.target_json) as Target;
  const [saved, scope] = await Promise.all([allSavedItems(ownerId), readCourseScope(ownerId)]);
  if (!scope.courseIds.includes(target.courseId)) throw new SafeError('forbidden', 403);
  const latest = exactSubmissionTarget(saved.items, target);
  if (!sameSubmissionTarget(target, latest)) throw new SafeError('snapshot_changed', 409);
  return { permit: { id, confirmedAt: data.confirmed_at, expiresAt: data.expires_at,
    snapshotVerifiedAt: data.snapshot_verified_at, target: latest, files: submissionFiles(JSON.parse(data.files_json)) } satisfies Permit,
    scope };
}

export async function verifySubmissionReceipt(ownerId: string, input: unknown) {
  const { permit } = await readSubmissionPermit(ownerId, input);
  const token = env.ISPACE_TOKEN;
  const courseScope = [permit.target.courseId];
  try {
    const result = await createMoodleReader({
      token, fetcher: fetch, courseScope, deadlineMs: 20000, maxCalls: 3,
      detailRead: async request => {
        const account = await request('core_webservice_get_site_info');
        if (!Number.isSafeInteger(account?.userid) || account.userid < 1) throw new SafeError('invalid_source_data');
        const functions = Array.isArray(account.functions) ? account.functions : [];
        if (!functions.some((fn: {name?: string}) => fn?.name === 'mod_assign_get_submission_status')) {
          throw new SafeError('submission_receipt_unavailable', 503);
        }
        // Previously issued permits only depended on the status function. Keep
        // that receipt available, but leave the preflight unverified when
        // this credential does not also grant the assignment listing.
        let live = null;
        if (functions.some((fn: {name?: string}) => fn?.name === 'mod_assign_get_assignments')) {
          const assignments = await request('mod_assign_get_assignments', {
            'courseids[0]': permit.target.courseId, includenotenrolledcourses: 0,
          });
          live = liveSubmissionTarget(assignments, permit.target);
        }
        const status = await request('mod_assign_get_submission_status', {
          assignid: permit.target.schoolAssignmentId, userid: account.userid,
        });
        return schoolSubmissionObservation(status, account.userid, permit, { live, secret: token });
      },
    })(courseScope);
    return { permitId: permit.id, target: permit.target, ...result };
  } catch (error) {
    if (!(error instanceof SafeError) || error.code === 'source_scope_violation') throw error;
    return { permitId: permit.id, target: permit.target,
      observation: unavailableSubmissionObservation(permit.target, new Date().toISOString()),
      receipt: { status: 'school_receipt_unavailable', errorCode: error.code, schoolUrl: permit.target.schoolUrl } };
  }
}

const selectorProperties = {
  courseId: { type: 'integer', minimum: 1 },
  itemId: { type: 'string', pattern: '^assignment:[1-9]\\d{0,14}$' },
  expectedVerifiedAt: { type: 'string', maxLength: 40 },
};
const permitSchema = {
  type: 'object', properties: { permitId: { type: 'string', format: 'uuid' } },
  required: ['permitId'], additionalProperties: false,
};
const readHints = { readOnlyHint: true, destructiveHint: false, untrustedContentHint: true };
export const submissionTools = [
  {
    name: 'prepare_ispace_submission',
    description: 'Get the official iSpace form and private confirmation page for one authorized saved assignment. Show the exact local filenames, byte sizes and SHA-256 to the user before any upload. The user selects and confirms the bundle in the private page. This tool does not authorize or upload files.',
    inputSchema: { type: 'object', properties: selectorProperties, required: Object.keys(selectorProperties), additionalProperties: false },
    annotations: { ...readHints, openWorldHint: false },
  },
  {
    name: 'read_ispace_submission_permit',
    description: 'Read an expiring, owner-authorized file manifest from the confirmation page. Verify local SHA-256 and current official form settings before using Chrome to submit exactly these files. This is local confirmation, not a school receipt. Stop on a mismatch or required student declaration.',
    inputSchema: permitSchema, annotations: { ...readHints, openWorldHint: false },
  },
  {
    name: 'verify_ispace_submission_receipt',
    description: 'Read fresh school status for the exact owner-authorized assignment before or after Chrome submission. When available, observation verifies the school target, personal or own-group scope, status, and reported file count. A missing or unverified field needs an official Chrome check. Existing submissions, unfamiliar drafts, or unresolved group impact require stopping. The receipt distinguishes matching file names and sizes from byte verification. Never upload or retry a submission.',
    inputSchema: permitSchema, annotations: { ...readHints, openWorldHint: true },
  },
];

export async function callSubmissionTool(ownerId: string, name: string, args: unknown, origin: string) {
  if (name === 'prepare_ispace_submission') {
    const { target, verifiedAt } = await authorizedTarget(ownerId, args);
    const url = new URL('/submission', origin);
    url.searchParams.set('courseId', String(target.courseId));
    url.searchParams.set('itemId', target.itemId);
    url.searchParams.set('expectedVerifiedAt', verifiedAt);
    return { status: 'awaiting_file_confirmation', target, confirmationUrl: url.href, maxFilesInConfirmation: maxSubmissionFiles,
      guidance: submitGuidance };
  }
  if (name === 'read_ispace_submission_permit') {
    const { permit } = await readSubmissionPermit(ownerId, args);
    return { status: 'confirmed_for_browser', permit, guidance: submitGuidance };
  }
  if (name === 'verify_ispace_submission_receipt') return verifySubmissionReceipt(ownerId, args);
  throw new SafeError('invalid_request', 400);
}
