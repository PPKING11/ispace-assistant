import { createHash } from 'node:crypto';
import { assignmentReviewMaterials } from './assignment-review.mjs';
import { attachmentRevision } from './attachment-index.mjs';
import { safeModuleUrl } from './course-resources.mjs';
import { learningState } from './learning-state.mjs';
import { SafeError } from './sync-core.mjs';

export const defaultCourseworkRules = {
  useCourseMaterials: true,
  answerExactQuestions: true,
  answersOnly: true,
  queueNewAssignments: true,
};

export type CourseworkRules = typeof defaultCourseworkRules;
export type CourseworkSelector = { courseId:number; itemId:string };
export type WorkStage = 'planned' | 'in_progress' | 'ready';
export type Assistance = 'unknown' | 'planning_only' | 'drafting_allowed' | 'prohibited';
export type Disclosure = 'unknown' | 'required' | 'not_required';
export type DraftFormat = 'text' | 'markdown' | 'docx' | 'python' | 'r' | 'csv';
export type DraftKind = 'personal' | 'ai_assisted';
export type CourseworkSource = CourseworkSelector & {
  title: string;
  schoolUrl: string | null;
  description: string;
  requirements: { kind:'deliverable'|'grading'|'policy'; excerpt:string; filename?:string }[];
  attachments: { itemId:string; resourceIndex:number; filename:string; relation:string; revision:string }[];
  dueAt: string | null;
  group: boolean;
  schoolSubmission: string;
  sourceVersion: string;
};
export type Work = {
  stage: WorkStage;
  role: string;
  plan: string;
  notes: string;
  checklist: { text:string; done:boolean }[];
  assistance: Assistance;
  disclosure: Disclosure;
  policySource: string;
  draft: string;
  draftKind: DraftKind;
  draftFormat: DraftFormat;
  draftSourceVersion: string | null;
};
export type WorkRecord = {
  source: CourseworkSource;
  verifiedAt: string;
  version: number;
  updatedAt: string;
  work: Work;
};

export const emptyWork: Work = {
  stage:'planned', role:'', plan:'', notes:'', checklist:[],
  assistance:'unknown', disclosure:'unknown', policySource:'',
  draft:'', draftKind:'personal', draftFormat:'docx', draftSourceVersion:null,
};

const stages = new Set<WorkStage>(['planned','in_progress','ready']);
const assistanceModes = new Set<Assistance>(['unknown','planning_only','drafting_allowed','prohibited']);
const disclosureModes = new Set<Disclosure>(['unknown','required','not_required']);
const draftFormats = new Set<DraftFormat>(['text','markdown','docx','python','r','csv']);
const draftKinds = new Set<DraftKind>(['personal','ai_assisted']);
const MISSING_POLICY = '请先核对老师对这份作业的规则，并记下依据。';
const protectedTask = /^(?:(?:class|online|in-class|midterm|final)\s+)?(?:quiz|exam(?:ination)?|test)(?=\b|\d)|^(?:课堂|期中|期末)?(?:测验|考试)|\b(?:answer\s?key|marking\s+scheme)\b|参考答案/iu;
const policyTerm = /(?:\b(?:generative\s+ai|ai\s+(?:use|usage|tools?|disclosure|declaration|assistance|generated|assisted)|chatgpt|copilot|llms?|(?:use|usage|assistance)\s+(?:of|from|by)\s+ai)\b|(?:AI|人工智能|大模型)[^。！？\n]{0,25}(?:允许|禁止|使用|声明|披露)|(?:使用|申报|披露|注明|声明)[^。！？\n]{0,30}(?:AI|人工智能|大模型))/iu;
const prohibition = /(?:\b(?:do|must|may|should)\s+not\s+(?:use|consult|rely\s+on)\b[^.!?\n]{0,50}\b(?:AI|artificial intelligence|ChatGPT|LLMs?|language models?)\b|\bno\s+(?:use\s+of\s+)?(?:generative\s+)?(?:AI|artificial intelligence|ChatGPT|LLMs?|language models?)\b[^.!?\n]{0,25}\b(?:permitted|allowed|assistance|use)\b|\b(?:AI|artificial intelligence|ChatGPT|LLMs?|language models?)\b[^.!?;\n]{0,65}\b(?:prohibited|not\s+(?:allowed|permitted))\b|(?:禁止|不得)[^。！？\n]{0,36}(?:AI|人工智能|大模型)|(?:AI|人工智能|大模型)[^。！？\n]{0,30}(?:禁止|不得))/iu;
const disclosureTerm = /\b(?:disclos\w*|declar\w*|acknowledg\w*|cite|document|report)\b|申报|披露|声明|标注|注明/iu;
const mandatoryTerm = /\b(?:must|required|shall|need to|should)\b|必须|应当|需要|须/iu;

export function invalidRequest(): never {
  throw new SafeError('invalid_request', 400);
}
export function objectValue(value:unknown): Record<string,unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) invalidRequest();
  return value as Record<string,unknown>;
}
export function selectCoursework(value:{courseId?:unknown;itemId?:unknown}):CourseworkSelector {
  if (typeof value.courseId!=='number' || !Number.isSafeInteger(value.courseId) || value.courseId<=0 ||
      typeof value.itemId!=='string' || !/^(?:assignment|module):[1-9]\d{0,14}$/u.test(value.itemId)) invalidRequest();
  return {courseId:value.courseId,itemId:value.itemId};
}
export function courseworkVersion(input: unknown): number {
  if (typeof input!=='number' || !Number.isSafeInteger(input) || input<0) invalidRequest();
  return input;
}
export function normalizedRules(value:unknown): CourseworkRules {
  const input=objectValue(value);
  if (Object.keys(input).length!==Object.keys(defaultCourseworkRules).length ||
      Object.entries(input).some(([key,value])=>!Object.hasOwn(defaultCourseworkRules,key)||typeof value!=='boolean')) invalidRequest();
  return input as CourseworkRules;
}
export function boundedText(value:unknown, max:number, trim=true):string {
  if (typeof value!=='string'||value.length>max||/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/u.test(value)) invalidRequest();
  const normalized=value.replace(/\r\n?/g,'\n');
  return trim ? normalized.trim() : normalized;
}

export function courseworkExcerpts(text:string,filename?:string): CourseworkSource['requirements'] {
  const sections=text.split(/(?:\n+|(?<=[。！？.!?])\s+(?=\p{Lu}|\p{Script=Han}))/u)
    .map(line=>line.replace(/\s+/gu,' ').trim()).filter(Boolean);
  const requirements=sections.flatMap((excerpt):CourseworkSource['requirements']=>{
    if (excerpt.length<5) return [];
    const kind = policyTerm.test(excerpt)||prohibition.test(excerpt) ? 'policy'
      : /\b(?:rubric|grad(?:e|ing)|marks?|weight|assess(?:ed|ment)\s+criteria)\b|评分|分值|占比/iu.test(excerpt) ? 'grading'
      : /\b(?:submit\w*|deliverables?|format|word\s+limit|page\s+limit|templates?|requirements?)\b|提交|格式|字数|篇幅|模板|要求/iu.test(excerpt) ? 'deliverable' : null;
    return kind ? [{kind,excerpt:excerpt.slice(0,560),...(filename?{filename}:{})}] : [];
  });
  return [...requirements.filter(entry=>entry.kind==='policy').slice(0,12),...requirements.filter(entry=>entry.kind!=='policy').slice(0,18)];
}
function schoolLink(item:any):string|null {
  const source = item.resourceMetadata?.targetUrl??item.sourceUrl;
  const moduleUrl = safeModuleUrl(source);
  if (moduleUrl) return moduleUrl;
  if (typeof source==='string' && /^https:\/\/ispace\.bnbu\.edu\.cn\/course\/view\.php\?id=[1-9]\d*$/u.test(source)) return source;
  return null;
}
function stamp(value:unknown):string|null {
  return typeof value==='number'&&Number.isSafeInteger(value)&&value>0&&value<8e12?new Date(value*1000).toISOString():null;
}

export function buildCourseworkSource(item:any,items:any[],verifiedAt?:string):CourseworkSource|null {
  if (!item || !/^(?:assignment|module):[1-9]\d{0,14}$/u.test(item.id??'') ||
      typeof item.title!=='string'||protectedTask.test(item.title)||
      (item.kind==='module'&&item.resourceMetadata?.moduleType!=='assign')) return null;
  const materials=assignmentReviewMaterials(item,items);
  if (!materials) return null;
  const attachments=materials.files.slice(0,20).map(({item,resourceIndex,relation})=>{
    const resource = item.resourceMetadata.resources[resourceIndex];
    return {itemId:item.id,resourceIndex,filename:resource.name,relation,
      revision:attachmentRevision(item,resource,verifiedAt), stableRevision:attachmentRevision(item,resource,null)};
  });
  const description=[item.description,item.resourceMetadata?.pageBody?.text].filter(Boolean).join('\n\n').slice(0,20000);
  const source = {
    courseId:item.courseId,itemId:item.id,title:item.title,schoolUrl:schoolLink(item),description,
    requirements:courseworkExcerpts(description),attachments,
    dueAt:stamp(item.rawSubmission?.attempt?.extensionduedate)??stamp(item.rawDates?.duedate),
    group:materials.isGroupWork,schoolSubmission:learningState(item).submission,
  };
  const {schoolSubmission:_,...versioned}=source;
  const sourceVersion=createHash('sha256').update(JSON.stringify({
    ...versioned, attachments:attachments.map(({revision:_,...attachment})=>attachment),
  })).digest('hex');
  return {...source,attachments:attachments.map(({stableRevision:_,...attachment})=>attachment),sourceVersion};
}

export function ruleInstructions(rules:CourseworkRules) {
  return [
    rules.useCourseMaterials&&'用户同意开始后，按题目和评分要求在同一门课查找相关讲义、幻灯片、例题或实验说明。读出作答所需的课件正文与作业附件，记录依据和仍缺的关键资料，再起草有依据的部分。',
    rules.answerExactQuestions&&'按题号及小问顺序作答，题目要求解释、举例或推导时覆盖对应部分。',
    rules.answersOnly&&'交付正文只保留题目所要求的内容。',
    '核对课程允许的协助范围。老师明确要求申报 AI 使用时，先在聊天中提醒用户。',
  ].filter((entry):entry is string=>Boolean(entry));
}

export function courseworkPolicy(work:Work, source:CourseworkSource, attachmentTexts:{filename:string;text:string}[]=[]){
  const references=[...source.requirements,...attachmentTexts.flatMap(file=>courseworkExcerpts(file.text,file.filename))];
  const policy=references.filter(row=>row.kind==='policy');
  const blockedBySource=policy.some(row=>prohibition.test(row.excerpt));
  const disclosureBySource=policy.some(row=>disclosureTerm.test(row.excerpt)&&mandatoryTerm.test(row.excerpt)&&!/\b(?:no need|not required|optional|need not)\b|无需|不用/u.test(row.excerpt.toLowerCase()));
  const disclosureRequired=work.disclosure==='required'||disclosureBySource;
  const draftingAllowed=work.assistance==='drafting_allowed'&&Boolean(work.policySource)&&!blockedBySource;
  return {
    draftingAllowed,
    disclosureRequired,
    notice: disclosureRequired?'课程要求申报 AI 使用。请在提交前按老师要求填写。':null,
    nextStep: draftingAllowed?null:MISSING_POLICY,
    evidence:policy.slice(0,8),
    references:references.slice(0,24),
  };
}

export function workspaceChecklist(work:Work,source:CourseworkSource) {
  return [
    {text:source.attachments.length?'读题目、评分要求、作业附件和相关课件':'读题目、评分要求和相关课件',done:false},
    ...(source.group?[{text:'确认本人负责的小组分工',done:Boolean(work.role)}]:[]),
    {text:'确认交付格式和课程允许的协助范围',done:work.assistance!=='unknown'&&Boolean(work.policySource)},
    {text:'逐项检查成品',done:work.stage==='ready'&&work.draftSourceVersion===source.sourceVersion},
  ];
}

export function updateWork(prior:Work,source:CourseworkSource,raw:unknown):Work{
  const patch=objectValue(raw);
  const allowed=['stage','role','plan','notes','checklist','assistance','disclosure','policySource','draft','appendDraft','draftKind','draftFormat'];
  if (!Object.keys(patch).length||Object.keys(patch).some(key=>!allowed.includes(key))||
      (Object.hasOwn(patch,'draft')&&Object.hasOwn(patch,'appendDraft'))) invalidRequest();
  const next={...prior};
  if (Object.hasOwn(patch,'stage')) {
    if (!stages.has(patch.stage as WorkStage)) invalidRequest();
    next.stage=patch.stage as WorkStage;
  }
  for(const [key,limit] of [['role',500],['plan',6000],['notes',5000],['policySource',1000]] as const){
    if (Object.hasOwn(patch,key)) next[key]=boundedText(patch[key],limit);
  }
  if (Object.hasOwn(patch,'checklist')){
    if (!Array.isArray(patch.checklist)||patch.checklist.length>30) invalidRequest();
    next.checklist=patch.checklist.map(value=>{
      const row=objectValue(value);const text=boundedText(row.text,250);
      if (!text||typeof row.done!=='boolean'||Object.keys(row).some(key=>!['text','done'].includes(key))) invalidRequest();
      return {text,done:row.done};
    });
  }
  if (Object.hasOwn(patch,'assistance')){
    if(!assistanceModes.has(patch.assistance as Assistance))invalidRequest();
    next.assistance=patch.assistance as Assistance;
  }
  if (Object.hasOwn(patch,'disclosure')){
    if(!disclosureModes.has(patch.disclosure as Disclosure))invalidRequest();
    next.disclosure=patch.disclosure as Disclosure;
  }
  if ((next.assistance!=='unknown'||next.disclosure!=='unknown')&&!next.policySource) throw new SafeError('coursework_policy_source_required',409);
  if (Object.hasOwn(patch,'draftKind')){
    if(!draftKinds.has(patch.draftKind as DraftKind))invalidRequest();
    next.draftKind=patch.draftKind as DraftKind;
  }
  if (Object.hasOwn(patch,'draftFormat')){
    if(!draftFormats.has(patch.draftFormat as DraftFormat))invalidRequest();
    next.draftFormat=patch.draftFormat as DraftFormat;
  }
  const hasDraft=Object.hasOwn(patch,'draft')||Object.hasOwn(patch,'appendDraft');
  if (hasDraft){
    if (!Object.hasOwn(patch,'draftKind')) invalidRequest();
    if (prior.draft && Object.hasOwn(patch,'appendDraft') && prior.draftKind!==next.draftKind) invalidRequest();
    if (Object.hasOwn(patch,'appendDraft')&&prior.draftSourceVersion&&prior.draftSourceVersion!==source.sourceVersion) throw new SafeError('coursework_source_changed',409);
    next.draft=Object.hasOwn(patch,'draft')?boundedText(patch.draft,60000,false):
      boundedText(prior.draft+boundedText(patch.appendDraft,60000,false),60000,false);
    next.draftSourceVersion=next.draft.trim()?source.sourceVersion:null;
  }
  const intentToDraft=(hasDraft&&next.draft.trim())||(Object.hasOwn(patch,'draftKind')&&prior.draftKind!==next.draftKind&&next.draft.trim())||patch.stage==='ready';
  if(intentToDraft&&next.draftKind==='ai_assisted'&&!courseworkPolicy(next,source).draftingAllowed) throw new SafeError('coursework_drafting_not_approved',409);
  if(patch.stage==='ready'&&(!next.draft.trim()||next.draftSourceVersion!==source.sourceVersion)) throw new SafeError('coursework_draft_required',409);
  if(next.stage==='ready'&&patch.stage!=='ready'&&(hasDraft||next.draftSourceVersion!==source.sourceVersion||next.draftKind==='ai_assisted'&&!courseworkPolicy(next,source).draftingAllowed)){
    next.stage='in_progress';
  }
  return next;
}
