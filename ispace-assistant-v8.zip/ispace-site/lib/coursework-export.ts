import { strToU8, zipSync } from 'fflate';
import type { DraftFormat, WorkRecord } from './coursework-model';

const titles:Record<DraftFormat,{extension:string;type:string}>={
  text:{extension:'txt',type:'text/plain; charset=utf-8'},
  markdown:{extension:'md',type:'text/markdown; charset=utf-8'},
  docx:{extension:'docx',type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'},
  python:{extension:'py',type:'text/plain; charset=utf-8'},
  r:{extension:'R',type:'text/plain; charset=utf-8'},
  csv:{extension:'csv',type:'text/csv; charset=utf-8'},
};
const declaration='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
const wordNamespace='http://schemas.openxmlformats.org/wordprocessingml/2006/main';
const relationshipNamespace='http://schemas.openxmlformats.org/package/2006/relationships';

function escapeXml(line:string) {
  return line.replace(/[&<>"]/g,character=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[character]!))
    .replace(/[\uFFFE\uFFFF]|[\uD800-\uDFFF]/gu,'\uFFFD');
}

function wordFile(text:string) {
  const paragraphs=text.split('\n').map(line=>
    '<w:p><w:r>'+line.split('\t').map(part=>'<w:t xml:space="preserve">'+escapeXml(part)+'</w:t>').join('<w:tab/>')+'</w:r></w:p>').join('');
  return zipSync({
    '[Content_Types].xml':strToU8(declaration+
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'+
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'+
      '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>'),
    '_rels/.rels':strToU8(declaration+'<Relationships xmlns="'+relationshipNamespace+'">'+
      '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'),
    'word/document.xml':strToU8(declaration+'<w:document xmlns:w="'+wordNamespace+'"><w:body>'+paragraphs+
      '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr></w:body></w:document>'),
  });
}

export function exportCoursework(record:WorkRecord) {
  const format=record.work.draftFormat;
  const {extension,type}=titles[format];
  const filename='coursework-'+record.source.courseId+'-'+record.source.itemId.replace(':','-')+'.'+extension;
  const body=format==='docx'?wordFile(record.work.draft):strToU8(record.work.draft);
  return {body,type,filename};
}
