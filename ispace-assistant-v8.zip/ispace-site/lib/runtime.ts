import { env, waitUntil } from "cloudflare:workers";
import { createHash } from "node:crypto";
import { COURSE_IDS, SafeError, verifyOwner, executeRefresh, digest } from "./sync-core.mjs";
import { COURSES } from './course-catalog.mjs';
import { discoverEnrolledCourses, parseSelectedCourses, selectEnrolledCourses } from './course-profile.mjs';
import { productionSource, LIVE_SOURCE_APPROVED, ADAPTER_REVISION, COVERAGE } from "./moodle-reader.mjs";
import { snapshotPage, readArguments } from "./snapshot-reader.mjs";
import { connectionState } from "./status-model.mjs";
import { parseSourceCoverage, announcementCoverage } from "./source-coverage.mjs";
import { SCHEDULE_CONFIG, scheduleStatus, scheduledSlotLookup } from "./schedule-config.mjs";
import { buildStudyPlan } from "./study-plan.mjs";
import { createSyncStore } from "./sync-store.mjs";
import { prepareReminderCommit, saveSyncFailure } from './reminder-store.mjs';
import { assignmentCourseworkContext, queueCourseworkFromSnapshot } from './coursework-store';
import { courseworkErrors, readCourseworkToolResult, writeCoursework } from './coursework-workflow';
import { RUN_TIMEOUT_MS, runStatus, snapshotFreshness } from "./sync-policy.mjs";
import {searchArguments,searchItems} from './item-search.mjs';
import {learningState} from './learning-state.mjs';
import {assignmentHelp,assignmentReviewMaterials,assignmentWorkScope} from './assignment-review.mjs';
import {visualScanUrl} from './visual-scan.mjs';
import {attachmentKey,attachmentRevision,attachmentSelectors,maxIndexedPages,ocrSubmission,searchText} from './attachment-index.mjs';
import {withOcrDeadlineEvidence} from './ocr-deadline-evidence.mjs';
import {browserDeadlineRows,browserTextForFile,findIndexedText,indexedFiles,indexDetails,previouslyVerifiedSha,saveBrowserText,saveIndexedFile,type FileDiagnostics,type IndexedFile} from './attachment-index-store';
function db(): D1Database { if (!env.DB) throw new SafeError("storage_unavailable"); return env.DB; }
export async function authorizeOwner(requestHeaders: Headers): Promise<string> {
  // Verified owner email is the bootstrap anchor; the Site-scoped ID is the durable key.
  const ownerId = await verifyOwner(requestHeaders, env.ISPACE_OWNER_EMAIL_SHA256);
  const storage = db();
  await storage.prepare("INSERT INTO owner_identity (singleton, owner_user_id) VALUES (1, ?) ON CONFLICT(singleton) DO NOTHING").bind(ownerId).run();
  const binding = await storage.prepare("SELECT owner_user_id FROM owner_identity WHERE singleton = 1").first<{ owner_user_id: string }>();
  if (!binding || binding.owner_user_id !== ownerId) throw new SafeError("forbidden", 403);
  return ownerId;
}
export const localSyncProfile = (ownerId:string) => digest(`ispace-local-sync:${ownerId}`);
const isEnrollmentMode = () => env.ISPACE_COURSE_MODE !== 'legacy';
const enrollmentProfile = (ownerId:string) => db().prepare(
  'SELECT source_identity_hash,connection_key_hash,courses_json FROM course_profile WHERE owner_user_id=?',
).bind(ownerId).first<{source_identity_hash:string;connection_key_hash:string;courses_json:string}>();
const connectionKeyHash = () => env.ISPACE_TOKEN?digest(`ispace-school-key:${env.ISPACE_TOKEN}`):Promise.resolve(null);

export async function readCourseScope(ownerId:string) {
  if(!ownerId)throw new SafeError('unauthenticated',401);
  if(!isEnrollmentMode())return {courseIds:COURSE_IDS,courses:COURSES,configured:true,enrollmentMode:false};
  const [profile,keyHash]=await Promise.all([enrollmentProfile(ownerId),connectionKeyHash()]);
  const courses=profile&&keyHash&&profile.connection_key_hash===keyHash?parseSelectedCourses(profile.courses_json):[];
  return {courseIds:courses.map((course:{id:number})=>course.id),courses,configured:Boolean(courses.length),enrollmentMode:true};
}

export async function onboardingCatalog(ownerId:string) {
  const scope=await readCourseScope(ownerId);
  if(!scope.enrollmentMode)return {scope,offers:scope.courses};
  const [profile,catalog]=await Promise.all([enrollmentProfile(ownerId),discoverEnrolledCourses(env.ISPACE_TOKEN,fetch)]);
  if(profile&&profile.source_identity_hash!==catalog.sourceIdentityHash)throw new SafeError('school_identity_changed',409);
  return {scope,offers:catalog.courses};
}

export async function saveCourseSelection(ownerId:string,input:unknown) {
  const scope=await readCourseScope(ownerId);
  if(!scope.enrollmentMode)throw new SafeError('forbidden',403);
  if(!input||typeof input!=='object'||Object.keys(input).length!==1||!('courseIds' in input))
    throw new SafeError('invalid_request',400);
  const {sourceIdentityHash,courses}=await discoverEnrolledCourses(env.ISPACE_TOKEN,fetch);
  const selected=selectEnrolledCourses(courses,input.courseIds);
  const result=await db().prepare(`INSERT INTO course_profile(owner_user_id,source_identity_hash,connection_key_hash,courses_json,updated_at)
    VALUES(?,?,?,?,?) ON CONFLICT(owner_user_id) DO UPDATE SET courses_json=excluded.courses_json,
    connection_key_hash=excluded.connection_key_hash,updated_at=excluded.updated_at
    WHERE source_identity_hash=excluded.source_identity_hash`)
    .bind(ownerId,sourceIdentityHash,await connectionKeyHash(),JSON.stringify(selected),new Date().toISOString()).run();
  if(result.meta.changes!==1)throw new SafeError('school_identity_changed',409);
  return {courses:selected};
}

function snapshotCoverage(json:string|null|undefined,ids:readonly number[]) {
  if(ids===COURSE_IDS)return parseSourceCoverage(json);
  const available=parseSourceCoverage(json,null);
  if(!available)return null;
  const selected=ids.flatMap(id=>available.filter((course:{courseId:number})=>course.courseId===id));
  return selected.length===ids.length&&ids.length?selected:null;
}
export type SyncStatus = Omit<ReturnType<typeof scheduleStatus>,'scheduleEnabled'> & {
  connection: "missing_credential" | "connection_unverified" | "verified" | "read_failed";
  freshness: string; ageSeconds: number | null; staleAfterSeconds: number; scheduleOverdue: boolean;
  lastVerifiedRead: string | null; lastAttempt: string | null; lastResult: string | null;
  adapterRevision: string; sourceEnabled: boolean; itemCount: number; courseIds: number[]; courseCounts: Record<number, number>; scheduleEnabled: boolean; scheduledTimes: string[]; scheduleConfigurationVerifiedAt: string; lastScheduledAttempt: string | null; lastScheduledResult: string | null; firstScheduledRunPending: boolean; announcementCoverage: "unverified" | "partial" | "verified"; timeZone: "Asia/Shanghai";
  courses: Array<{id:number;name:string;code:string}>;
};
export async function readStatus(ownerId: string): Promise<SyncStatus> {
  if (!ownerId) throw new SafeError("unauthenticated", 401);
  const storage = db();
  const scope=await readCourseScope(ownerId);
  const ids=scope.courseIds;
  const last = await storage.prepare("SELECT started_at, status, lease_expires_at FROM sync_runs WHERE owner_user_id = ? ORDER BY started_at DESC LIMIT 1").bind(ownerId).first<{ started_at: string; status: string; lease_expires_at: string | null }>();
  const snapshot = await storage.prepare("SELECT owner_user_id, verified_at, items_json, source_coverage_json FROM sync_snapshots WHERE owner_user_id = ?").bind(ownerId).first<{ owner_user_id: string; verified_at: string; items_json: string; source_coverage_json: string | null }>();
  const latest = snapshotPage(ownerId, snapshot, {}, ids);
  const courseCounts = latest.courseCounts;
  const sourceCoverage = snapshotCoverage(snapshot?.source_coverage_json,ids);
  const now = Date.now();
  type ScheduledRun = {request_key:string;started_at:string;finished_at:string|null;status:string;lease_expires_at:string|null};
  const [scheduled, slotRows] = await Promise.all([
    storage.prepare("SELECT request_key, started_at, finished_at, status, lease_expires_at FROM sync_runs WHERE owner_user_id = ? AND request_key LIKE 'scheduled:%' AND started_at >= ? ORDER BY started_at DESC LIMIT 1").bind(ownerId,SCHEDULE_CONFIG.confirmedAt).first<ScheduledRun>(),
    storage.prepare("SELECT request_key, started_at, finished_at, status, lease_expires_at FROM sync_runs WHERE owner_user_id = ? AND request_key IN (?, ?, ?) AND started_at >= ?").bind(ownerId,...scheduledSlotLookup(now),SCHEDULE_CONFIG.confirmedAt).all<ScheduledRun>(),
  ]);
  const scheduledState=scheduleStatus(scheduled,now,slotRows.results);
  return { adapterRevision: ADAPTER_REVISION, sourceEnabled: LIVE_SOURCE_APPROVED, connection: connectionState({hasCredential:Boolean(env.ISPACE_TOKEN), sourceEnabled:LIVE_SOURCE_APPROVED, lastVerifiedRead:latest.verifiedAt, lastResult:runStatus(last)}), lastVerifiedRead: latest.verifiedAt, itemCount: latest.total, courseCounts, lastAttempt: last?.started_at ?? null, lastResult: runStatus(last), courseIds: [...ids],courses:[...scope.courses], ...scheduledState, ...(scope.enrollmentMode?{scheduleEnabled:false,scheduledTimes:[],scheduleOverdue:false,firstScheduledRunPending:false,scheduleSlots:[],lastGraceElapsedSlot:null}:{}), ...snapshotFreshness(latest.verifiedAt,now), announcementCoverage:announcementCoverage(sourceCoverage,ids), timeZone: "Asia/Shanghai" };
}
export async function readLatestItems(ownerId: string, argumentsValue: unknown = {}) {
  if (!ownerId) throw new SafeError("unauthenticated",401);
  const {courseIds}=await readCourseScope(ownerId);
  const args = readArguments(argumentsValue as Record<string, unknown>,courseIds);
  const snapshot = await db().prepare("SELECT owner_user_id, verified_at, items_json, source_coverage_json FROM sync_snapshots WHERE owner_user_id = ?").bind(ownerId).first<{owner_user_id:string;verified_at:string;items_json:string;source_coverage_json:string|null}>();
  const sourceCoverage=snapshotCoverage(snapshot?.source_coverage_json,courseIds);
  const connection=await readStatus(ownerId);
  return {...snapshotPage(ownerId,snapshot,args,courseIds), ...snapshotFreshness(snapshot?.verified_at), lastResult:connection.lastResult,lastAttempt:connection.lastAttempt,connection:connection.connection,coverage:COVERAGE,sourceCoverage,announcementCoverage:announcementCoverage(sourceCoverage,courseIds)};
}
export async function readStudyPlan(ownerId: string) {
  const [saved,scope]=await Promise.all([allSavedItems(ownerId),readCourseScope(ownerId)]);
  if(!saved.verifiedAt)return buildStudyPlan(saved.items,saved.verifiedAt,scope.courses);
  const ocr=await browserDeadlineRows(db(),ownerId).catch(()=>[]);
  return buildStudyPlan(withOcrDeadlineEvidence(saved.items,ocr,saved.verifiedAt,env.ISPACE_TOKEN,scope.courseIds),saved.verifiedAt,scope.courses);
}
export async function refresh(ownerId: string, requestKey: string) {
  const scope=await readCourseScope(ownerId);
  if(!scope.configured)throw new SafeError('course_setup_required',409);
  const before=await allSavedItems(ownerId);
  const readSchool = productionSource(env, fetch,scope.courseIds);
  const stopAt = Date.now() + RUN_TIMEOUT_MS - 5000;
  const store=createSyncStore(db(),{prepareCommit:(storage:any,context:any)=>prepareReminderCommit(storage,context,
    (items:any[],at:string)=>buildStudyPlan(items.filter(item=>scope.courseIds.includes(item.courseId)),at,scope.courses))});
  const result=await executeRefresh({ ownerId, requestKey, store,courseIds:scope.courseIds, readSource: async (ids:any, options:any) => {
    if(scope.enrollmentMode){
      const [profile,catalog]=await Promise.all([enrollmentProfile(ownerId),discoverEnrolledCourses(env.ISPACE_TOKEN,fetch,options.signal)]);
      if(!profile||profile.source_identity_hash!==catalog.sourceIdentityHash)throw new SafeError('source_auth_failed');
      selectEnrolledCourses(catalog.courses,ids);
    }
    const school = await readSchool(ids, options);
    if (options.signal?.aborted || Date.now() >= stopAt) return school;
    try {
      const [{ addAssignmentDeadlineEvidence }, { readCourseFileBytes }, { extractCourseText }] = await Promise.all([
        import('./assignment-deadline-scan.mjs'), import('./course-download.mjs'), import('./file-content.mjs'),
      ]);
      await addAssignmentDeadlineEvidence(school.items, async (
        resource:{fileUrl:string;name:string;size?:number},
        limits:{maxBytes:number;timeoutMs:number;pageCount:number},
      ) => {
        const { bytes } = await readCourseFileBytes({ resource, token:env.ISPACE_TOKEN, maxBytes:limits.maxBytes, timeoutMs:limits.timeoutMs });
        const sha256=createHash('sha256').update(bytes).digest('hex');
        return {...await extractCourseText(bytes,resource.name,{ pageCount:limits.pageCount }),sha256};
      }, { signal:options.signal, stopAt, secret:env.ISPACE_TOKEN });
    } catch {
      // Attachment detail is supplemental to the course sync.
    }
    return school;
  } });
  if(result.duplicate)return result;
  if(result.status!=='verified'){
    await saveSyncFailure(db(),ownerId,requestKey,result).catch(()=>{});
    return result;
  }
  waitUntil(indexCourseAttachments(ownerId,{maxFiles:2}).catch(()=>{}));
  const after=await allSavedItems(ownerId);
  if(after.verifiedAt!==result.finishedAt)return {...result,changes:{status:'unknown_concurrent_refresh'}};
  waitUntil(queueCourseworkFromSnapshot(db(),ownerId,after).catch(()=>{}));
  const a=new Map(before.items.map((x:any)=>[`${x.courseId}:${x.id}`,JSON.stringify(x)]));
  const b=new Map(after.items.map((x:any)=>[`${x.courseId}:${x.id}`,JSON.stringify(x)]));
  return {...result,changes:{status:before.verifiedAt?'compared':'initial_snapshot',from:before.verifiedAt,to:after.verifiedAt,added:[...b.keys()].filter(k=>!a.has(k)),updated:[...b.keys()].filter(k=>a.has(k)&&a.get(k)!==b.get(k)),removed:[...a.keys()].filter(k=>!b.has(k)),sourceRead:scope.enrollmentMode?'selected_courses_read_atomic_cache_replacement':'selected_courses_read_atomic_cache_replacement'}};
}
export function publicError(error: unknown) {
  const status = error instanceof SafeError ? error.status : 503;
  const code = error instanceof SafeError ? error.code : "storage_unavailable";
  const messages: Record<string, string> = { unauthenticated: "请先使用拥有此应用的 ChatGPT 账户登录。", forbidden: "此页面仅供应用所有者使用。", owner_setup_missing: "所有者访问验证尚未完成。", invalid_request: "请求格式无效，请重新尝试。", storage_unavailable: "云端存储暂时不可用，请稍后再试。", snapshot_changed:"已保存的数据刚有更新，请从第一页重新读取。", file_too_large:"附件超过当前操作的大小上限。", file_size_mismatch:"学校返回的附件字节数不完整，请重试。", file_timeout:"从学校读取附件超时，请重试。" };
  const setupMessages:Record<string,string>={course_setup_required:'请在使用设置选择要同步的课程。',school_identity_changed:'学校登录与此私人副本绑定的账号不同。请为这个学校账号另开一个私人副本。',enrollment_discovery_unavailable:'学校为此账号开通的连接未提供本人选课读取。',missing_credential:'请先在此私人副本的 Sites 设置中连接本人学校账号。',source_scope_violation:'这门课不在当前账号确认的同步范围。',profile_changed:'浏览器中的账号已切换，请重新选择本机下载配置。'};
  return { status, code, message: messages[code] ?? setupMessages[code] ?? courseworkErrors[code] ?? "目前无法完成验证，请稍后再试。" };
}
export function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: { "Cache-Control": "no-store, private", "X-Content-Type-Options": "nosniff" } });
}
export async function readCoursework(ownerId:string,args:unknown){
  return readCourseworkToolResult(db(),ownerId,args);
}
export async function saveCoursework(ownerId:string,args:unknown){
  return writeCoursework(db(),ownerId,args,expected=>allSavedItems(ownerId,expected));
}

// Backward-compatible verification also exposes a bounded text preview and original link.
// It never embeds bytes; full pagination/original embedding use read_course_file.
export async function verifyCourseFile(ownerId:string,input:unknown,origin=''){
  const result=await readCourseFile(ownerId,input,origin);
  const value=JSON.parse(result.content[0].text);
  if (value.status === 'extraction_limit_exceeded') return value;
  return {...value,status:'download_verified',courseId:(input as any).courseId,itemId:(input as any).itemId,resourceIndex:(input as any).resourceIndex,verifiedAt:value.readAt};
}

export async function allSavedItems(ownerId:string,expectedVerifiedAt?:string) {
  if(!ownerId)throw new SafeError('unauthenticated',401);
  const {courseIds}=await readCourseScope(ownerId);
  const record=await db().prepare('SELECT owner_user_id, verified_at, items_json, source_coverage_json FROM sync_snapshots WHERE owner_user_id = ?').bind(ownerId).first<any>();
  const first=snapshotPage(ownerId,record,{limit:50,expectedVerifiedAt},courseIds);const items=[...first.items];
  let offset=first.nextOffset;
  while(offset!==null){const p=snapshotPage(ownerId,record,{limit:50,offset,expectedVerifiedAt:first.verifiedAt},courseIds);items.push(...p.items);offset=p.nextOffset;}
  const last=await db().prepare('SELECT status, started_at, lease_expires_at FROM sync_runs WHERE owner_user_id = ? ORDER BY started_at DESC LIMIT 1').bind(ownerId).first<any>();
  return {items,verifiedAt:first.verifiedAt,verified:first.verified,...snapshotFreshness(first.verifiedAt),lastResult:runStatus(last),announcementCoverage:announcementCoverage(snapshotCoverage(record?.source_coverage_json,courseIds),courseIds),courseIds};
}

export async function saveCourseOcr(ownerId:string,input:unknown){
  const scope=await readCourseScope(ownerId);
  const args=ocrSubmission(input,scope.courseIds);
  const saved=await allSavedItems(ownerId,args.expectedVerifiedAt);
  const file:IndexedFile|undefined=attachmentSelectors(saved.items,saved.verifiedAt,saved.courseIds).get(attachmentKey(args.courseId,args.itemId,args.resourceIndex));
  if(!file||!(/\.pdf$/i.test(file.resource.name)||file.image))throw new SafeError('file_type_unsupported',415);
  if(file.image&&args.page!==1)throw new SafeError('invalid_request',400);
  const storage=db();
  if(!await previouslyVerifiedSha(storage,ownerId,file,args.sha256)){
    const {fetchCourseFile}=await import('./course-download.mjs');
    const response=await fetchCourseFile({resource:file.resource,token:env.ISPACE_TOKEN,timeoutMs:20000});
    const expectedMime=file.image?/^image\/(?:jpeg|png)$/:/^application\/pdf$/;
    if(!response.body||!expectedMime.test(response.headers.get('content-type')??'')){
      await response.body?.cancel();
      throw new SafeError('file_type_unsupported',415);
    }
    const reader=response.body.getReader();
    const hash=createHash('sha256');
    try {
      for(;;){
        const chunk=await reader.read();
        if(chunk.done)break;
        hash.update(chunk.value);
      }
    } finally {reader.releaseLock();}
    if(hash.digest('hex')!==args.sha256)throw new SafeError('file_changed',409);
  }
  const text=withoutSourceSecret(args.text).trim();
  if(!text)throw new SafeError('invalid_request',400);
  if(!await saveBrowserText(storage,ownerId,args.expectedVerifiedAt,file,{page:args.page,sha256:args.sha256,text,language:args.language}))throw new SafeError('snapshot_changed',409);
  return {status:'saved',page:args.page,sha256:args.sha256};
}

function withoutSourceSecret(value:string){
  return env.ISPACE_TOKEN?value.split(env.ISPACE_TOKEN).join('[已隐藏]'):value;
}

function attachmentLookup(file:IndexedFile,verifiedAt:string){
  return {courseId:file.courseId,itemId:file.itemId,resourceIndex:file.resourceIndex,expectedVerifiedAt:verifiedAt};
}

export async function searchCourseAttachments(ownerId:string,input:any,origin:string){
  if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!['query','courseId','limit','offset','expectedVerifiedAt'].includes(k)))throw new SafeError('invalid_request',400);
  const {query,courseId,limit=20,offset=0,expectedVerifiedAt}=input;
  const scope=await readCourseScope(ownerId);
  if(typeof query!=='string'||query.length>120||!searchText(query)||(courseId!==undefined&&!scope.courseIds.includes(courseId))||
     !Number.isInteger(limit)||limit<1||limit>40||!Number.isInteger(offset)||offset<0||offset>2000)throw new SafeError('invalid_request',400);
  const {items,...snapshot}=await allSavedItems(ownerId,expectedVerifiedAt);
  const files:Map<string,IndexedFile>=attachmentSelectors(items,snapshot.verifiedAt,snapshot.courseIds);
  const eligible=[...files.values()].filter(file=>courseId===undefined||file.courseId===courseId);
  const [meta,matching]=await Promise.all([indexedFiles(db(),ownerId),findIndexedText(db(),ownerId,searchText(query),courseId??null)]);
  const states=new Map(meta.map(row=>[row.fileKey,row]));
  const textFiles=eligible.filter(file=>!file.image);
  const indexed=textFiles.filter(file=>states.get(file.key)?.revision===file.revision);
  const unique=new Set<string>();
  const verifiedMatches=matching.filter(row=>{
    if(files.get(row.fileKey)?.revision!==row.revision)return false;
    const key=JSON.stringify([row.courseId,row.revision,row.page,row.kind]);
    if(unique.has(key))return false;
    unique.add(key);
    return true;
  });
  const matches=verifiedMatches.slice(offset,offset+limit).flatMap(row=>{
    const file=files.get(row.fileKey);
    if(!file||!snapshot.verifiedAt)return [];
    const selector=attachmentLookup(file,snapshot.verifiedAt);
    const base=new URLSearchParams(Object.entries(selector).map(([key,value])=>[key,String(value)]));
    const page=row.page>0?row.page:null;
    const readArgs={...selector,...(page?{page,pageCount:1,expectedSha256:row.sha256}:{})};
    const full=new URLSearchParams(Object.entries({...readArgs,op:'file'}).map(([key,value])=>[key,String(value)]));
    return [{title:file.title,filename:file.resource.name,courseId:file.courseId,page,match:row.text,source:row.kind==='ocr'?'browser_ocr':'file_text',
      readArgs,readUrl:origin+'/read?'+full,scanUrl:row.kind==='ocr'?visualScanUrl(origin,base,file.resource.name,page??1,row.sha256):null}];
  });
  return {...snapshot,query,total:verifiedMatches.length,items:matches,nextOffset:offset+matches.length<verifiedMatches.length?offset+matches.length:null,
    coverage:{textFiles:textFiles.length,indexed:indexed.filter(file=>states.get(file.key)?.status==='indexed').length,
      partial:indexed.filter(file=>states.get(file.key)?.status==='partial').length,
      needsOcr:indexed.filter(file=>states.get(file.key)?.status==='needs_ocr').length,
      failed:indexed.filter(file=>states.get(file.key)?.status==='read_failed').length,
      pending:textFiles.length-indexed.length,imageFiles:eligible.length-textFiles.length,hitLimit:matching.length>2000},untrusted:true};
}

export async function indexCourseAttachments(ownerId:string,input:any){
  if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!['courseId','maxFiles','retryFailed','target'].includes(k)))throw new SafeError('invalid_request',400);
  const {courseId,maxFiles=3,retryFailed=false,target}=input;
  const scope=await readCourseScope(ownerId);
  if((courseId!==undefined&&!scope.courseIds.includes(courseId))||!Number.isInteger(maxFiles)||maxFiles<1||maxFiles>4||typeof retryFailed!=='boolean')throw new SafeError('invalid_request',400);
  if(target!==undefined&&(!target||typeof target!=='object'||Object.keys(target).some(k=>!['courseId','itemId','resourceIndex','expectedVerifiedAt'].includes(k))||
    !scope.courseIds.includes(target.courseId)||!(/^(?:assignment|module):[1-9]\d*$/).test(target.itemId)||
    !Number.isInteger(target.resourceIndex)||target.resourceIndex<0||target.resourceIndex>99||typeof target.expectedVerifiedAt!=='string'))throw new SafeError('invalid_request',400);
  const saved=await allSavedItems(ownerId,target?.expectedVerifiedAt);
  if(!saved.verifiedAt)throw new SafeError('connection_unverified',409);
  const storage=db();
  const rows=new Map((await indexedFiles(storage,ownerId)).map(row=>[row.fileKey,row]));
  const files:Map<string,IndexedFile>=attachmentSelectors(saved.items,saved.verifiedAt,saved.courseIds);
  const chosen=target&&files.get(attachmentKey(target.courseId,target.itemId,target.resourceIndex));
  if(target&&(!chosen||chosen.image))throw new SafeError('file_not_found',404);
  const pending=chosen?[chosen]:[...files.values()].filter(file=>{
    if(file.image||(courseId!==undefined&&file.courseId!==courseId))return false;
    const prior=rows.get(file.key);
    return prior?.revision!==file.revision||(retryFailed&&prior.status==='read_failed');
  });
  // Work through small items first and limit large-file pressure on the Worker.
  pending.sort((left,right)=>(left.resource.size??Infinity)-(right.resource.size??Infinity));
  const [{readCourseFileBytes,MAX_TEXT_FILE_BYTES},{extractCourseText}]=await Promise.all([import('./course-download.mjs'),import('./file-content.mjs')]);
  const stop=Date.now()+36000;
  const processed=[];
  for(const file of pending.slice(0,maxFiles)){
    const timeoutMs=Math.min(chosen?23000:10000,stop-Date.now());
    if(timeoutMs<=1000)break;
    let parts:Array<{page:number;text:string}>=[];
    let sha256='';
    let status='read_failed';
    const diagnostics:FileDiagnostics={failureCode:null,totalPages:null,pagesWithoutText:[],nextPage:null,textWasShortened:false};
    try{
      if(file.resource.size!==undefined&&file.resource.size>MAX_TEXT_FILE_BYTES)throw new SafeError('file_too_large',413);
      const {bytes}=await readCourseFileBytes({resource:file.resource,token:env.ISPACE_TOKEN,timeoutMs});
      sha256=createHash('sha256').update(bytes).digest('hex');
      const extraction=await extractCourseText(bytes,file.resource.name,{pageCount:maxIndexedPages});
      const exact=extraction.pages??[{page:0,text:extraction.text??''}];
      const limitPerPage=35000;
      parts=exact.map(part=>({page:part.page,text:withoutSourceSecret(part.text).trim().slice(0,limitPerPage)})).filter(part=>Boolean(part.text));
      diagnostics.totalPages=extraction.totalPages??null;
      diagnostics.pagesWithoutText=extraction.pages?.filter(page=>page.ocr==='may_require_ocr_or_visual_review').map(page=>page.page)??[];
      diagnostics.nextPage=extraction.nextPage??null;
      diagnostics.textWasShortened=exact.some(part=>part.text.length>limitPerPage);
      const needsOcr=diagnostics.pagesWithoutText.length>0;
      const partial=Boolean(diagnostics.nextPage||needsOcr||diagnostics.textWasShortened);
      status=extraction.status!=='text_read'?'read_failed':parts.length?(partial?'partial':'indexed'):(needsOcr?'needs_ocr':'indexed');
      if(status==='read_failed')diagnostics.failureCode=extraction.status;
    }catch(error) { diagnostics.failureCode=error instanceof SafeError?error.code:'file_extraction_failed'; }
    if(!await saveIndexedFile(storage,ownerId,saved.verifiedAt,file,status,sha256,parts,diagnostics))throw new SafeError('snapshot_changed',409);
    processed.push({courseId:file.courseId,title:file.title,filename:file.resource.name,status,pagesWithText:parts.length});
  }
  return {verifiedAt:saved.verifiedAt,processed,pending:Math.max(0,pending.length-processed.length),sourceScope:'approved_course_attachments'};
}

export async function attachmentAudit(ownerId:string,courseId:number|undefined,offset:number,expectedVerifiedAt?:string) {
  const saved=await allSavedItems(ownerId,expectedVerifiedAt);
  if((courseId!==undefined&&!saved.courseIds.includes(courseId))||!Number.isInteger(offset)||offset<0||offset>10000)throw new SafeError('invalid_request',400);
  if(!saved.verifiedAt)return {items:[],nextOffset:null,verifiedAt:null};
  const latest=new Map((await indexedFiles(db(),ownerId)).map(row=>[row.fileKey,row]));
  const candidates=[...attachmentSelectors(saved.items,saved.verifiedAt,saved.courseIds).values()].filter(file=>courseId===undefined||file.courseId===courseId)
    .map(file=>({file,status:file.image?'image':latest.get(file.key)?.revision===file.revision?latest.get(file.key)!.status:'pending'}))
    .filter(row=>row.status!=='indexed');
  const order:Record<string,number>={read_failed:0,needs_ocr:1,image:2,partial:3,pending:4};
  candidates.sort((a,b)=>(order[a.status]??9)-(order[b.status]??9)||a.file.resource.name.localeCompare(b.file.resource.name));
  const batch=candidates.slice(offset,offset+20);
  const details=await indexDetails(db(),ownerId,batch.map(row=>row.file.key));
  const rows=batch.flatMap(({file,status})=>{
    const info=details.reports.find(x=>x.fileKey===file.key&&x.revision===file.revision);
    const ocr=details.ocr.filter(x=>x.fileKey===file.key&&x.revision===file.revision&&(!info?.sha256||x.sha256===info.sha256));
    if(status==='image'&&ocr.length)return [];
    const pages: number[] = info?JSON.parse(info.pagesWithoutText):file.image?[1]:[];
    const target=attachmentLookup(file,saved.verifiedAt);
    const query=new URLSearchParams(Object.entries(target).map(([key,value])=>[key,String(value)]));
    return [{fileKey:file.key,courseId:file.courseId,filename:file.resource.name,status,info,
      unreadPages:pages.filter(page=>!ocr.some(row=>row.page===page)).slice(0,100),
      downloadUrl:'/api/files?'+query,readUrl:'/read?op=file&'+query,scanUrl:visualScanUrl('',query,file.resource.name),target}];
  });
  return {items:rows,nextOffset:offset+batch.length<candidates.length?offset+batch.length:null,verifiedAt:saved.verifiedAt};
}
export async function searchCourseItems(ownerId:string,input:unknown){
  const scope=await readCourseScope(ownerId);
  const args=searchArguments(input as any,scope.courseIds);const saved=await allSavedItems(ownerId,args.expectedVerifiedAt);
  const {items,...status}=saved;return {...status,...searchItems(items,args)};
}
export async function readCourseItem(ownerId:string,input:any,origin:string){
  const scope=await readCourseScope(ownerId);
  if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!['courseId','itemId','expectedVerifiedAt','textOffset','textLimit','includeAttachments'].includes(k))||!scope.courseIds.includes(input.courseId)||typeof input.itemId!=='string'||typeof input.expectedVerifiedAt!=='string')throw new SafeError('invalid_request',400);
  const {textOffset=0,textLimit=16000,includeAttachments=true}=input;
  if(!Number.isSafeInteger(textOffset)||textOffset<0||textOffset>200000||!Number.isSafeInteger(textLimit)||textLimit<1||textLimit>30000||typeof includeAttachments!=='boolean')throw new SafeError('invalid_request',400);
  const saved=await allSavedItems(ownerId,input.expectedVerifiedAt);const found:any=saved.items.find((x:any)=>x.courseId===input.courseId&&x.id===input.itemId);
  if(!found)throw new SafeError('item_not_found',404);
  const text=[found.description,found.resourceMetadata?.pageBody?.text,...(found.resourceMetadata?.resources??[]).filter((r:any)=>r.kind==='text').map((r:any)=>r.text)].filter(Boolean).join('\n\n');
  const {items,...status}=saved;
  const {description,resourceMetadata,...metadata}=found;
  const learning=learningState(found);
  const materials=includeAttachments&&textOffset===0?assignmentReviewMaterials(found,items):null;
  const assignmentReview=materials?await readAssignmentMaterials(ownerId,origin,found,input.expectedVerifiedAt,materials,
    { activityText:text, submissionMode:learning.mode,
      courseName:scope.courses.find(course=>course.id===found.courseId)?.name??'这门课' }):undefined;
  const coursework=assignmentReview?await assignmentCourseworkContext(db(),ownerId,found,items,input.expectedVerifiedAt,
    assignmentReview.attachments.flatMap(file=>'text' in file&&typeof file.text==='string'?[{filename:file.filename,text:file.text}]:[])):undefined;
  return {...status,item:{...metadata,resourceMetadata:resourceMetadata?{...resourceMetadata,pageBody:resourceMetadata.pageBody?{...resourceMetadata.pageBody,text:undefined}:undefined,resources:resourceMetadata.resources.map((r:any)=>r.kind==='text'?{kind:'text',textLength:r.text.length}:r)}:undefined},learningState:learning,assignmentReview,coursework,content:{status:text?'text_read':'empty_in_source_snapshot',text:text.slice(textOffset,textOffset+textLimit),totalCharacters:text.length,nextTextOffset:textOffset+textLimit<text.length?textOffset+textLimit:null,attachmentsRead:assignmentReview?.attachments.some(file=>file.hasText)??false,untrusted:true}};
}

async function readAssignmentMaterials(
  ownerId:string,origin:string,found:any,expectedVerifiedAt:string,
  materials:NonNullable<ReturnType<typeof assignmentReviewMaterials>>,
  {activityText,submissionMode,courseName}:{activityText:string;submissionMode:string;courseName:string},
){
  const deadline=Date.now()+18000;
  const pageCount=10;
  let remainingBytes=48*1024*1024;
  let attempts=0;
  const attachments=[];
  for(const {item,resourceIndex,relation} of materials.files){
    const args={courseId:item.courseId,itemId:item.id,resourceIndex,expectedVerifiedAt};
    const resource=item.resourceMetadata.resources[resourceIndex];
    const query=new URLSearchParams(Object.entries(args).map(([key,value])=>[key,String(value)]));
    const downloadUrl=origin+'/api/files?'+query;
    const reference={filename:resource.name,relation,sourceTitle:item.title,sourceUrl:item.resourceMetadata.targetUrl??item.sourceUrl,downloadUrl,readArgs:args,scanUrl:visualScanUrl(origin,query,resource.name)};
    const timeoutMs=Math.min(deadline-Date.now(),8000);
    if(attempts>=4||remainingBytes<=0||resource.size>remainingBytes||timeoutMs<=0){
      attachments.push({...reference,status:'deferred',hasText:false});
      continue;
    }
    attempts++;
    try{
      const result=await readCourseFile(ownerId,{...args,pageCount,textLimit:8000},origin,{maxBytes:remainingBytes,timeoutMs});
      const file=JSON.parse(result.content[0].text);
      const extraction=file.extraction;
      remainingBytes-=file.bytes??0;
      const visualReviewPages=(extraction.pages??[]).filter((page:any)=>page.ocr==='may_require_ocr_or_visual_review').map((page:any)=>page.page);
      const hasText=extraction.status==='text_read'&&Boolean(extraction.pages
        ? extraction.pages.some((page:any)=>page.textCharacters>0)
        : extraction.text?.trim());
      const nextText=extraction.nextTextOffset!=null?{...args,page:1,pageCount,textOffset:extraction.nextTextOffset,expectedSha256:file.sha256}:null;
      const nextPages=extraction.nextPage!=null?{...args,page:extraction.nextPage,pageCount,expectedSha256:file.sha256}:null;
      const status=hasText
        ? (visualReviewPages.length||nextText||nextPages||extraction.textTruncated?'partial':'read')
        : (visualReviewPages.length||extraction.status==='browser_image_review'?'visual_review':'not_read');
      attachments.push({...reference,status,hasText,scanUrl:file.scanUrl??reference.scanUrl,extractionStatus:extraction.status,
        text:hasText?extraction.text:undefined,totalPages:extraction.totalPages,
        visualReviewPages,limitations:extraction.limitations,nextText,nextPages});
    }catch(error){
      if(error instanceof SafeError&&error.code==='snapshot_changed')throw error;
      remainingBytes-=resource.size>0?resource.size:remainingBytes;
      attachments.push({...reference,status:'not_read',hasText:false,errorCode:publicError(error).code});
    }
  }
  const due=[found.rawSubmission?.attempt?.extensionduedate,found.rawDates?.duedate]
    .find(value=>Number.isSafeInteger(value)&&value>0&&value<8e12);
  const work=assignmentWorkScope(activityText,materials.isGroupWork,attachments);
  return {...work,submissionMode,
    dueAt:due?new Date(due*1000).toISOString():null,timeZone:'Asia/Shanghai',
    attachments,help:assignmentHelp(work.workScope,courseName,found.title),untrusted:true};
}
export async function readOwnRecords(ownerId:string,input:any){
  const scope=await readCourseScope(ownerId);
  if(!input||typeof input!=='object'||Object.keys(input).some(k=>k!=='courseId')||!scope.courseIds.includes(input.courseId))throw new SafeError('invalid_request',400);
  const {ownRecords}=await import('./own-records.mjs');return ownRecords({courseId:input.courseId,token:env.ISPACE_TOKEN,fetcher:fetch,courseScope:scope.courseIds});
}
export async function readCourseFile(ownerId:string,input:any,origin:string,batchLimits?:{maxBytes:number;timeoutMs:number}){
  if(!ownerId)throw new SafeError('unauthenticated',401);
  if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!['courseId','itemId','resourceIndex','expectedVerifiedAt','page','pageCount','textOffset','textLimit','expectedSha256','includeOriginal','byteOffset'].includes(k)))throw new SafeError('invalid_request',400);
  const {page=1,pageCount=3,textOffset=0,textLimit=16000,expectedSha256,includeOriginal=false,byteOffset,...selector}=input;
  if(!Number.isSafeInteger(page)||page<1||page>2000||!Number.isSafeInteger(pageCount)||pageCount<1||pageCount>10||!Number.isSafeInteger(textOffset)||textOffset<0||textOffset>2000000||!Number.isSafeInteger(textLimit)||textLimit<1||textLimit>30000||typeof includeOriginal!=='boolean'||expectedSha256!==undefined&&!/^[a-f0-9]{64}$/.test(expectedSha256)||((page>1||textOffset>0)&&!expectedSha256))throw new SafeError('invalid_request',400);
  if(byteOffset!==undefined&&(!Number.isSafeInteger(byteOffset)||byteOffset<0||byteOffset>=48*1024*1024||
    (byteOffset>0&&!expectedSha256)||includeOriginal||input.textOffset!==undefined||input.textLimit!==undefined||
    input.page!==undefined||input.pageCount!==undefined)) throw new SafeError('invalid_request',400);
  const {downloadArguments,selectDownload,readCourseFileBytes,MAX_TEXT_FILE_BYTES,csvResource,csvByteChunk,csvPageByteOffset}=await import('./course-download.mjs');
  const scope=await readCourseScope(ownerId);
  const query=new URLSearchParams(Object.entries(selector).map(([k,v])=>[k,String(v)]));const args=downloadArguments(query,scope.courseIds);
  const resource=await selectDownload({ownerId,args,readPage:readLatestItems});
  const downloadUrl=`${origin}/api/files?${query}`;
  const rangeOffset=byteOffset??csvPageByteOffset(resource,input);
  if(byteOffset!==undefined&&!csvResource(resource.name,resource.fileUrl)) throw new SafeError('invalid_request',400);
  if (resource.size > MAX_TEXT_FILE_BYTES) {
    if (expectedSha256) throw new SafeError('file_too_large', 413);
    return {isError:true, content:[{type:'text',text:JSON.stringify({
      status:'extraction_limit_exceeded', filename:resource.name, downloadUrl,
      scanUrl:visualScanUrl(origin,query,resource.name,page),
      sizeFromSnapshot:resource.size, maxTextFileBytes:MAX_TEXT_FILE_BYTES,
      note:'This file can be downloaded through the private link. No file bytes or text were read.',
      extraction:{status:'not_read_size_limit',nextTextOffset:null},
    })}]};
  }
  const {bytes,mediaType}=await readCourseFileBytes({resource,token:env.ISPACE_TOKEN,fetcher:fetch,...batchLimits});
  const byteCount=bytes.byteLength;
  const sha256=createHash('sha256').update(bytes).digest('hex');
  if(expectedSha256&&expectedSha256!==sha256)throw new SafeError('file_changed',409);
  function asResource(data:Uint8Array,uri:string,mimeType:string){
    let binary='';for(let i=0;i<data.byteLength;i+=8192)binary+=String.fromCharCode(...data.subarray(i,i+8192));
    return {type:'resource',resource:{uri,mimeType,blob:btoa(binary)}};
  }
  if(rangeOffset!==undefined){
    if(mediaType!=='text/csv') throw new SafeError('file_type_unsupported',415);
    const {part,nextByteOffset}=csvByteChunk(bytes,rangeOffset);
    const range={status:'file_chunk_read',filename:resource.name,bytes:byteCount,mediaType,sha256,byteOffset:rangeOffset,chunkBytes:part.byteLength,nextByteOffset,snapshotVerifiedAt:args.expectedVerifiedAt,downloadUrl,untrusted:true};
    return {content:[{type:'text',text:JSON.stringify(range)},asResource(part,`${downloadUrl}#byte=${rangeOffset}-${rangeOffset+part.byteLength-1}`,mediaType)],isError:false};
  }
  let extraction:any;
  const embedOriginal=includeOriginal&&byteCount<=2*1024*1024;
  // PDF.js owns its input and may transfer the buffer. Keep a copy only for inline originals.
  try{
    if (mediaType==='image/png'||mediaType==='image/jpeg') extraction={status:'browser_image_review',format:mediaType.split('/')[1]};
    else {const {extractCourseText}=await import('./file-content.mjs');extraction=await extractCourseText(embedOriginal?bytes.slice():bytes,resource.name,{page,pageCount});}
  }
  catch(e){if(e instanceof SafeError)throw e;extraction={status:'extraction_failed',ocr:'unknown',note:'Original file downloaded successfully; text extraction failed, so no content success is claimed.'};}
  if(extraction.pages||extraction.status==='browser_image_review'){
    const saved=await allSavedItems(ownerId,args.expectedVerifiedAt);
    const item=saved.items.find((entry:any)=>entry.courseId===args.courseId&&entry.id===args.itemId);
    const revision=attachmentRevision(item,resource,args.expectedVerifiedAt);
    const ocr=await browserTextForFile(db(),ownerId,revision,sha256,page,page+pageCount-1).catch(()=>[]);
    if(ocr.length){
      const byPage=new Map<number,string>();
      for(const row of ocr)if(!byPage.has(row.page))byPage.set(row.page,row.text);
      if(extraction.pages){
        extraction.pages=extraction.pages.map((part:any)=>{
          const recognized=byPage.get(part.page);
          return recognized&&part.ocr==='may_require_ocr_or_visual_review'?{...part,text:recognized,ocr:'browser_ocr_text'}:part;
        });
      }else if(byPage.has(1)){
        extraction={...extraction,status:'text_read',text:byPage.get(1),ocr:'browser_ocr_text'};
      }
      extraction.ocrPages=[...byPage.keys()];
    }
  }
  const fullText=extraction.text??extraction.pages?.map((p:any)=>`[Page ${p.page}]\n${p.text}`).join('\n\n')??'';
  const {text,pages,...extractionMeta}=extraction;
  const nextTextOffset=textOffset+textLimit<fullText.length && textOffset+textLimit<=2000000
    ? textOffset+textLimit:null;
  const textTruncated=textOffset+textLimit<fullText.length&&nextTextOffset===null;
  const mime=resource.name.toLowerCase().endsWith('.docx')?'application/vnd.openxmlformats-officedocument.wordprocessingml.document':resource.name.toLowerCase().endsWith('.pptx')?'application/vnd.openxmlformats-officedocument.presentationml.presentation':resource.name.toLowerCase().endsWith('.ppt')?'application/vnd.ms-powerpoint':resource.name.toLowerCase().endsWith('.doc')?'application/msword':mediaType??'application/octet-stream';
  const visualPage=pages?.find((entry:any)=>entry.ocr==='may_require_ocr_or_visual_review')?.page??page;
  const scanUrl=visualScanUrl(origin,query,resource.name,visualPage,sha256);
  const result:any={status:'file_downloaded',filename:resource.name,bytes:byteCount,mediaType:mime,sha256,snapshotVerifiedAt:args.expectedVerifiedAt,...snapshotFreshness(args.expectedVerifiedAt),readAt:new Date().toISOString(),downloadUrl,scanUrl,sourceUrl:resource.fileUrl,extraction:{...extractionMeta,pages:pages?.map(({text,...p}:any)=>({...p,textCharacters:text.length})),text:fullText.slice(textOffset,textOffset+textLimit),totalCharacters:fullText.length,nextTextOffset,...(textTruncated?{textTruncated:true}:{})},untrusted:true};
  const content:any[]=[{type:'text',text:JSON.stringify(result)},{type:'resource_link',uri:downloadUrl,name:resource.name,mimeType:mime,size:byteCount,description:'Owner-authenticated original file; school token is never included. Refresh the selector if snapshot changes.'}];
  if(embedOriginal)content.push(asResource(bytes,downloadUrl,mime));
  else if(includeOriginal)content.push({type:'text',text:'Original exceeds the 2 MiB inline limit; use the authenticated download link.'});
  return {content,isError:false};
}
