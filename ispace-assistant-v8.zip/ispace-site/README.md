# iSpace 私人副本安装说明

本包面向北师香港浸会大学 iSpace 用户。每个同学用自己的 ChatGPT 账户创建一个私有 Sites，连接自己的学校账户。课程快照、作业记录和文件设置保存在各自的副本里。

## 1. 创建和连接

1. 在 Codex 中打开解压后的 `ispace-site`，使用官方 Sites 插件为该目录创建自己的站点。创建后核对 `.openai/hosting.json` 中的 `project_id` 是新站点的 ID，并保留模板中的 `DB` 数据库绑定和 `mcp` 能力。确认站点仅限所有者访问。
2. 让 Codex 按 Sites 插件返回的源仓库信息提交和推送 `ispace-site` 源码。通过 Sites 保存该提交对应的版本并私有部署。部署完成后记下 Sites 返回的网址。
3. 在 Sites 列表中找到该站点，打开「更多操作 → 设置」，填写下列运行值。学校凭据须由学校正式提供并允许用于本人课程读取。请在设置的 Secret 字段输入学校令牌。
   - ISPACE_COURSE_MODE 填 enrolled。
   - ISPACE_OWNER_EMAIL_SHA256 填该 Site 登录邮箱去掉两端空格、转小写后的 SHA-256。
   - ISPACE_TOKEN 填学校为本人正式开通的 Moodle/iSpace 服务 token。
4. 按 Sites 设置提示重新部署。使用创建站点时的 ChatGPT 账号登录，再访问自己站点的 `/setup`。检查课程列表，选择要同步的课，打开「同步状态」并进行一次读取。学校未开放本人选课查询时，设置页会显示相应原因。
5. 在 Codex 中连接该站点生成的 MCP 插件。先读取课程列表或同步状态，确认对应的是自己的私人副本，并核对最近一次同步成功。

如需在本机计算邮箱哈希，下列命令会读取下一行终端输入。输入在 Sites 使用的邮箱，按回车。它只输出 SHA-256，学校 token 仍通过正式 Sites 设置另行配置。

    node -e "require('node:readline').createInterface({input:process.stdin}).once('line',email=>{console.log(require('node:crypto').createHash('sha256').update(email.trim().toLowerCase()).digest('hex'));process.exit(0)})"

[官方 Sites 发布说明](https://learn.chatgpt.com/docs/sites/publishing-and-sharing) · [官方 Sites 运行设置](https://learn.chatgpt.com/docs/sites/managing-a-site#configure-runtime-environment-values)

## 2. 可选的本机自动下载

1. 在站点打开「使用设置」。页面会检查是否有配套的本机下载组件。需要安装时，可以点击「查看所需组件」，安装并关联站点后点击「重新检查」。
2. 安装包如果含有 ispace-course-local，请阅读其中的 README。当前配套件是 Windows 与 Chrome 的开发分发包，需从可信来源确认包后自行安装。
3. 在 Chrome 扩展里设置你自己的私有 Sites 地址并登录。可以选择桌面的 Course 文件夹、自定路径或沿用现有目录。核对英文年级和学期，保存设置后用「试下载一份课件」验收，再按需选择「立即下载」或开启自动下载。
4. 自动下载依赖 Chrome 保持运行和学校资料可读取。电脑离线期间积累的新文件会在下一次可用的检查中继续处理。

目录层级为 Course / Year 2 Semester 1 / 课程缩写 / 文件类型。Year 2 Semester 1 是大二上的例子。作业、课件、小组项目和实验资料分别归档。

独立副本的同步可在「同步状态」中手动触发。是否启用云端定时同步由副本所有者在本人账户中另行设置。作业草稿和进度可以在作业工作台保留，提交前请核对学校设置、要交的文件及回执。

## 3. Codex 一站式设置

在桌面版 Codex 中打开与此目录同级的 [ispace-assistant](../ispace-assistant/README.md)，按向导核对私人站点、配套组件、下载目录、聊天和后台提醒。
