CREATE TABLE `owner_identity` (
	`singleton` integer PRIMARY KEY NOT NULL,
	`owner_user_id` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `sync_runs` (
	`owner_user_id` text NOT NULL,
	`request_key` text NOT NULL,
	`started_at` text NOT NULL,
	`finished_at` text,
	`status` text NOT NULL,
	PRIMARY KEY(`owner_user_id`, `request_key`)
);
--> statement-breakpoint
CREATE INDEX `idx_sync_runs_owner_started` ON `sync_runs` (`owner_user_id`,`started_at`);--> statement-breakpoint
CREATE TABLE `sync_snapshots` (
	`owner_user_id` text PRIMARY KEY NOT NULL,
	`items_json` text NOT NULL,
	`item_count` integer NOT NULL,
	`verified_at` text NOT NULL
);
