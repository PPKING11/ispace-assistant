CREATE TABLE `attachment_index_files` (
	`owner_user_id` text NOT NULL,
	`file_key` text NOT NULL,
	`revision` text NOT NULL,
	`status` text NOT NULL,
	`processed_at` text NOT NULL,
	PRIMARY KEY(`owner_user_id`, `file_key`)
);
--> statement-breakpoint
CREATE TABLE `attachment_index_text` (
	`owner_user_id` text NOT NULL,
	`file_key` text NOT NULL,
	`course_id` integer NOT NULL,
	`item_id` text NOT NULL,
	`resource_index` integer NOT NULL,
	`revision` text NOT NULL,
	`kind` text NOT NULL,
	`page` integer NOT NULL,
	`sha256` text NOT NULL,
	`body` text NOT NULL,
	`normalized` text NOT NULL,
	`language` text,
	`updated_at` text NOT NULL,
	PRIMARY KEY(`owner_user_id`, `file_key`, `kind`, `page`)
);
--> statement-breakpoint
CREATE INDEX `idx_attachment_owner_kind_course` ON `attachment_index_text` (`owner_user_id`,`kind`,`course_id`);