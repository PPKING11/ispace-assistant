ALTER TABLE `sync_runs` ADD `attempt_count` integer DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `sync_runs` ADD `lease_token` text;--> statement-breakpoint
ALTER TABLE `sync_runs` ADD `lease_expires_at` text;