CREATE TABLE `course_reminders` (
	`owner_user_id` text NOT NULL,
	`event_id` text NOT NULL,
	`occurred_at` text NOT NULL,
	`kind` text NOT NULL,
	`message_json` text NOT NULL,
	`read_at` text,
	PRIMARY KEY(`owner_user_id`, `event_id`)
);
--> statement-breakpoint
CREATE INDEX `idx_reminders_owner_occurred` ON `course_reminders` (`owner_user_id`,`occurred_at`);