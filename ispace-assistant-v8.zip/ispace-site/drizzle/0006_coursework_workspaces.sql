CREATE TABLE `coursework_preferences` (
	`owner_user_id` text PRIMARY KEY NOT NULL,
	`version` integer NOT NULL,
	`body_json` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `coursework_workspaces` (
	`owner_user_id` text NOT NULL,
	`course_id` integer NOT NULL,
	`item_id` text NOT NULL,
	`source_version` text NOT NULL,
	`source_json` text NOT NULL,
	`verified_at` text NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`work_json` text DEFAULT '{}' NOT NULL,
	`updated_at` text NOT NULL,
	PRIMARY KEY(`owner_user_id`, `course_id`, `item_id`)
);
--> statement-breakpoint
CREATE INDEX `idx_coursework_owner_updated` ON `coursework_workspaces` (`owner_user_id`,`updated_at`);