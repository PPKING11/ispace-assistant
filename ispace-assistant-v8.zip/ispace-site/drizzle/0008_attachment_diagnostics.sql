CREATE TABLE `attachment_diagnostics` (
	`owner_user_id` text NOT NULL,
	`file_key` text NOT NULL,
	`revision` text NOT NULL,
	`sha256` text NOT NULL,
	`failure_code` text,
	`total_pages` integer,
	`pages_without_text_json` text NOT NULL,
	`next_page` integer,
	`text_was_shortened` integer NOT NULL,
	PRIMARY KEY(`owner_user_id`, `file_key`)
);
