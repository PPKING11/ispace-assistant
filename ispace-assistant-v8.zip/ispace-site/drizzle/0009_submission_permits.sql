CREATE TABLE `submission_permits` (
	`owner_user_id` text NOT NULL,
	`permit_id` text NOT NULL,
	`confirmed_at` text NOT NULL,
	`expires_at` text NOT NULL,
	`snapshot_verified_at` text NOT NULL,
	`target_json` text NOT NULL,
	`files_json` text NOT NULL,
	PRIMARY KEY(`owner_user_id`, `permit_id`)
);
--> statement-breakpoint
CREATE INDEX `idx_submission_owner_confirmed` ON `submission_permits` (`owner_user_id`,`confirmed_at`);