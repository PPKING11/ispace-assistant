CREATE TABLE `course_profile` (
	`owner_user_id` text PRIMARY KEY NOT NULL,
	`source_identity_hash` text,
	`connection_key_hash` text,
	`courses_json` text DEFAULT '[]' NOT NULL,
	`updated_at` text NOT NULL
);
