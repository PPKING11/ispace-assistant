"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ShieldCheck, CalendarClock, CirclePause, RotateCw, BookOpen, LockKeyhole } from "lucide-react";
import type { SyncStatus } from "@/lib/runtime";
import { statusCopy, refreshFeedback } from "@/lib/status-model.mjs";

const formatTime = (value: string | null) => value ? new Intl.DateTimeFormat("zh-CN", { timeZone: "Asia/Shanghai", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(new Date(value)) : "尚未验证";

const slotLabels: Record<string, string> = {
  pending: "尚未到时间",
  awaiting_record: "等待同步记录",
  not_recorded: "未见同步记录",
  verified: "同步成功",
  running: "正在同步",
  failed: "同步失败",
  interrupted: "同步中断",
};

function ScheduledRun({ slot, label }: { slot: SyncStatus["scheduleSlots"][number]; label: string }) {
  const timestamp = slot.finishedAt ?? slot.startedAt;
  const timeLabel = slot.finishedAt ? "完成于" : "开始于";
  return <p><b>{label} {slot.time}</b> · {slotLabels[slot.status]}{timestamp && <span>（{timeLabel} {formatTime(timestamp)}）</span>}</p>;
}

export default function Dashboard({ initial }: { initial: SyncStatus }) {
  const [status, setStatus] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState("");
  const copy=statusCopy(status);
  const courseNames:Record<number,string>=Object.fromEntries(status.courses.map(course=>[course.id,course.name]));
  async function read() {
    const response = await fetch("/api/status", { cache: "no-store" });
    const value = await response.json() as SyncStatus & { message?: string };
    if (!response.ok) throw new Error(value.message || "暂时无法读取状态，请稍后再试。");
    setStatus(value); return value;
  }
  async function check() {
    setBusy(true); setFeedback("");
    try {
      const response = await fetch("/api/refresh", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ requestKey: `manual:${crypto.randomUUID()}` }) });
      const value = await response.json() as { status?: string; message?: string };
      if (!response.ok) throw new Error(value.message || "验证暂时不可用。");
      const fresh=await read();
      setFeedback(refreshFeedback(value.status,Boolean(fresh.lastVerifiedRead)));
      return value;
    } catch (error) { setFeedback(error instanceof Error ? error.message : "验证暂时不可用。"); throw error; }
    finally { setBusy(false); }
  }
  useEffect(() => {
    const context = (document as Document & { modelContext?: { registerTool: (tool: unknown, options: { signal: AbortSignal }) => unknown } }).modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    try {
      Promise.resolve(context.registerTool({ name: "read_sync_status", title: "查看同步状态", description: "Read the owner's connection and verified-read status without credentials.", inputSchema: { type: "object", properties: {}, additionalProperties: false }, annotations: { readOnlyHint: true, untrustedContentHint: false }, execute: async (input: unknown) => { if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).length) throw new Error("Invalid input"); return read(); } }, { signal: lifecycle.signal })).catch(() => {});
    } catch { /* Browser integration is optional; normal controls remain available. */ }
    return () => lifecycle.abort();
  }, []);
  return <main className="shell">
    <header className="masthead"><div className="wordmark"><span className="brand">iSpace</span><span className="private-label">私有同步</span></div><span className="owner-badge"><ShieldCheck size={17} aria-hidden="true" />仅限本人</span></header>
    <nav className="study-nav"><Link href="/">作业与考试</Link><Link href="/sync" aria-current="page">同步状态</Link><Link href="/files">课程附件</Link></nav>
    <section className="connection-panel" aria-labelledby="connection-title">
      <div className="connection-heading"><span className="icon-tile"><LockKeyhole size={25} aria-hidden="true" /></span><span className="status-pill">{copy.badge}</span></div>
      <h1 id="connection-title">{copy.title}</h1>
      <p className="intro">{copy.intro}</p>
      <div className="action-row"><Button size="lg" onClick={() => { void check().catch(() => {}); }} disabled={busy} className="check-button"><RotateCw size={17} className={busy ? "spin" : ""} aria-hidden="true" />{busy ? "正在检查" : "检查连接状态"}</Button><span className="quiet-note">此步骤不会向学校提交内容</span></div>
      <p className="feedback" aria-live="polite">{feedback}</p>
    </section>
    <section className="summary-grid" aria-label="同步概览">
      <article className="summary"><p className="eyebrow">最近一次有效读取</p><strong>{formatTime(status.lastVerifiedRead)}</strong><p>已保存学校条目：{status.itemCount}</p></article>
      <article className="summary">
        <p className="eyebrow">自动检查 · 北京时间</p>
        <strong className="paused">{status.scheduleEnabled ? <CalendarClock size={20} aria-hidden="true" /> : <CirclePause size={20} aria-hidden="true" />}{status.scheduleEnabled ? "已配置并启用" : "尚未启用"}</strong>
        {status.scheduleEnabled && <>
          {status.lastGraceElapsedSlot && <ScheduledRun slot={status.lastGraceElapsedSlot} label="昨晚" />}
          {status.scheduleSlots.map(slot => <ScheduledRun key={slot.scheduledAt} slot={slot} label={slot.time === "08:00" ? "今早" : "今晚"} />)}
        </>}
      </article>
    </section>
    <section className="courses" aria-labelledby="course-title"><div className="section-heading"><h2 id="course-title"><BookOpen size={21} aria-hidden="true" />同步范围</h2><span>{status.courseIds.length} 门已选课程</span></div><ul className="course-list">{status.courseIds.map((course, index) => <li key={course}><span className="course-order">{String(index + 1).padStart(2, "0")}</span><span>{courseNames[course]}<small className="course-id">{course}</small></span><span className="not-read">{status.lastVerifiedRead?`已保存 ${status.courseCounts[course] ?? 0} 条`:"未读取"}</span></li>)}</ul><p className="scope-note"><a href="/setup">使用设置</a></p></section>
    <section className="security-note"><ShieldCheck size={21} aria-hidden="true" /><div><h2>{['verified','read_failed'].includes(status.connection)?"只读取指定课程":"下一步：完成安全授权验证"}</h2><p>请不要在聊天中发送密码或 token。读取范围包括课程主页介绍、可读取的 News 首帖和课程日历；未覆盖完整 Page 正文、测验和考勤详情。</p><p>{status.announcementCoverage==='verified'?"已核对本次返回的 News 类型公告论坛；不包含普通论坛和回复。":status.announcementCoverage==='partial'?"公告覆盖仍不完整，请同时查看课程 Announcements；零条不代表没有公告。":"公告覆盖尚待核实；已发现的 Announcements 链接不等于已读完公告，零条不代表没有公告。"}</p></div></section>
    <footer><span>最近检查：{status.lastAttempt ? formatTime(status.lastAttempt) : "尚未检查"}</span><span>Asia/Shanghai · UTC+08:00</span></footer>
  </main>;
}
