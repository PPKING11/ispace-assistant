'use client';

import {useEffect,useState} from 'react';

const companionId='fcgnjkllmgaomnachmiimchkdjgfenif';
type CompanionState='checking'|'ready'|'extension_only'|'unpaired'|'unavailable';
type CompanionReply={installed?:boolean;localHost?:boolean;needsSiteSetup?:boolean};
type BrowserSupport = {chrome?:{runtime?:{sendMessage:(id:string,message:object,callback:(reply?:CompanionReply)=>void)=>void;lastError?:{message?:string}}}};

function askCompanion(type:'probe'|'open-setup') {
  return new Promise<CompanionReply|undefined>(resolve=>{
    const runtime=(window as BrowserSupport).chrome?.runtime;
    if(!runtime?.sendMessage)return resolve(undefined);
    const timeout=window.setTimeout(()=>resolve(undefined),1800);
    try {
      runtime.sendMessage(companionId,{type},reply=>{
        window.clearTimeout(timeout);
        const failed=Boolean(runtime.lastError);
        resolve(failed?undefined:reply);
      });
    } catch {
      window.clearTimeout(timeout);
      resolve(undefined);
    }
  });
}

export default function CompanionCheck(){
  const [status,setStatus]=useState<CompanionState>('checking');
  const [showSetup,setShowSetup]=useState(false);
  const [feedback,setFeedback]=useState('');
  async function probe(){
    setStatus('checking');
    const reply=await askCompanion('probe');
    setStatus(reply?.installed?(reply.needsSiteSetup?'unpaired':reply.localHost?'ready':'extension_only'):'unavailable');
  }
  useEffect(()=>{void probe();},[]);
  async function openSetup(){
    const reply=await askCompanion('open-setup');
    if(!reply)setFeedback('请在 Chrome 工具栏打开 iSpace 课程文件助手。');
  }
  const labels={
    checking:'正在检查本机下载组件…',
    ready:'Chrome 扩展和 Windows 文件助手已连接。',
    extension_only:'已检测到 Chrome 扩展，仍需连接 Windows 文件助手。',
    unpaired:'扩展已安装，请先在插件设置关联当前私人站点。',
    unavailable:'当前浏览器尚未检测到已配对的 iSpace 课程文件助手。',
  };
  return <section className="summary">
    <h2>本地课程文件</h2>
    <p role="status">{labels[status]}</p>
    <p>要在这台电脑上创建课程目录并自动保存新文件吗？可以选桌面的 <code>Course</code>、已有目录或其他位置。</p>
    <p><code>Course / Year 1 Semester 1 / BIO / Assignments</code></p>
    {status==='ready'?<button type="button" className="snapshot-reload" onClick={()=>void openSetup()}>选择本地目录</button>:
      status!=='checking'&&<button type="button" className="snapshot-reload" onClick={()=>setShowSetup(!showSetup)} aria-expanded={showSetup}>查看所需组件</button>}
    {' '}<a href="/">稍后设置</a>
    {showSetup&&<div><p>iSpace 课程文件助手需要配套 Chrome 扩展与 Windows 文件助手。本机自动归档由这两个组件配合完成。</p>
      <p>按安装包中的说明安装。打开 Chrome 扩展设置，填写当前私人站点地址，再回来重新检查。</p>
      <button type="button" className="snapshot-reload" onClick={()=>void probe()}>重新检查</button></div>}
    {feedback&&<p role="status">{feedback}</p>}
  </section>;
}
