import {headers} from 'next/headers';
import {requireChatGPTUser} from '../chatgpt-auth';
import {authorizeOwner,onboardingCatalog,publicError,readCourseScope} from '@/lib/runtime';
import CompanionCheck from './companion-check';
import CourseSelection from './course-selection';

export const dynamic='force-dynamic';

export default async function Setup(){
  await requireChatGPTUser('/setup');
  try{
    const owner=await authorizeOwner(await headers());
    const scope=await readCourseScope(owner);
    const catalog=scope.enrollmentMode?await onboardingCatalog(owner)
      .then(value=>({offers:value.offers,message:''}))
      .catch(error=>({offers:[],message:publicError(error).message})):{offers:scope.courses,message:''};
    return <main className="shell">
      <header className="masthead"><h1>iSpace 使用设置</h1><span className="owner-badge">仅限本人</span></header>
      <nav className="study-nav"><a href="/">作业与考试</a><a href="/sync">同步状态</a><a href="/read">课程资料阅读</a></nav>
      <section className="summary">
        <h2>学校账号和课程</h2>
        {catalog.message?<><p role="status">{catalog.message}</p><p><a href="https://ispace.bnbu.edu.cn/" target="_blank" rel="noreferrer">打开学校 iSpace</a></p></>:
          scope.enrollmentMode?(catalog.offers.length?<CourseSelection courses={catalog.offers} selected={[...scope.courseIds]}/>:<p>学校本次未返回可同步的本人课程。</p>):
          <p>{scope.courses.map((c:{code:string})=>c.code).join('、')}</p>}
      </section>
      <CompanionCheck/>
    </main>;
  }catch(error){
    return <main className="shell"><h1>暂时无法打开使用设置</h1><p>{publicError(error).message}</p></main>;
  }
}
