'use client';

import {useState} from 'react';

type Course={id:number;name:string;code:string};

export default function CourseSelection({courses,selected}:{courses:Course[];selected:number[]}){
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState('');
  async function save(event:React.FormEvent<HTMLFormElement>){
    event.preventDefault();
    const courseIds=new FormData(event.currentTarget).getAll('course').map(Number);
    if(courseIds.length<1||courseIds.length>12){setMessage('请选择 1–12 门要同步的课程。');return;}
    setBusy(true);setMessage('');
    try {
      const response=await fetch('/api/setup',{
        method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({courseIds}),
      });
      const value=await response.json() as {message?:string};
      setMessage(response.ok?'课程已保存，可以到同步状态页开始首次同步。':value.message??'还没保存，请重试。');
    } catch {setMessage('暂时无法保存选课，请重试。');}
    finally {setBusy(false);}
  }
  return <form onSubmit={event=>void save(event)}>
    <fieldset disabled={busy}>
      <legend>从本人选课中选择要同步的课程</legend>
      {courses.map(course=><label key={course.id} style={{display:'block',marginBlock:6}}>
        <input type="checkbox" name="course" value={course.id} defaultChecked={selected.includes(course.id)}/>
        {' '}{course.code} · {course.name}
      </label>)}
      <button type="submit" className="snapshot-reload">{busy?'正在保存':'保存课程'}</button>
      {' '}<a href="/sync">打开同步状态</a>
    </fieldset>
    <p role="status">{message}</p>
  </form>;
}
