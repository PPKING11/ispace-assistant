"use client";
import {useMemo,useState} from 'react';
import {ArrowUpRight,BookOpen,CalendarDays,Check,ChevronDown,Clock3,GraduationCap,LockKeyhole,RotateCw} from 'lucide-react';
import {RemindersLink} from './reminders/reminder-inbox';
type When={date:string;time:string|null;yearInferred:boolean};
type Task={id:string;courseId:number;title:string;kind:string;eventType:string;when:When|null;endTime:string|null;cutoff:When|null;status:{state:string;label:string;detail:string};note:string;deadlineNeedsReview?:boolean;deadlineReviewLabel?:string|null;sources:{title:string;url?:string;excerpt:string;verifiedAt:string|null}[]};
type Plan={verifiedAt:string|null;items:Task[];courses:{id:number;name:string;examTimeKnown:boolean}[];sourceItemCount:number;timeZone:string;coverageNote:string};
const stamp=(s:string|null)=>s?new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(new Date(s)):'尚无已核实数据';
const dateLabel=(d:string)=>{const [,month,day]=d.split('-');return `${Number(month)}月${Number(day)}日`};
const beijingToday=()=>new Date(Date.now()+8*3600000).toISOString().slice(0,10);
function TaskCard({task,course}:{task:Task;course:string}){
 const when=task.when;
 const itemId=task.id.split(':').slice(1).join(':');
 const reviewHref=task.kind==='assignment'&&/^(?:assignment|module):[1-9]\d*$/.test(itemId)
  ? '/read?'+new URLSearchParams({op:'item',courseId:String(task.courseId),itemId,expectedVerifiedAt:task.sources[0]?.verifiedAt??''})
  : null;
 return <article className={`task-card ${task.kind==='exam'?'exam-card':''} ${task.status.state==='submitted'?'submitted-card':''}`}>
  <div className="task-date"><strong>{when?dateLabel(when.date):'待确认'}</strong><span>{when?(when.time?`${when.time}${task.endTime?'–'+task.endTime:''}`:'时刻未注明'):'日期待核对'}</span><small>{when?when.date.slice(0,4)+' 年':'查看学校来源'}</small></div>
  <div className="task-content"><div className="task-meta"><span className="course-tag">{course}</span><span className={`kind-tag ${task.kind==='exam'?'exam-tag':''}`}>{task.kind==='exam'?'考试 / 测验':task.eventType==='assessment'?'课堂作业':'作业 / 项目'}</span></div>
   <h3>{task.title}</h3><div className="task-status"><span className={task.status.state==='submitted'?'is-submitted':''}>{task.status.state==='submitted'&&<Check size={14} aria-hidden="true"/>}{task.status.label}</span><span className="date-type">{task.eventType==='exam'?'考试时间':task.eventType==='assessment'?'安排日期':'截止时间'}</span></div>
   {task.note&&<p className="task-note">{task.note}</p>}
   {task.cutoff&&<p className="cutoff-note">停止接收：{dateLabel(task.cutoff.date)} {task.cutoff.time}；作业截止仍以上方时间为准</p>}
   {when?.yearInferred&&<p className="inferred-note">来源未写年份，按本次课程快照的 {when.date.slice(0,4)} 学期整理</p>}
   {task.deadlineNeedsReview&&<p className="inferred-note">{task.deadlineReviewLabel??'截止日期需要核对，请查看下方来源。'}</p>}
   {reviewHref&&<p><a href={reviewHref}>读作业说明与附件</a></p>}
   <details className="source-details"><summary>来源与状态依据 <ChevronDown size={13} aria-hidden="true"/></summary><p>{task.status.detail}</p>{task.sources.map((s,i)=><div className="source-evidence" key={i}><a href={s.url} target="_blank" rel="noopener noreferrer">{s.title}<ArrowUpRight size={13} aria-hidden="true"/></a><p>{s.excerpt}</p><small>读取于 {stamp(s.verifiedAt)}（北京时间）</small></div>)}</details>
  </div><a className="source-shortcut" href={task.sources[0]?.url} target="_blank" rel="noopener noreferrer" aria-label={`在 iSpace 查看 ${task.title}`}><ArrowUpRight size={19} aria-hidden="true"/></a>
 </article>;
}
export default function StudyDashboard({initial,scheduledTimes}:{initial:Plan;scheduledTimes:string[]}){
 const [plan,setPlan]=useState(initial);const [kind,setKind]=useState('all');const [course,setCourse]=useState('all');const [busy,setBusy]=useState(false);const [error,setError]=useState('');
 const today=beijingToday();
 const names=Object.fromEntries(plan.courses.map(c=>[c.id,c.name]));
 const filtered=useMemo(()=>plan.items.filter(i=>(kind==='all'||i.kind===kind)&&(course==='all'||String(i.courseId)===course)),[plan,kind,course]);
 const submitted=filtered.filter(i=>i.status.state==='submitted');
 const past=filtered.filter(i=>i.status.state!=='submitted'&&i.when&&i.when.date<today);
 const active=filtered.filter(i=>i.status.state!=='submitted'&&(!i.when||i.when.date>=today));
 const upcoming=plan.items.filter(i=>i.status.state!=='submitted'&&i.when&&i.when.date>=today);
 const next=upcoming[0];
 async function reload(){
  setBusy(true);setError('');
  try{
   const response=await fetch('/api/refresh',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({requestKey:`manual:${crypto.randomUUID()}`})});
   const result=await response.json() as {status?:string;message?:string};
   if(!response.ok||result.status!=='verified')throw new Error(result.message||(result.status==='running'?'同步正在进行，请稍后再试':'暂时未能从学校读取最新资料'));
   const r=await fetch('/api/deadlines',{cache:'no-store'});
   const p=await r.json() as Plan & {message?:string};
   if(!r.ok)throw new Error(p.message||'暂时无法加载');
   setPlan(p);
  }catch(e){setError(e instanceof Error?e.message:'暂时无法加载');}
  finally{setBusy(false);}
 }
 const cards=(items:Task[])=>items.map(task=><TaskCard key={task.id} task={task} course={names[task.courseId]}/>);
 return <main className="shell study-shell">
  <header className="masthead"><div className="wordmark"><span className="brand">iSpace<span className="brand-dot">.</span></span><span className="private-label">学习日程</span></div><span className="owner-badge"><LockKeyhole size={14} aria-hidden="true"/>仅限本人</span></header>
  <nav className="study-nav"><a href="/" aria-current="page">作业与考试</a><a href="/coursework">作业工作区</a><a href="/submission">准备提交</a><RemindersLink/><a href="/sync">同步状态</a><a href="/read">课程资料阅读</a><a href="/files">课程附件</a><a href="/setup">使用设置</a></nav>
  <section className="study-heading"><div><p className="eyebrow">{plan.courses.length} 门课程 · 北京时间 UTC+08:00</p><h1>作业与考试</h1></div><button className="snapshot-reload" onClick={()=>void reload()} disabled={busy}><RotateCw size={15} className={busy?'spin':''} aria-hidden="true"/>{busy?'正在从学校读取':'从学校刷新'}</button></section>
  <p className="snapshot-caption">数据核实于 {stamp(plan.verifiedAt)}{scheduledTimes.length?` · 每天 ${scheduledTimes.join(' / ')} 同步`:''}</p>
  {error&&<p role="alert" className="load-error">{error}；当前内容继续保留</p>}
  {!plan.verifiedAt?<section className="notice"><h2>还没有可显示的学校数据</h2><p>完成同步后，作业和考试会显示在这里。</p><a href="/sync">查看同步状态</a></section>:<>
  <section className="agenda-summary" aria-label="日程概览"><div className="next-task"><span><Clock3 size={16} aria-hidden="true"/>最近一项</span><strong>{next?.when?dateLabel(next.when.date)+(next.when.time?' '+next.when.time:' · 时刻待定'):'暂无已知的后续日期'}</strong><p>{next?`${names[next.courseId]} · ${next.title}`:'仍需查看未公布日期的项目'}</p></div><div className="agenda-stat"><BookOpen size={20} aria-hidden="true"/><strong>{upcoming.filter(i=>i.kind==='assignment').length}</strong><span>后续作业 / 项目</span></div><div className="agenda-stat"><GraduationCap size={21} aria-hidden="true"/><strong>{upcoming.filter(i=>i.kind==='exam').length}</strong><span>已知考试 / 测验</span></div></section>
  <div className="study-filters"><div className="filter-tabs" role="group" aria-label="事项类型">{[['all','全部'],['assignment','作业 / 项目'],['exam','考试 / 测验']].map(([value,label])=><button key={value} aria-pressed={kind===value} onClick={()=>setKind(value)}>{label}</button>)}</div><label className="course-filter"><span className="sr-only">筛选课程</span><select value={course} onChange={e=>setCourse(e.target.value)}><option value="all">全部课程</option>{plan.courses.map(c=><option value={c.id} key={c.id}>{c.name}</option>)}</select></label></div>
  <section className="agenda-list" aria-labelledby="active-title"><div className="list-heading"><h2 id="active-title"><CalendarDays size={18} aria-hidden="true"/>待处理与状态待核对</h2><span>{active.length} 项 · 按日期排序</span></div>{active.length?cards(active):<p className="empty-result">当前筛选下没有后续事项；不代表课程没有其他安排。</p>}</section>
  {submitted.length>0&&<details className="task-group"><summary><span><Check size={17} aria-hidden="true"/>已提交</span><span>{submitted.length} 项 <ChevronDown size={17} aria-hidden="true"/></span></summary><div className="group-content">{cards(submitted)}</div></details>}
  {past.length>0&&<details className="task-group"><summary><span>日期已过 · 状态待核对</span><span>{past.length} 项 <ChevronDown size={17} aria-hidden="true"/></span></summary><div className="group-content"><p className="past-note">日期已过不等于没有完成；这些事项没有可读取的提交记录。</p>{cards(past)}</div></details>}
  <aside className="coverage-note"><h2>还有哪些时间待确认？</h2><p>{plan.courses.filter(c=>!c.examTimeKnown).map(c=>c.name).join('、')}：当前可读内容中未找到具体考试时间。</p><p>{plan.coverageNote}</p><p>“完成情况未知”不会当作未交；线下作业与部分小组提交需要在学校来源核对。</p></aside>
  </>}
  <footer><span>所有时间均为北京时间</span><a href="/sync">查看读取范围与同步状态 <ArrowUpRight size={13} aria-hidden="true"/></a></footer>
 </main>;
}
