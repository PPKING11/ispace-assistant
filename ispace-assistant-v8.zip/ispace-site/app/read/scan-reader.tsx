'use client';

import {useEffect, useRef, useState} from 'react';
import {downloadArguments, MAX_FILE_BYTES} from '@/lib/course-download.mjs';

type ScanReaderProps = {
  downloadUrl: string;
  fileName: string;
  expectedSha256?: string;
  initialPage?: number;
  autoStart?: boolean;
};

type Language = 'eng' | 'chi_sim';
type ScanJob = {page: number; language: Language};
type Phase = 'idle' | 'downloading' | 'rendering' | 'recognizing' | 'done' | 'cancelled' | 'error';
type ScanView = {phase: Phase; page: number; totalPages?: number; isImage: boolean; canvasReady: boolean; text?: string; error?: string};
type SaveRequest = ReturnType<typeof downloadArguments> & {sha256: string; page: number; language: Language; text: string};
type SaveStatus = {state: 'idle' | 'saving' | 'saved'} | {state: 'error'; message: string};

type Viewport = {width: number; height: number};
type RenderTask = {promise: Promise<void>; cancel(): void};
type PdfPage = {
  getViewport(options: {scale: number}): Viewport;
  render(options: {
    canvas: HTMLCanvasElement;
    canvasContext: CanvasRenderingContext2D;
    viewport: Viewport;
    background: string;
  }): RenderTask;
};
type PdfLoadingTask = {
  promise: Promise<{numPages: number; getPage(page: number): Promise<PdfPage>}>;
  destroy(): Promise<void>;
};
type PdfModule = {
  GlobalWorkerOptions: {workerSrc: string};
  getDocument(options: {
    data: ArrayBuffer;
    isEvalSupported: boolean;
    enableXfa: boolean;
    useWorkerFetch: boolean;
    standardFontDataUrl: string;
    wasmUrl: string;
  }): PdfLoadingTask;
};
type OcrClient = {
  loadModel(url: string): Promise<void>;
  loadImage(image: ImageData): Promise<void>;
  getText(): Promise<string>;
  destroy(): void;
};
type OcrModule = {OCRClient: new (options: {workerURL: string}) => OcrClient};

class ScanError extends Error {}

const maxSavedCharacters = 12000;
const saveTimeoutMs = 30_000;
const maxCanvasPixels = 4_000_000;
const maxCanvasSide = 2400;
const messages: Record<Phase, string> = {
  idle: '',
  downloading: '正在读取和核对原件…',
  rendering: '正在显示原页…',
  recognizing: '正在识别图片里的文字…',
  done: '',
  cancelled: '已取消本次识别。',
  error: '',
};

function assetUrl(name: 'pdf.mjs' | 'pdf.worker.mjs' | 'tesseract.js' | 'tesseract-worker.js' | 'eng.traineddata' | 'chi_sim.traineddata' | 'standard_fonts/' | 'wasm/') {
  return new URL(`/ocr/${name}`, window.location.origin).href;
}

function importReader(name: 'pdf.mjs' | 'tesseract.js') {
  const url = assetUrl(name);
  return import(/* @vite-ignore */ /* webpackIgnore: true */ url);
}

function cancellable<T>(operation: Promise<T>, signal: AbortSignal) {
  return new Promise<T>((resolve, reject) => {
    const onAbort = () => reject(signal.reason);
    signal.addEventListener('abort', onAbort, {once: true});
    if (signal.aborted) onAbort();
    void operation.then(resolve, reject).finally(() => signal.removeEventListener('abort', onAbort));
  });
}

async function readOriginal(downloadUrl: string, expectedSha256: string | undefined, signal: AbortSignal) {
  const url = new URL(downloadUrl, window.location.origin);
  if (url.origin !== window.location.origin || url.pathname !== '/api/files' || url.username || url.password || url.hash) {
    throw new ScanError('请从课程资料阅读页打开此附件。');
  }
  let selector: ReturnType<typeof downloadArguments>;
  try {
    selector = downloadArguments(url.searchParams);
    if (url.searchParams.get('courseId') !== String(selector.courseId) || url.searchParams.get('resourceIndex') !== String(selector.resourceIndex)) throw new Error('Invalid selector');
  } catch {
    throw new ScanError('附件链接已失效，请从课程资料阅读页重新打开。');
  }
  const response = await fetch(url, {cache: 'no-store', credentials: 'same-origin', redirect: 'error', signal});
  if (!response.ok) {
    if (response.status === 401 || response.status === 403) throw new ScanError('请重新登录后再读取原件。');
    if (response.status === 409) throw new ScanError('课程资料已更新，请从作业页面重新打开最新原件。');
    throw new ScanError('原件暂时无法下载，请重试。');
  }
  const mediaType = response.headers.get('content-type')?.split(';')[0].trim().toLowerCase();
  if (mediaType !== 'application/pdf' && mediaType !== 'image/png' && mediaType !== 'image/jpeg') {
    throw new ScanError('此处可以识别 PDF、PNG 或 JPEG 原件。');
  }
  if (Number(response.headers.get('content-length')) > MAX_FILE_BYTES) {
    throw new ScanError('此附件超过图片页读取上限。');
  }
  const bytes = await response.arrayBuffer();
  if (bytes.byteLength > MAX_FILE_BYTES) throw new ScanError('此附件超过图片页读取上限。');
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  const sha256 = Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('');
  if (expectedSha256 && sha256 !== expectedSha256.toLowerCase()) {
    throw new ScanError('原件与此前读取的版本不同，请从作业页面重新打开。');
  }
  return {bytes, mediaType, selector, sha256};
}

async function saveForChat(request: SaveRequest, signal: AbortSignal) {
  const response = await fetch('/api/ocr', {
    method: 'POST',
    headers: {'content-type': 'application/json', accept: 'application/json'},
    credentials: 'same-origin',
    cache: 'no-store',
    redirect: 'error',
    body: JSON.stringify(request),
    signal,
  });
  if (response.status === 401 || response.status === 403) throw new ScanError('登录已失效，请重新登录后重试保存。');
  if (response.status === 409) throw new ScanError('当前资料版本已更新，请重新打开最新附件后识别。');
  if (!response.ok) throw new ScanError('暂时无法保存，可以重试。');
  const receipt: unknown = await response.json();
  if (!receipt || typeof receipt !== 'object' || !('status' in receipt) || receipt.status !== 'saved' ||
      !('page' in receipt) || receipt.page !== request.page || !('sha256' in receipt) || receipt.sha256 !== request.sha256) {
    throw new ScanError('没有收到保存回执，可以重试。');
  }
}

function renderScale(width: number, height: number, maxScale: number) {
  if (width <= 0 || height <= 0 || !Number.isFinite(width * height)) throw new ScanError('无法确定原页图像的尺寸。');
  return Math.min(maxScale, maxCanvasSide / Math.max(width, height), Math.sqrt(maxCanvasPixels / (width * height)));
}

export default function ScanReader({downloadUrl, fileName, expectedSha256, initialPage = 1, autoStart = false}: ScanReaderProps) {
  const namedImage = /\.(?:png|jpe?g)$/i.test(fileName);
  const firstPage = !namedImage && Number.isSafeInteger(initialPage) && initialPage >= 1 ? initialPage : 1;
  const [pageInput, setPageInput] = useState(String(firstPage));
  const [language, setLanguage] = useState<Language>('eng');
  const [job, setJob] = useState<ScanJob | null>(autoStart ? {page: firstPage, language: 'eng'} : null);
  const [view, setView] = useState<ScanView>({phase: autoStart ? 'downloading' : 'idle', page: firstPage, isImage: namedImage, canvasReady: false});
  const [saveRequest, setSaveRequest] = useState<SaveRequest | null>(null);
  const [saveStatus, setSaveStatus] = useState<SaveStatus>({state: 'idle'});
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const cancelCurrent = useRef<(() => void) | null>(null);

  useEffect(() => {
    if (!saveRequest) return;
    const controller = new AbortController();
    const timeout = AbortSignal.timeout(saveTimeoutMs);
    const signal = AbortSignal.any([controller.signal, timeout]);
    void saveForChat(saveRequest, signal).then(() => {
      if (!controller.signal.aborted) setSaveStatus({state: 'saved'});
    }, (error: unknown) => {
      if (!controller.signal.aborted) setSaveStatus({
        state: 'error',
        message: timeout.aborted ? '保存超时，可以重试。' : error instanceof ScanError ? error.message : '暂时无法保存，可以重试。',
      });
    });
    return () => controller.abort();
  }, [saveRequest]);

  useEffect(() => {
    if (!job) return;

    const controller = new AbortController();
    const {signal} = controller;
    let loadingTask: PdfLoadingTask | undefined;
    let renderTask: RenderTask | undefined;
    let client: OcrClient | undefined;
    let phase: Phase = 'downloading';

    async function closePdf() {
      const task = loadingTask;
      loadingTask = undefined;
      if (task) await task.destroy().catch(() => {});
    }

    function release() {
      renderTask?.cancel();
      renderTask = undefined;
      client?.destroy();
      client = undefined;
      void closePdf();
    }

    function stop() {
      controller.abort();
      release();
    }

    const update = (change: Partial<ScanView>) => {
      if (!signal.aborted) setView((previous) => ({...previous, ...change}));
    };

    cancelCurrent.current = stop;

    async function run({page, language}: ScanJob) {
      const canvas = canvasRef.current;
      if (!canvas) return;
      canvas.width = 1;
      canvas.height = 1;
      update({phase, page, canvasReady: false, text: undefined, error: undefined});
      try {
        const {bytes, mediaType, selector, sha256} = await readOriginal(downloadUrl, expectedSha256, signal);
        signal.throwIfAborted();
        phase = 'rendering';
        const isImage = mediaType !== 'application/pdf';
        update({phase, isImage});
        const context = canvas.getContext('2d', {willReadFrequently: true});
        if (!context) throw new ScanError('当前浏览器无法显示原页。');

        if (isImage) {
          update({page: 1, totalPages: 1});
          const original = await createImageBitmap(new Blob([bytes], {type: mediaType}));
          try {
            signal.throwIfAborted();
            const scale = renderScale(original.width, original.height, 1);
            canvas.width = Math.max(1, Math.floor(original.width * scale));
            canvas.height = Math.max(1, Math.floor(original.height * scale));
            context.fillStyle = '#ffffff';
            context.fillRect(0, 0, canvas.width, canvas.height);
            context.drawImage(original, 0, 0, canvas.width, canvas.height);
          } finally {
            original.close();
          }
        } else {
          const pdf = await importReader('pdf.mjs') as PdfModule;
          signal.throwIfAborted();
          pdf.GlobalWorkerOptions.workerSrc = assetUrl('pdf.worker.mjs');
          loadingTask = pdf.getDocument({
            data: bytes,
            isEvalSupported: false,
            enableXfa: false,
            useWorkerFetch: false,
            standardFontDataUrl: assetUrl('standard_fonts/'),
            wasmUrl: assetUrl('wasm/'),
          });
          const document = await loadingTask.promise;
          signal.throwIfAborted();
          update({totalPages: document.numPages});
          if (page > document.numPages) throw new ScanError(`此 PDF 共 ${document.numPages} 页，请选择有效页码。`);
          const original = await document.getPage(page);
          signal.throwIfAborted();
          const {width, height} = original.getViewport({scale: 1});
          const viewport = original.getViewport({scale: renderScale(width, height, 2.5)});
          canvas.width = Math.max(1, Math.floor(viewport.width));
          canvas.height = Math.max(1, Math.floor(viewport.height));
          renderTask = original.render({canvas, canvasContext: context, viewport, background: '#ffffff'});
          await renderTask.promise;
          renderTask = undefined;
        }
        signal.throwIfAborted();
        phase = 'recognizing';
        update({phase, canvasReady: true});
        await closePdf();
        signal.throwIfAborted();

        const {OCRClient} = await importReader('tesseract.js') as OcrModule;
        signal.throwIfAborted();
        client = new OCRClient({workerURL: assetUrl('tesseract-worker.js')});
        await cancellable(client.loadModel(assetUrl(language === 'eng' ? 'eng.traineddata' : 'chi_sim.traineddata')), signal);
        signal.throwIfAborted();
        await cancellable(client.loadImage(context.getImageData(0, 0, canvas.width, canvas.height)), signal);
        signal.throwIfAborted();
        const text = (await cancellable(client.getText(), signal)).trim();
        signal.throwIfAborted();
        update({phase: 'done', text});
        if (text) {
          const savedText = text.slice(0, maxSavedCharacters).replace(/[\ud800-\udbff]$/, '').trimEnd();
          setSaveStatus({state: 'saving'});
          setSaveRequest({...selector, sha256, page: isImage ? 1 : page, language, text: savedText});
        }
      } catch (error) {
        update({
          phase: 'error',
          error: error instanceof ScanError ? error.message : phase === 'recognizing'
            ? '文字识别未完成，可以查看下方原页或重试。'
            : '原页暂时无法显示，请确认已登录后重试。',
        });
      } finally {
        if (cancelCurrent.current === stop) cancelCurrent.current = null;
        release();
      }
    }

    void run(job);
    return () => {
      if (cancelCurrent.current === stop) cancelCurrent.current = null;
      stop();
    };
  }, [downloadUrl, expectedSha256, job]);

  const busy = view.phase === 'downloading' || view.phase === 'rendering' || view.phase === 'recognizing';
  const saving = saveStatus.state === 'saving';
  const selectedPage = view.isImage ? 1 : Number(pageInput);
  const validPage = Number.isSafeInteger(selectedPage) && selectedPage >= 1 && selectedPage <= (view.totalPages ?? 2000);
  const originalLabel = view.isImage ? '原图' : `第 ${view.page} 页原图`;
  const textLabel = view.isImage ? '识别文字' : `第 ${view.page} 页识别文字`;

  return (
    <section>
      <h3>图片页文字识别</h3>
      <div className="action-row">
        {!view.isImage && <>
          <label>页码 <input type="number" min={1} max={view.totalPages ?? 2000} step={1} value={pageInput} onChange={(event) => setPageInput(event.target.value)} disabled={busy} /></label>
          {view.totalPages !== undefined && <span>共 {view.totalPages} 页</span>}
        </>}
        <label>识别语言 <select value={language} onChange={(event) => setLanguage(event.target.value === 'chi_sim' ? 'chi_sim' : 'eng')} disabled={busy}>
          <option value="eng">英语</option>
          <option value="chi_sim">简体中文</option>
        </select></label>
        <button className="snapshot-reload" type="button" disabled={!validPage || busy || saving} onClick={() => {
          setSaveRequest(null);
          setSaveStatus({state: 'idle'});
          setView((previous) => ({...previous, phase: 'downloading', canvasReady: false, text: undefined, error: undefined}));
          setJob({page: selectedPage, language});
        }}>{view.isImage ? '识别图片' : '识别此页'}</button>
        {busy && <button className="snapshot-reload" type="button" onClick={() => {
          cancelCurrent.current?.();
          setJob(null);
          setView((previous) => ({...previous, phase: 'cancelled'}));
        }}>取消</button>}
      </div>
      {messages[view.phase] && <p role="status">{messages[view.phase]}</p>}
      {view.error && <p role="alert" className="load-error">{view.error}</p>}
      <figure hidden={!view.canvasReady} style={{margin: '1rem 0'}}>
        <figcaption>{originalLabel}</figcaption>
        <canvas ref={canvasRef} role="img" aria-label={`${fileName} ${originalLabel}`} style={{display: 'block', maxWidth: '100%', height: 'auto', border: '1px solid #dce5ed'}} />
      </figure>
      {view.phase === 'done' && (view.text ? <>
        <h4>{textLabel}</h4>
        {saving && <p role="status">正在保存识别文字到你的私有插件…</p>}
        {saveStatus.state === 'saved' && <p role="status">聊天可读取此页</p>}
        {saveStatus.state === 'error' && saveRequest && <div>
          <p role="alert" className="load-error">{saveStatus.message} 下方仍保留此次识别的文字。</p>
          <button className="snapshot-reload" type="button" onClick={() => {
            setSaveStatus({state: 'saving'});
            setSaveRequest({...saveRequest});
          }}>重试保存</button>
        </div>}
        {saveRequest && saveRequest.text.length < view.text.length && <p>最多保存前 12,000 个字符供聊天读取。下方显示完整的本次识别结果。</p>}
        <pre style={{whiteSpace: 'pre-wrap', overflowWrap: 'anywhere'}}>{view.text}</pre>
        <p>图表、公式和版式可对照上方原图。</p>
      </> : <p role="status">未识别到文字，可以查看原图。</p>)}
    </section>
  );
}
