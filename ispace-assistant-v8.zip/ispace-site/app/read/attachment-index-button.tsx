'use client';

import {useState} from 'react';
import {useRouter} from 'next/navigation';

type Target={courseId:number;itemId:string;resourceIndex:number;expectedVerifiedAt:string};
export default function AttachmentIndexButton({courseId,target}:{courseId?:number;target?:Target}){
  const router=useRouter();
  const [working,setWorking]=useState(false);
  const [feedback,setFeedback]=useState('');
  async function index(){
    setWorking(true);
    setFeedback('');
    try{
      const query=target?new URLSearchParams(Object.entries(target).map(([key,value])=>[key,String(value)])):
        new URLSearchParams(courseId?{courseId:String(courseId)}:undefined);
      const response=await fetch('/api/attachment-index?'+query,{method:'POST'});
      const value=await response.json() as {message?:string;pending?:number;processed?:{status:string}[]};
      if(!response.ok)throw new Error(value.message??'暂时无法读取附件。');
      if(!Array.isArray(value.processed)||!Number.isInteger(value.pending))throw new Error('未收到附件检查回执。');
      setFeedback(target?(value.processed[0]?.status==='read_failed'?'仍未读到正文，可查看更新后的原因。':'这份附件已重新检查。'):
        value.pending?`已检查 ${value.processed.length} 份，待检查 ${value.pending} 份。`:'这批已检查完毕。');
      router.refresh();
    }catch(error){setFeedback(error instanceof Error?error.message:'暂时无法读取附件。');}
    finally{setWorking(false);}
  }
  return <div>
    <button type="button" className="snapshot-reload" disabled={working} onClick={()=>void index()}>{working?'正在读取附件':target?'重新检查这份附件':'更新下一批附件'}</button>
    {feedback&&<p role="status">{feedback}</p>}
  </div>;
}
