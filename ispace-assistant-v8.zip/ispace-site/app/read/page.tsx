import {headers} from 'next/headers';
import {requireChatGPTUser} from '../chatgpt-auth';
import {attachmentAudit,authorizeOwner,searchCourseAttachments,searchCourseItems,readCourseItem,readCourseFile,readLatestItems,readOwnRecords,publicError,readStatus} from '@/lib/runtime';
import {SafeError} from '@/lib/sync-core.mjs';
import {downloadArguments,selectDownload} from '@/lib/course-download.mjs';
import {isVisualScanFile} from '@/lib/visual-scan.mjs';
import ScanReader from './scan-reader';
import AttachmentIndexButton from './attachment-index-button';
export const dynamic='force-dynamic';
const href=(v:Record<string,any>)=>'/read?'+new URLSearchParams(Object.entries(v).filter(([,v])=>v!==undefined).map(([k,v])=>[k,String(v)]));
const statusLabel=(value:string)=>({read:'已读取',failed:'读取失败',not_available_in_token_service:'学校当前接口未开放',submitted:'已提交',not_submitted:'未提交',draft:'草稿',unknown:'未知',graded:'已评分',not_graded:'未评分',individual:'个人提交入口',group:'小组提交入口'}[value]??value);
const origin='';
const reviewStatus:Record<string,string>={read:'已读取文字',partial:'部分已读',visual_review:'需查看原页',not_read:'正文未读到',deferred:'待继续读取'};
export default async function Read({searchParams}:{searchParams:Promise<Record<string,string|undefined>>}){
 await requireChatGPTUser('/read');
 const q=await searchParams;
 const nav=<nav className="study-nav"><a href="/">作业与考试</a><a href="/read">课程资料阅读</a><a href="/read?op=attachment-search">搜附件正文</a><a href="/files">原文件下载</a><a href="/sync">同步状态</a></nav>;
 try{
  const h=await headers();const owner=await authorizeOwner(h);const state=await readStatus(owner);
  const COURSE_NAMES:Record<number,string>=Object.fromEntries(state.courses.map(course=>[course.id,course.name]));
  const courseId=q.courseId?Number(q.courseId):undefined;const expectedVerifiedAt=q.expectedVerifiedAt??state.lastVerifiedRead??undefined;
  let body;
  if(q.op==='attachment-search'){
   const query=q.query?.trim();
   const result=query?await searchCourseAttachments(owner,{query,courseId,offset:Number(q.offset??0),expectedVerifiedAt},origin):null;
   body=<section className="summary">
    <h2>搜附件正文</h2>
    <form action="/read">
     <input type="hidden" name="op" value="attachment-search"/>
     <label>关键词 <input name="query" defaultValue={query} maxLength={120} required/></label>
     <label>课程 <select name="courseId" defaultValue={q.courseId??''}><option value="">全部课程</option>{Object.entries(COURSE_NAMES).map(([id,name])=><option key={id} value={id}>{String(name)}</option>)}</select></label>
     <button type="submit">搜索</button>
    </form>
    <AttachmentIndexButton courseId={courseId}/>
    <p><a href={href({op:'attachment-audit',courseId,expectedVerifiedAt})}>查看哪些附件还没读全</a></p>
    {result&&<>
     <p>匹配 {result.total} 处。已读 {result.coverage.indexed} 份，部分已读 {result.coverage.partial} 份，待检查 {result.coverage.pending} 份，待读图片文字 {result.coverage.needsOcr} 份，读取失败 {result.coverage.failed} 份。</p>
     {result.coverage.hitLimit&&<p>匹配数量较多，请按课程缩小范围。</p>}
     <ul>{result.items.map((hit,index)=><li key={hit.readUrl+':'+index}>
      <a href={hit.scanUrl??hit.readUrl}>{hit.filename}{hit.page?` · 第 ${hit.page} 页`:''}</a>
      <p>{COURSE_NAMES[hit.courseId]} · {hit.source==='browser_ocr'?'图片识别':'附件文字'}</p>
      <p>{hit.match}</p>
     </li>)}</ul>
     {result.nextOffset!==null&&<a href={href({...q,offset:result.nextOffset,expectedVerifiedAt:result.verifiedAt})}>下一页</a>}
    </>}
   </section>;
  }else if(q.op==='attachment-audit'){
   const report=await attachmentAudit(owner,courseId,Number(q.offset??0),expectedVerifiedAt);
   const statuses:Record<string,string>={read_failed:'读取失败',needs_ocr:'需要图片识别',image:'图片尚待识别',partial:'部分已读',pending:'待检查'};
   const reasons:Record<string,string>={file_too_large:'超过 48 MiB 的正文提取上限。',file_timeout:'从学校读取原件超时。',file_extraction_failed:'无法解析此版本的正文。',file_read_failed:'学校没有返回完整原件。',file_size_mismatch:'学校返回的字节数与记录不一致。',conversion_required:'这种格式需要先转换。',unsupported_or_encrypted:'格式受限或文件已加密。',file_type_unsupported:'学校返回的文件类型暂不支持。',file_auth_failed:'学校当前拒绝读取，请核对登录和权限。'};
   body=<section className="summary">
    <h2>附件读取进度</h2>
    {!report.items.length&&<p>{report.nextOffset===null?'这页没有需要补读的附件。':'这页的图片已识别，可以继续看下一页。'}</p>}
    {report.items.map(row=><details key={row.fileKey} className="source-details">
      <summary>{row.filename} · {statuses[row.status]??row.status}</summary>
      <p>{COURSE_NAMES[row.courseId]}</p>
      {row.info?.failureCode&&<p>{reasons[row.info.failureCode]??'这次无法读取正文。'}</p>}
      {!row.info&&['read_failed','partial'].includes(row.status)&&<p>之前的读取没有保存失败原因或漏读页码。重新检查这份附件后可查看。</p>}
      {Boolean(row.unreadPages.length)&&<p>需识别的原页 {row.unreadPages.map(page=><a key={page} style={{marginRight:8}} href={href({op:'scan',...row.target,page,expectedSha256:row.info?.sha256||undefined})}>第 {page} 页</a>)}</p>}
      {row.info?.nextPage&&<p>未检查第 {row.info.nextPage} 页起的后续内容。 {row.info.sha256&&<a href={href({op:'file',...row.target,page:row.info.nextPage,expectedSha256:row.info.sha256})}>继续阅读</a>}</p>}
      {Boolean(row.info?.textWasShortened)&&<p>有较长的内容未全部纳入搜索，可以单独打开附件读取。</p>}
      <p><a href={row.readUrl}>单独读取</a>{' · '}<a href={row.downloadUrl} download>下载原件</a>{row.scanUrl&&<>{' · '}<a href={row.scanUrl}>打开原页</a></>}</p>
      {row.status!=='image'&&<AttachmentIndexButton target={row.target}/>}
    </details>)}
    {report.nextOffset!==null&&<a href={href({...q,offset:report.nextOffset,expectedVerifiedAt:report.verifiedAt})}>下一页</a>}
   </section>;
  }else if(q.op==='scan'){
   const query=new URLSearchParams({courseId:String(courseId),itemId:q.itemId??'',resourceIndex:q.resourceIndex??'',expectedVerifiedAt:expectedVerifiedAt??''});
   const args=downloadArguments(query,state.courseIds);
   const page=Number(q.page??1);
   if(!Number.isInteger(page)||page<1||page>2000||(q.expectedSha256!==undefined&&!/^[a-f0-9]{64}$/.test(q.expectedSha256)))throw new SafeError('invalid_request',400);
   const resource=await selectDownload({ownerId:owner,args,readPage:readLatestItems});
   if(!isVisualScanFile(resource.name))throw new SafeError('file_type_unsupported',415);
   const downloadUrl='/api/files?'+query;
   body=<ScanReader key={downloadUrl+':'+page} downloadUrl={downloadUrl} fileName={resource.name} expectedSha256={q.expectedSha256} initialPage={page} autoStart/>;
  }else if(q.op==='file'){
   const result=await readCourseFile(owner,{courseId,itemId:q.itemId,resourceIndex:Number(q.resourceIndex),expectedVerifiedAt,page:Number(q.page??1),pageCount:Number(q.pageCount??3),textOffset:Number(q.textOffset??0),expectedSha256:q.expectedSha256},origin);
   const file=JSON.parse(result.content[0].text);const e=file.extraction;
   body=<section className="summary"><h2>{file.filename}</h2><p>{file.status==='extraction_limit_exceeded'?'文件超过 48 MiB 正文提取上限，可打开原页。':`原文件已读取 · ${file.bytes} 字节`}</p>
    <p><a href={file.downloadUrl} download>下载原文件</a></p>
    {file.scanUrl&&<p><a href={file.scanUrl}>查看原页并识别文字</a></p>}
    {e.totalPages&&<p>共 {e.totalPages} 页，当前从第 {q.page??1} 页读取。</p>}
    {e.pages?.filter((p:any)=>p.ocr==='may_require_ocr_or_visual_review').map((p:any)=><p key={p.page}><a href={href({op:'scan',courseId,itemId:q.itemId,resourceIndex:q.resourceIndex,expectedVerifiedAt,page:p.page,expectedSha256:file.sha256})}>识别第 {p.page} 页并核对原图</a></p>)}
    {e.status==='conversion_required'&&<p>此格式需要转换后才能可靠读取正文。</p>}
    <pre style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{e.text||'没有可直接提取的文字。'}</pre>
    {e.nextTextOffset!=null&&<p><a href={href({...q,textOffset:e.nextTextOffset,expectedSha256:file.sha256})}>继续本组文字</a></p>}
    {e.nextPage&&<p><a href={href({...q,page:e.nextPage,textOffset:0,expectedSha256:file.sha256})}>下一组 PDF 页面</a></p>}
   </section>;
  }else if(q.op==='item'){
   const result=await readCourseItem(owner,{courseId,itemId:q.itemId,expectedVerifiedAt,textOffset:Number(q.textOffset??0)},origin);
   const item:any=result.item;
   const learning=result.learningState;
   const review=result.assignmentReview;
   const due=review?.dueAt?new Intl.DateTimeFormat('zh-CN',{timeZone:review.timeZone,dateStyle:'medium',timeStyle:'short'}).format(new Date(review.dueAt)):null;
   const hasGroupContext=review?.workScopeEvidence.some(evidence=>evidence.kind==='group_context');
   const workScopeLabel=review?.workScope==='group'?'小组完成':review?.workScope==='individual'?'个人完成'
     :hasGroupContext?'待核对（与小组项目有关）':'待核对';
   body=<section className="summary">
    <h2>{item.title}</h2>
    <p>学校提交方式为{statusLabel(learning.mode)} · {statusLabel(learning.submission)} · {statusLabel(learning.grading)}。实际提交人：未知。</p>
    {review&&<p>作业完成方式为{workScopeLabel}。</p>}
    {review?.workScopeEvidence.map(evidence=><p key={evidence.kind}>据{evidence.filename??'作业说明'}，「{evidence.excerpt}」</p>)}
    {due&&<p>截止时间为 {due}（北京时间）。</p>}
    <p><a href={item.resourceMetadata?.targetUrl??item.sourceUrl}>学校原始链接</a></p>
    <pre style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{result.content.text||'当前来源没有正文；请查看以下附件。'}</pre>
    {result.content.nextTextOffset!==null&&<a href={href({...q,textOffset:result.content.nextTextOffset})}>继续正文</a>}
    {review?<section>
     <h3>作业附件</h3>
     {review.attachments.length===0&&<p>未找到已关联的附件。</p>}
     {review.attachments.map(file=><details key={file.downloadUrl}>
      <summary>{file.filename} · {reviewStatus[file.status]}</summary>
      <p>来源为<a href={file.sourceUrl}> {file.sourceTitle}</a>。 <a href={file.downloadUrl} download>下载原件</a></p>
      {file.scanUrl&&<p><a href={file.scanUrl}>查看原页并识别文字</a></p>}
      {'visualReviewPages' in file&&Boolean(file.visualReviewPages?.length)&&<p>请核对原件第 {file.visualReviewPages?.join('、')} 页的图片、公式或表格。</p>}
      {'text' in file&&file.text&&<pre style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{file.text}</pre>}
      {'nextText' in file&&file.nextText&&<p><a href={href({op:'file',...file.nextText})}>继续本组文字</a></p>}
      {'nextPages' in file&&file.nextPages&&<p><a href={href({op:'file',...file.nextPages})}>继续读取后续页</a></p>}
      {!file.hasText&&<p><a href={href({op:'file',...file.readArgs})}>单独查看或重试</a></p>}
     </details>)}
     <h3>{review.help.question}</h3>
     {result.coursework&&<p><a href={result.coursework.workspaceUrl}>打开作业工作区</a>
       {item.kind==='assignment'&&item.sourceUrl?.startsWith('https://ispace.bnbu.edu.cn/mod/assign/view.php?')&&
         <>{' · '}<a href={'/submission?'+new URLSearchParams({courseId:String(item.courseId),itemId:item.id,expectedVerifiedAt:expectedVerifiedAt??''})}>准备提交</a></>}</p>}
     <p>在连接 iSpace 的聊天里，可以说：</p>
     <ul>{review.help.choices.map(choice=><li key={choice}>关于「{item.title}」，{choice}。</li>)}</ul>
    </section>:<ul>{item.resourceMetadata?.resources?.map((r:any,i:number)=>r.kind==='file'?<li key={i}><a href={href({op:'file',courseId,itemId:q.itemId,resourceIndex:i,expectedVerifiedAt})}>{r.name}</a></li>:null)}</ul>}
   </section>;
  }else if(q.op==='records'){
   const records=await readOwnRecords(owner,{courseId});
   body=<section className="summary"><h2>本人学习记录 · {COURSE_NAMES[courseId!]}</h2><p>实时读取时间：{records.verifiedAt}</p><h3>成绩：{statusLabel(records.grades.status)}</h3>{records.grades.status==='failed'&&<p>错误类别：{records.grades.errorCode}，不能解释为无成绩。</p>}<ul>{records.grades.items?.map((g:any,i:number)=><li key={i}>{g.itemname}：{g.grade||'未公布'} {g.feedback}</li>)}</ul><h3>测验：{statusLabel(records.quizzes.status)}</h3>{records.quizzes.items?.length===0&&<p>学校接口本次返回 0 项 Moodle 测验；不代表没有线下测验或其他类型考试。</p>}<ul>{records.quizzes.items?.map((quiz:any)=><li key={quiz.id}>{quiz.name} · 本人尝试：{statusLabel(quiz.ownAttempts.status)}<ul>{quiz.ownAttempts.items?.map((a:any)=><li key={a.id}>第 {a.attempt} 次：{a.state}；原始得分 {a.sumgrades??'未知'}</li>)}</ul></li>)}</ul><h3>签到：暂不支持本人记录</h3><p>尚未确认安全的本人专用读取接口。课程日历中的 Attendance 只是安排，不能当作已签到或缺勤。</p></section>;
  }else{
   const results=await searchCourseItems(owner,{courseId,query:q.query??'',kind:q.kind||undefined,limit:20,offset:Number(q.offset??0),expectedVerifiedAt,dateField:q.dateField??'updated',dateFrom:q.dateFrom?`${q.dateFrom}T00:00:00+08:00`:undefined,dateTo:q.dateTo?`${q.dateTo}T23:59:59+08:00`:undefined});
   body=<><form action="/read"><label>课程 <select name="courseId" defaultValue={q.courseId??''}><option value="">全部课程</option>{Object.entries(COURSE_NAMES).map(([id,name])=><option key={id} value={id}>{String(name)}</option>)}</select></label> <label>关键词 <input name="query" defaultValue={q.query} /></label> <label>类型 <select name="kind" defaultValue={q.kind??''}><option value="">全部</option>{[['assignment','作业'],['page','Page 正文'],['news','公告首帖'],['module','课程模块'],['section','章节说明'],['calendar','课程日历']].map(([v,t])=><option key={v} value={v}>{t}</option>)}</select></label><p><label>日期字段 <select name="dateField" defaultValue={q.dateField??'updated'}><option value="updated">更新时间</option><option value="due">截止时间</option><option value="event">日历开始时间</option></select></label> <label>从 <input name="dateFrom" type="date" defaultValue={q.dateFrom}/></label> <label>至 <input name="dateTo" type="date" defaultValue={q.dateTo}/></label> <button type="submit">搜索</button></p></form><p>找到 {results.total} 项。搜索覆盖已同步正文、标题和文件名；附件内部文字需打开读取。日期缺失的项目不参与日期筛选。</p>{results.items.map((item:any)=><section className="summary" key={`${item.courseId}:${item.id}`}><h2><a href={href({op:'item',courseId:item.courseId,itemId:item.id,expectedVerifiedAt:results.verifiedAt})}>{item.title}</a></h2><p>{COURSE_NAMES[item.courseId]} · {item.kind} · {item.rawDates?.timemodified?`更新于 ${new Date(item.rawDates.timemodified*1000).toISOString()}`:'更新时间未知'}</p><p>{item.description?.slice(0,200)}</p></section>)}{results.nextOffset!==null&&<a href={href({...q,offset:results.nextOffset,expectedVerifiedAt:results.verifiedAt})}>下一页</a>}</>;
  }
  return <main className="shell"><header className="masthead"><h1>课程资料阅读</h1><span className="owner-badge">仅限本人</span></header>{nav}<p>快照：{state.lastVerifiedRead} · {state.freshness==='fresh'?'缓存未过期':'缓存需更新'} · 最近同步：{state.lastResult}。缓存不代表刚刚访问学校。</p><details><summary>本人测验、成绩与签到可读范围</summary><ul>{Object.entries(COURSE_NAMES).map(([id,name])=><li key={id}><a href={href({op:'records',courseId:id})}>{String(name)}：实时核实本人记录</a></li>)}</ul></details>{body}</main>;
 }catch(e){const error=publicError(e);return <main className="shell"><h1>本次读取未完成</h1>{nav}<p>{error.message}</p><p>错误类别：{error.code}。读取失败不能解释为没有变化、没有作业或没有成绩。</p></main>;}
}
