import { authorizeOwner, indexCourseAttachments, json, publicError } from '@/lib/runtime';
import { SafeError } from '@/lib/sync-core.mjs';

export const dynamic = 'force-dynamic';

export async function POST(request:Request){
  try{
    if(request.headers.get('origin')!==new URL(request.url).origin)throw new SafeError('forbidden',403);
    const owner=await authorizeOwner(request.headers);
    const selector=new URL(request.url).searchParams;
    const fields=['courseId','itemId','resourceIndex','expectedVerifiedAt'];
    if([...selector.keys()].some(key=>!fields.includes(key)||selector.getAll(key).length>1))throw new SafeError('invalid_request',400);
    const courseId=selector.has('courseId')?Number(selector.get('courseId')):undefined;
    const isTarget=fields.slice(1).some(key=>selector.has(key));
    if(isTarget&&fields.some(key=>!selector.has(key)))throw new SafeError('invalid_request',400);
    const target=isTarget?{
      courseId,itemId:selector.get('itemId'),resourceIndex:Number(selector.get('resourceIndex')),
      expectedVerifiedAt:selector.get('expectedVerifiedAt'),
    }:undefined;
    return json(await indexCourseAttachments(owner,{courseId,target}));
  }catch(error){
    const failure=publicError(error);
    return json({error:failure.code,message:failure.message},failure.status);
  }
}
