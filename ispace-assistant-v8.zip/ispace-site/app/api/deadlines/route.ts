import {authorizeOwner,readStudyPlan,publicError,json} from '@/lib/runtime';
export const dynamic='force-dynamic';
export async function GET(request:Request){
  try{return json(await readStudyPlan(await authorizeOwner(request.headers)));}
  catch(error){const failure=publicError(error);return json({error:failure.code,message:failure.message},failure.status);}
}
