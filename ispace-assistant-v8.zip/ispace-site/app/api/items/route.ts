import {authorizeOwner, readLatestItems, publicError, json} from "@/lib/runtime";
import {SafeError} from "@/lib/sync-core.mjs";
export const dynamic = "force-dynamic";
export async function GET(request:Request){
  try{
    const owner=await authorizeOwner(request.headers);
    const query=new URL(request.url).searchParams;
    const args:Record<string,unknown>={};
    for(const [key,value] of query){
      if(key in args)throw new SafeError("invalid_request",400);
      args[key]=['courseId','offset','limit'].includes(key)?Number(value):value;
    }
    return json(await readLatestItems(owner,args));
  }catch(error){const failure=publicError(error);return json({error:failure.code,message:failure.message},failure.status);}
}
