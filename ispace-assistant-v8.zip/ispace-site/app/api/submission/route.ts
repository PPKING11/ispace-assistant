import { authorizeOwner, json, publicError } from '@/lib/runtime';
import { confirmSubmission, verifySubmissionReceipt } from '@/lib/submission-service';
import { SafeError } from '@/lib/sync-core.mjs';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    if (request.headers.get('origin') !== new URL(request.url).origin) throw new SafeError('forbidden', 403);
    const owner = await authorizeOwner(request.headers);
    if (request.headers.get('content-type')?.split(';')[0] !== 'application/json') throw new SafeError('invalid_request', 400);
    const text = await request.text();
    if (text.length > 16000) throw new SafeError('invalid_request', 400);
    let parsed;
    try { parsed = JSON.parse(text); } catch { throw new SafeError('invalid_request', 400); }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed) || Object.keys(parsed).length !== 2 || !('input' in parsed)) {
      throw new SafeError('invalid_request', 400);
    }
    if (parsed.action === 'confirm') return json(await confirmSubmission(owner, parsed.input));
    if (parsed.action === 'verify_receipt') return json(await verifySubmissionReceipt(owner, parsed.input));
    throw new SafeError('invalid_request', 400);
  } catch (error) {
    const failure = publicError(error);
    const message = failure.code === 'submission_confirmation_expired'
      ? '提交确认已过期，请重新核对作业和文件。' : failure.message;
    return json({ error: failure.code, message }, failure.status);
  }
}
