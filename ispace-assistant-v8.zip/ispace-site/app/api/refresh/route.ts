import { authorizeOwner, refresh, publicError, json } from "@/lib/runtime";
import { requireRequestBody, SafeError } from "@/lib/sync-core.mjs";
export async function POST(request: Request) {
  try {
    const owner = await authorizeOwner(request.headers);
    if (request.headers.get("origin") !== new URL(request.url).origin) throw new SafeError("forbidden", 403);
    if (!request.headers.get("content-type")?.includes("application/json")) throw new SafeError("invalid_request", 400);
    const body = await request.text();
    if (body.length > 2048) throw new SafeError("invalid_request", 400);
    let input; try { input = JSON.parse(body); } catch { throw new SafeError("invalid_request", 400); }
    return json(await refresh(owner, requireRequestBody(input)));
  } catch (error) { const failure = publicError(error); return json({ error: failure.code, message: failure.message }, failure.status); }
}
