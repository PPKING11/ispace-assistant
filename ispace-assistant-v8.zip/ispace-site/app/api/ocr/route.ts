import { authorizeOwner, json, publicError, saveCourseOcr } from '@/lib/runtime';
import { SafeError } from '@/lib/sync-core.mjs';

export const dynamic = 'force-dynamic';

export async function POST(request:Request){
  try{
    if(request.headers.get('origin')!==new URL(request.url).origin)throw new SafeError('forbidden',403);
    if(request.headers.get('content-type')?.split(';')[0].trim().toLowerCase()!=='application/json')throw new SafeError('invalid_request',415);
    const owner=await authorizeOwner(request.headers);
    const reader=request.body?.getReader();
    if(!reader)throw new SafeError('invalid_request',400);
    const buffer=new Uint8Array(80*1024);
    let size=0;
    try{
      for(;;){
        const part=await reader.read();
        if(part.done)break;
        if(size+part.value.byteLength>buffer.byteLength){
          await reader.cancel();
          throw new SafeError('invalid_request',413);
        }
        buffer.set(part.value,size);
        size+=part.value.length;
      }
    }finally{reader.releaseLock();}
    let body:unknown;
    try{body=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(buffer.subarray(0,size)));}
    catch{throw new SafeError('invalid_request',400);}
    return json(await saveCourseOcr(owner,body));
  }catch(error){
    const failure=publicError(error);
    return json({error:failure.code,message:failure.message},failure.status);
  }
}
