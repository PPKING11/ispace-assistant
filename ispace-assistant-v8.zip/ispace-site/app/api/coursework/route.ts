import { env } from 'cloudflare:workers';
import { allSavedItems, authorizeOwner, json, publicError } from '@/lib/runtime';
import { SafeError } from '@/lib/sync-core.mjs';
import { courseworkVersion, selectCoursework } from '@/lib/coursework-model';
import { exportCoursework } from '@/lib/coursework-export';
import { readCourseworkRecord } from '@/lib/coursework-store';
import { courseworkErrors, writeCoursework } from '@/lib/coursework-workflow';

export const dynamic='force-dynamic';

function storage() {
  if(!env.DB)throw new SafeError('storage_unavailable');
  return env.DB;
}
function rejected(error:unknown) {
  const failure=publicError(error);
  return json({error:failure.code,message:courseworkErrors[failure.code]??failure.message},failure.status);
}
async function receive(request:Request) {
  if(request.headers.get('content-type')?.split(';')[0].trim().toLowerCase()!=='application/json')throw new SafeError('invalid_request',415);
  const reader=request.body?.getReader();
  if(!reader)throw new SafeError('invalid_request',400);
  const buffer=new Uint8Array(384*1024);
  let used=0;
  try{
    for(;;){
      const next=await reader.read();
      if(next.done)break;
      if(used+next.value.length>buffer.length){
        await reader.cancel();
        throw new SafeError('invalid_request',413);
      }
      buffer.set(next.value,used);
      used+=next.value.length;
    }
  }finally{reader.releaseLock();}
  try{return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(buffer.subarray(0,used)));}
  catch{throw new SafeError('invalid_request',400);}
}
export async function POST(request:Request) {
  try{
    if(request.headers.get('origin')!==new URL(request.url).origin)throw new SafeError('forbidden',403);
    const owner=await authorizeOwner(request.headers);
    return json(await writeCoursework(storage(),owner,await receive(request),expected=>allSavedItems(owner,expected)));
  }catch(error){return rejected(error);}
}
export async function GET(request:Request) {
  try{
    const query=new URL(request.url).searchParams;
    if([...query.keys()].some(key=>!['courseId','itemId','version','sourceVersion'].includes(key))||
       ['courseId','itemId','version','sourceVersion'].some(key=>query.getAll(key).length!==1)) throw new SafeError('invalid_request',400);
    const owner=await authorizeOwner(request.headers);
    const selector=selectCoursework({courseId:Number(query.get('courseId')),itemId:query.get('itemId')});
    const record=await readCourseworkRecord(storage(),owner,selector);
    if(!record)throw new SafeError('item_not_found',404);
    const version=courseworkVersion(Number(query.get('version')));
    if(!record.work.draft.trim()||record.version!==version||record.source.sourceVersion!==query.get('sourceVersion'))throw new SafeError('coursework_changed',409);
    const file=exportCoursework(record);
    return new Response(new Uint8Array(file.body),{headers:{
      'Cache-Control':'no-store, private','Content-Type':file.type,
      'Content-Disposition':'attachment; filename="'+file.filename+'"',
      'X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox",
    }});
  }catch(error){return rejected(error);}
}
