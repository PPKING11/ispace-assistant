import { authorizeOwner, json, publicError, saveCourseSelection } from '@/lib/runtime';
import { SafeError } from '@/lib/sync-core.mjs';

export const dynamic='force-dynamic';

export async function POST(request:Request) {
  try {
    if(request.headers.get('origin')!==new URL(request.url).origin)throw new SafeError('forbidden',403);
    const owner=await authorizeOwner(request.headers);
    const body=await request.text();
    if(body.length>750)throw new SafeError('invalid_request',400);
    let input:unknown;
    try {input=JSON.parse(body);}catch {throw new SafeError('invalid_request',400);}
    return json(await saveCourseSelection(owner,input));
  } catch(error) {
    const failure=publicError(error);
    return json({error:failure.code,message:failure.message},failure.status);
  }
}
