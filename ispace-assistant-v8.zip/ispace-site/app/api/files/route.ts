import {env} from 'cloudflare:workers';
import {authorizeOwner,readLatestItems,readCourseScope,localSyncProfile,publicError,json} from '@/lib/runtime';
import {SafeError} from '@/lib/sync-core.mjs';
import {FILE_DOWNLOAD_ENABLED,downloadArguments,selectDownload,fetchCourseFile} from '@/lib/course-download.mjs';
export const dynamic='force-dynamic';
export async function GET(request:Request){
 try{
  const owner=await authorizeOwner(request.headers);
  if(!FILE_DOWNLOAD_ENABLED)throw new SafeError('file_download_not_enabled',503);
  const site=request.headers.get('sec-fetch-site');
  if(site&&site!=='same-origin'&&site!=='none')throw new SafeError('forbidden',403);
  const profile=request.headers.get('x-ispace-sync-profile');
  if(profile!==null&&profile!==await localSyncProfile(owner))throw new SafeError('profile_changed',409);
  const {courseIds}=await readCourseScope(owner);
  const args=downloadArguments(new URL(request.url).searchParams,courseIds);
  const resource=await selectDownload({ownerId:owner,args,readPage:readLatestItems});
  return await fetchCourseFile({resource,token:env.ISPACE_TOKEN,fetcher:fetch});
 }catch(error){const failure=publicError(error);return json({error:failure.code,message:failure.message},failure.status);}
}
