import { allSavedItems, authorizeOwner, json, localSyncProfile, publicError, readCourseScope } from '@/lib/runtime';
import { buildLocalFileManifest } from '@/lib/local-course-files.mjs';
import { SafeError } from '@/lib/sync-core.mjs';

export const dynamic='force-dynamic';

export async function GET(request:Request) {
  try {
    const site=request.headers.get('sec-fetch-site');
    if((site&&site!=='same-origin'&&site!=='none')||new URL(request.url).search)throw new SafeError('forbidden',403);
    const owner=await authorizeOwner(request.headers);
    const [scope,saved,profileId]=await Promise.all([readCourseScope(owner),allSavedItems(owner),localSyncProfile(owner)]);
    const shouldRefresh=scope.enrollmentMode&&scope.configured&&
      (!saved.verifiedAt||Date.now()-Date.parse(saved.verifiedAt)>=12*60*60*1000);
    return json({...await buildLocalFileManifest({...saved,courses:scope.courses,profileId}),shouldRefresh});
  } catch(error) {
    const failure=publicError(error);
    return json({error:failure.code,message:failure.message},failure.status);
  }
}
