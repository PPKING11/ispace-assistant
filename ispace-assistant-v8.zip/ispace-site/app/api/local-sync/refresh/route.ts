import { allSavedItems, authorizeOwner, json, localSyncProfile, publicError, readCourseScope, refresh } from '@/lib/runtime';
import { SafeError, schedulerKey } from '@/lib/sync-core.mjs';

const trustedCompanion='chrome-extension://fcgnjkllmgaomnachmiimchkdjgfenif';

export async function POST(request:Request) {
  try {
    const origin=request.headers.get('origin');
    if(origin!==trustedCompanion||new URL(request.url).search||request.body)
      throw new SafeError('forbidden',403);
    const owner=await authorizeOwner(request.headers);
    if(request.headers.get('x-ispace-sync-profile')!==await localSyncProfile(owner))
      throw new SafeError('profile_changed',409);
    const scope=await readCourseScope(owner);
    if(!scope.enrollmentMode||!scope.configured)return json({status:'not_needed'});
    const saved=await allSavedItems(owner);
    if(saved.verifiedAt&&Date.now()-Date.parse(saved.verifiedAt)<12*60*60*1000)return json({status:'not_needed'});
    return json(await refresh(owner,'local:'+schedulerKey()));
  } catch(error) {
    const failure=publicError(error);
    return json({error:failure.code,message:failure.message},failure.status);
  }
}
