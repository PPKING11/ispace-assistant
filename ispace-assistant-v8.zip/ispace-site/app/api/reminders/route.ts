import { env } from 'cloudflare:workers';
import { authorizeOwner, json, publicError } from '@/lib/runtime';
import { markRemindersRead, reminderInbox, reminderSummary } from '@/lib/reminder-store.mjs';
import { SafeError } from '@/lib/sync-core.mjs';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const owner = await authorizeOwner(request.headers);
    if (!env.DB) throw new SafeError('storage_unavailable');
    const query = new URL(request.url).searchParams;
    if (query.size === 0) return json(await reminderInbox(env.DB, owner));
    if (query.size === 1 && query.get('summary') === '1') return json(await reminderSummary(env.DB, owner));
    throw new SafeError('invalid_request', 400);
  } catch (error) {
    const failure = publicError(error);
    return json({ error: failure.code, message: failure.message }, failure.status);
  }
}

export async function POST(request: Request) {
  try {
    if (request.headers.get('origin') !== new URL(request.url).origin) throw new SafeError('forbidden', 403);
    const owner = await authorizeOwner(request.headers);
    if (!env.DB) throw new SafeError('storage_unavailable');
    if (request.headers.get('content-type')?.split(';')[0] !== 'application/json') throw new SafeError('invalid_request', 400);
    const text = await request.text();
    if (text.length > 12000) throw new SafeError('invalid_request', 400);
    let input: unknown;
    try { input = JSON.parse(text); } catch { throw new SafeError('invalid_request', 400); }
    return json(await markRemindersRead(env.DB, owner, input));
  } catch (error) {
    const failure = publicError(error);
    return json({ error: failure.code, message: failure.message }, failure.status);
  }
}
