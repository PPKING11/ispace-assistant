import { requireChatGPTUser } from '../chatgpt-auth';
import { headers } from 'next/headers';
import { authorizeOwner,readStudyPlan,publicError,readCourseScope,readStatus } from '@/lib/runtime';
import { redirect } from 'next/navigation';
import StudyDashboard from '../study-dashboard';
export const dynamic='force-dynamic';
export default async function Deadlines(){
  await requireChatGPTUser('/deadlines');
  let owner:string;
  try{owner=await authorizeOwner(await headers());}
  catch(error){const failure=publicError(error);return <main className="shell"><section className="notice"><h1>暂时无法打开作业与考试</h1><p>{failure.message}</p></section></main>;}
  const scope=await readCourseScope(owner);
  if(!scope.configured)redirect('/setup');
  try{
    const [plan,status]=await Promise.all([readStudyPlan(owner),readStatus(owner)]);
    return <StudyDashboard initial={plan} scheduledTimes={status.scheduledTimes}/>;
  }catch(error){const failure=publicError(error);return <main className="shell"><section className="notice"><h1>暂时无法打开作业与考试</h1><p>{failure.message}</p></section></main>;}
}
