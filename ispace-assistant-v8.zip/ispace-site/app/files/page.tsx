import {headers} from 'next/headers';
import {requireChatGPTUser} from '../chatgpt-auth';
import {authorizeOwner,readCourseScope,readLatestItems,publicError} from '@/lib/runtime';
export const dynamic='force-dynamic';
export default async function Files(){
 await requireChatGPTUser('/files');
 try{
  const owner=await authorizeOwner(await headers());
  const {courses}=await readCourseScope(owner);
  const COURSE_NAMES:Record<number,string>=Object.fromEntries(courses.map((course:{id:number;name:string})=>[course.id,course.name]));
  const first=await readLatestItems(owner,{limit:50});const items=[...first.items];let offset=first.nextOffset;
  while(offset!==null){const page=await readLatestItems(owner,{offset,limit:50,expectedVerifiedAt:first.verifiedAt});items.push(...page.items);offset=page.nextOffset;}
  return <main className="shell"><header className="masthead"><h1>课程附件</h1><span className="owner-badge">仅限本人</span></header><nav className="study-nav"><a href="/">作业与考试</a><a href="/sync">同步状态</a><a href="/read">课程资料阅读</a><a href="/files" aria-current="page">课程附件</a></nav><p>按需下载，不会提交作业。当前支持 PDF、Office、ZIP、CSV，原文件最大 96 MiB；学校拒绝下载时不会自动扩大权限。</p><p>快照时间：{first.verifiedAt??'暂无有效快照'}。链接失效时请刷新此页。</p>{items.filter((item:any)=>item.resourceMetadata?.resources?.some((r:any)=>r.kind==='file')).map((item:any)=><section className="summary" key={`${item.courseId}:${item.id}`}><h2>{COURSE_NAMES[item.courseId]} · {item.title}</h2><ul>{item.resourceMetadata.resources.map((r:any,index:number)=>r.kind==='file'?<li key={index}><a download href={`/api/files?${new URLSearchParams({courseId:String(item.courseId),itemId:item.id,resourceIndex:String(index),expectedVerifiedAt:first.verifiedAt!})}`}>{r.name||'课程附件'}</a> {r.size!==undefined?`（${Math.ceil(r.size/1024)} KiB）`:''}</li>:null)}</ul></section>)}</main>;
 }catch(error){const failure=publicError(error);return <main className="shell"><h1>暂时无法读取附件索引</h1><p>{failure.message}</p></main>;}
}
