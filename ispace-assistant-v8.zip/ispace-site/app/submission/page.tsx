import { headers } from 'next/headers';
import { requireChatGPTUser } from '../chatgpt-auth';
import { authorizeOwner, publicError } from '@/lib/runtime';
import { submissionOptions } from '@/lib/submission-service';
import SubmissionPanel from './submission-panel';

export const dynamic = 'force-dynamic';

type Query = { courseId?: string; itemId?: string; expectedVerifiedAt?: string };

export default async function SubmissionPage({ searchParams }: { searchParams: Promise<Query> }) {
  const query = await searchParams;
  const resume = new URLSearchParams();
  for (const key of ['courseId', 'itemId', 'expectedVerifiedAt'] as const) {
    const value = query[key];
    if (typeof value === 'string' && value.length <= 40) resume.set(key, value);
  }
  await requireChatGPTUser(resume.size ? '/submission?' + resume : '/submission');
  try {
    const owner = await authorizeOwner(await headers());
    const options = await submissionOptions(owner);
    const requestedAssignment = options.targets.find(row => query.courseId === String(row.courseId) && query.itemId === row.itemId);
    const fresh = query.expectedVerifiedAt === options.verifiedAt;
    return <SubmissionPanel options={options} initialTarget={fresh && requestedAssignment
      ? `${requestedAssignment.courseId}:${requestedAssignment.itemId}` : ''}
      stale={Boolean(query.expectedVerifiedAt && !fresh)} />;
  } catch (error) {
    const failure = publicError(error);
    return <main className="shell"><section className="notice">
      <h1>暂时无法打开作业提交</h1><p>{failure.message}</p>
      <a href="/deadlines">返回作业与考试</a>
    </section></main>;
  }
}
