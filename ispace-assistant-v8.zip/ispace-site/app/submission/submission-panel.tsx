'use client';

import { useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import styles from './submission.module.css';

type Target = {
  courseId: number;
  itemId: string;
  title: string;
  schoolUrl: string;
  team: boolean | null;
  workScope?: 'group' | 'individual' | 'unknown';
  requiresAllTeamMembers: boolean | null;
  hasSeparateSubmit: boolean | null;
};
type LocalFile = { name: string; bytes: number; sha256: string };
type Options = { verifiedAt: string | null; targets: Target[]; courses: readonly { id: number; code: string }[] };
type Permit = { id: string; expiresAt: string; target: Target; files: LocalFile[] };
type Receipt = { status: string; schoolStatus?: string; modifiedAt?: string | null; files?: { name: string; bytes: number | null }[] | null };
type SchoolCheck = {
  receipt: Receipt;
  observation?: {
    readAt: string; submissionVerified: boolean; schoolStatus: string; savedFileCount: number | null;
  };
};

const targetKey = (target: Target) => `${target.courseId}:${target.itemId}`;
const teamLabel = (team: boolean | null) => team === null ? '需在学校页面核对' : team ? '小组提交' : '个人提交';
const workScopeLabel = (scope: Target['workScope']) => scope === 'group' ? '小组完成' : scope === 'individual' ? '个人完成' : '请核对题目和附件';
const number = new Intl.NumberFormat('zh-CN');
const clock = new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', month: 'short', day: 'numeric',
  hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });

async function submissionAction<T>(action: string, input: unknown) {
  const response = await fetch('/api/submission', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, input }),
  });
  const result = await response.json() as T & { message?: string };
  if (!response.ok) throw new Error(result.message ?? '暂时无法完成，请重试。');
  return result;
}

const receiptText: Record<string, string> = {
  school_record_matches_files: '学校显示已提交，文件名和大小与预览一致。',
  school_submitted_files_not_verified: '学校有提交记录，本次文件仍待核对。',
  school_draft: '学校显示草稿，仍待正式提交。',
  school_submission_unconfirmed: '学校未返回已提交回执。',
  school_receipt_unavailable: '暂时无法通过插件读取学校回执，请打开学校页面核对。',
};

export default function SubmissionPanel({ options, initialTarget, stale }: { options: Options; initialTarget: string; stale: boolean }) {
  const [selection, setSelection] = useState(initialTarget);
  const [files, setFiles] = useState<LocalFile[]>([]);
  const [busy, setBusy] = useState('');
  const [feedback, setFeedback] = useState('');
  const [approved, setApproved] = useState(false);
  const [permit, setPermit] = useState<Permit | null>(null);
  const [schoolCheck, setSchoolCheck] = useState<SchoolCheck | null>(null);
  const target = options.targets.find(row => targetKey(row) === selection);
  const courseCode = (courseId: number) => options.courses.find(course => course.id === courseId)?.code ?? courseId;
  const receipt = schoolCheck?.receipt;
  const observation = schoolCheck?.observation;
  const emptySchoolRecord = observation?.submissionVerified && observation.schoolStatus === 'new' && observation.savedFileCount === 0;

  function clearConfirmation() {
    setApproved(false);
    setPermit(null);
    setSchoolCheck(null);
    setFeedback('');
  }

  async function fingerprintFiles(list: FileList | null) {
    clearConfirmation();
    setFiles([]);
    const selected = Array.from(list ?? []);
    if (!selected.length) return;
    if (selected.length > 12 || selected.some(file => file.size === 0)) {
      setFeedback('一次最多核对 12 份非空文件。');
      return;
    }
    setBusy('正在检查文件');
    try {
      const metadata: LocalFile[] = [];
      const names = new Set<string>();
      for (const file of selected) {
        const filename = file.name.normalize('NFC').toLowerCase();
        if (names.has(filename)) throw new Error('请为同名文件改名后再选择。');
        names.add(filename);
        const signature = await crypto.subtle.digest('SHA-256', await file.arrayBuffer());
        const sha256 = [...new Uint8Array(signature)].map(byte => byte.toString(16).padStart(2, '0')).join('');
        metadata.push({ name: file.name, bytes: file.size, sha256 });
      }
      setFiles(metadata);
    } catch (error) {
      setFeedback(error instanceof Error ? error.message : '暂时无法检查文件。');
    } finally { setBusy(''); }
  }

  async function confirm() {
    if (!target || !options.verifiedAt || !files.length || !approved || permit) return;
    setBusy('正在生成确认编号');
    setFeedback('');
    try {
      const selector = { courseId: target.courseId, itemId: target.itemId, expectedVerifiedAt: options.verifiedAt };
      const result = await submissionAction<{ permit: Permit }>('confirm', { selector, files });
      setPermit(result.permit);
    } catch (error) { setFeedback(error instanceof Error ? error.message : '暂时无法确认。'); }
    finally { setBusy(''); }
  }

  async function verify() {
    if (!permit) return;
    setFeedback('');
    setSchoolCheck(null);
    setBusy('正在读取学校状态');
    try { setSchoolCheck(await submissionAction<SchoolCheck>('verify_receipt', { permitId: permit.id })); }
    catch (error) { setFeedback(error instanceof Error ? error.message : '暂时无法读取学校回执。'); }
    finally { setBusy(''); }
  }

  return <main className="shell study-shell">
    <header className="masthead"><div className="wordmark">
      <span className="brand">iSpace<span className="brand-dot">.</span></span><span className="private-label">学习日程</span>
    </div></header>
    <nav className="study-nav" aria-label="学习日程">
      <a href="/deadlines">作业与考试</a><a href="/read">课程资料阅读</a><a href="/submission" aria-current="page">准备提交</a>
    </nav>
    <div className="study-heading"><h1>准备提交作业</h1></div>
    <p className="snapshot-caption">核对作业和文件后，在学校 iSpace 页面完成提交。</p>
    {stale && <p className="inferred-note">课程记录已更新，请重新选择当前作业。</p>}
    {options.targets.length === 0 ? <p className="empty-result">当前课程记录没有可用的 iSpace 作业提交入口。</p> : <>
      <section className={styles.panel}>
        <label className={styles.field}>选择作业
          <select value={selection} disabled={Boolean(busy)} onChange={event => {
            setSelection(event.currentTarget.value);
            setFiles([]);
            clearConfirmation();
          }}>
            <option value="">请选择课程作业</option>
            {options.targets.map(row => <option key={targetKey(row)} value={targetKey(row)}>
              {courseCode(row.courseId)} · {row.title}
            </option>)}
          </select>
        </label>
        {target && <>
          <dl className={styles.details}>
            <div><dt>课程</dt><dd>{courseCode(target.courseId)}</dd></div>
            <div><dt>学校上传入口</dt><dd>{teamLabel(target.team)}</dd></div>
            <div><dt>题面完成方式</dt><dd>{workScopeLabel(target.workScope)}</dd></div>
          </dl>
          {target.team && <p>{target.requiresAllTeamMembers ? '学校设定为所有组员分别确认提交。' : '此作业可能更新小组共用的提交记录。请先核对组内最终定稿。'}</p>}
          {target.team !== true && target.workScope === 'group' && <p>题面要求小组完成。先核对组内定稿、上传人及是否已有提交。</p>}
          <a href={target.schoolUrl} target="_blank" rel="noopener noreferrer" className={styles.schoolLink}>
            查看学校的文件格式、数量和大小要求 <ArrowUpRight size={14} aria-hidden="true" />
          </a>
          <label className={styles.field}>选择最终文件
            <input key={selection} type="file" multiple disabled={Boolean(busy)} onChange={event => void fingerprintFiles(event.currentTarget.files)} />
          </label>
          <p className={styles.subtle}>此页在本机计算文件指纹，保存文件名、大小和指纹。</p>
          {files.length > 0 && <ul className={styles.files}>
            {files.map(file => <li key={file.name}>
              <strong>{file.name}</strong><span>{number.format(file.bytes)} 字节</span><code>SHA-256 {file.sha256}</code>
            </li>)}
          </ul>}
          {files.length > 0 && !permit && <>
            <label className={styles.approval}><input type="checkbox" checked={approved} disabled={Boolean(busy)}
              onChange={event => setApproved(event.currentTarget.checked)} />我已确认上述课程、作业、提交方式和文件。</label>
            <button type="button" className="snapshot-reload" disabled={!approved || Boolean(busy)} onClick={() => void confirm()}>
              确认这份文件清单
            </button>
          </>}
        </>}
      </section>
    </>}
    {permit && <section className={styles.panel}>
      <h2>提交清单已确认</h2>
      <p>确认编号 <code>{permit.id}</code>，北京时间 {clock.format(new Date(permit.expiresAt))} 前有效。让聊天助手协助时，可以把编号发给它。</p>
      <p>请用本人已登录的 Chrome 打开学校页面，核对文件和提交方式。有些作业保存后就会提交，有些需要另按一次正式提交。</p>
      <div className={styles.actions}>
        <a href={permit.target.schoolUrl} target="_blank" rel="noopener noreferrer" className={styles.schoolLink}>
          打开 iSpace 作业 <ArrowUpRight size={14} aria-hidden="true" />
        </a>
        <button type="button" className="snapshot-reload" disabled={Boolean(busy)} onClick={() => void verify()}>核对学校提交状态</button>
      </div>
      {receipt && <div role="status" className={styles.receipt}>
        <strong>{emptySchoolRecord ? '核对时学校显示尚未提交，未列已保存文件。请在操作前复核学校页面。' : receiptText[receipt.status] ?? '请到学校页面核对提交状态。'}</strong>
        {observation && <p>本次核对时间 {clock.format(new Date(observation.readAt))}</p>}
        {receipt.modifiedAt && <p>学校记录更新时间 {clock.format(new Date(receipt.modifiedAt))}</p>}
        {receipt.files?.length ? <ul>{receipt.files.map((file, i) => <li key={`${i}:${file.name}`}>{file.name}
          {file.bytes !== null && ` · ${number.format(file.bytes)} 字节`}</li>)}</ul> : null}
      </div>}
    </section>}
    {(busy || feedback) && <p role="status">{feedback || busy}</p>}
  </main>;
}
