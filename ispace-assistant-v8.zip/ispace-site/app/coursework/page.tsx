import { headers } from 'next/headers';
import { env } from 'cloudflare:workers';
import { requireChatGPTUser } from '@/app/chatgpt-auth';
import { authorizeOwner, publicError } from '@/lib/runtime';
import { SafeError } from '@/lib/sync-core.mjs';
import { selectCoursework } from '@/lib/coursework-model';
import { describeCoursework, listCoursework, readCourseworkRecord, readCourseworkRules } from '@/lib/coursework-store';
import CourseworkToolbar, { CourseworkEditor, CourseworkRulesEditor } from './widgets';

export const dynamic='force-dynamic';
const pageLink=(courseId:number,itemId:string)=>'/coursework?'+new URLSearchParams({courseId:String(courseId),itemId});
const stages={planned:'已准备清单',in_progress:'进行中',ready:'待交'};
const beijing=new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',dateStyle:'medium',timeStyle:'short'});

export default async function CourseworkPage({searchParams}:{searchParams:Promise<Record<string,string|undefined>>}) {
  const query=await searchParams;
  const target=query.courseId&&query.itemId?pageLink(Number(query.courseId),query.itemId):'/coursework';
  await requireChatGPTUser(target);
  const nav=<nav className="study-nav"><a href="/">作业与考试</a><a href="/read">课程资料阅读</a><a href="/coursework">作业工作台</a><a href="/sync">同步状态</a></nav>;
  try{
    const owner=await authorizeOwner(await headers());
    const db=env.DB;
    if(!db)throw new SafeError('storage_unavailable');
    let content;
    if(query.courseId||query.itemId){
      const selector=selectCoursework({courseId:Number(query.courseId),itemId:query.itemId});
      const work=await readCourseworkRecord(db,owner,selector);
      content=work?<CourseworkEditor initial={await describeCoursework(db,owner,work)}/>:<section className="summary">
        <h2>整理这份作业</h2><p>从已同步的学校数据整理题目要求、关联附件和作业清单。</p>
        <CourseworkToolbar selector={selector} label="生成作业清单"/>
      </section>;
    } else{
      const offset=Number(query.offset??'0');
      const [listing,prefs]=await Promise.all([listCoursework(db,owner,offset),readCourseworkRules(db,owner)]);
      content=<>
        <CourseworkRulesEditor initial={prefs}/>
        <section className="summary" style={{marginTop:16}}>
          <h2>已保存的作业</h2>
          {listing.items.length===0?<p>你可以从<a href="/read?kind=assignment">课程作业</a>打开一份作业，也可以在同步后查看新作业清单。</p>:<ul style={{display:'grid',gap:12,marginTop:8}}>
            {listing.items.map(item=><li key={item.courseId+':'+item.itemId}>
              <a href={pageLink(item.courseId,item.itemId)}>{item.title}</a>
              {' · '}{stages[item.stage]}{item.group?' · 小组作业':''}{item.hasDraft?' · 有草稿':''}
              {item.dueAt&&<small style={{display:'block'}}>学校截止时间 {beijing.format(new Date(item.dueAt))}</small>}
            </li>)}
          </ul>}
          {listing.nextOffset!==null&&<p><a href={'/coursework?offset='+listing.nextOffset}>下一页</a></p>}
        </section>
      </>;
    }
    return <main className="shell">
      <header className="masthead"><h1>作业工作台</h1><span className="owner-badge">我的作业</span></header>
      {nav}{content}
    </main>;
  }catch(error){
    const failure=publicError(error);
    return <main className="shell"><header className="masthead"><h1>作业工作台</h1></header>
      {nav}<p role="alert">{failure.message}</p></main>;
  }
}
