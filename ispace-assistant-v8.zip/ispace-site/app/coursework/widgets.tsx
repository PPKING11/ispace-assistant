'use client';

import { useState, type FormEvent } from 'react';
import type { CourseworkRules, CourseworkSelector, Work } from '@/lib/coursework-model';
import type { describeCoursework, readCourseworkRules } from '@/lib/coursework-store';

type Detail = Awaited<ReturnType<typeof describeCoursework>>;
type RulesState = Awaited<ReturnType<typeof readCourseworkRules>>;
const area='grid gap-2 py-2';
const field='w-full rounded-md border border-[var(--border)] bg-white px-3 py-2 text-[var(--foreground)]';

async function save<T=unknown>(body:Record<string,unknown>):Promise<T> {
  const response=await fetch('/api/coursework',{
    method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),
  });
  const result=await response.json();
  if(!response.ok)throw new Error((result as {message?:string}|null)?.message??'暂时无法保存，请稍后再试。');
  return result as T;
}

export default function CourseworkToolbar({selector,label}:{selector:CourseworkSelector;label:string}) {
  const [pending,setPending]=useState(false);
  const [message,setMessage]=useState('');
  async function prepare(){
    setPending(true);setMessage('');
    try{
      await save({action:'prepare',...selector});
      window.location.reload();
    }catch(error){setMessage(error instanceof Error?error.message:'暂时无法读取作业。');}
    finally{setPending(false);}
  }
  return <div className="mt-3 flex flex-wrap items-center gap-3">
    <button className="snapshot-reload" type="button" onClick={prepare} disabled={pending}>{pending?'正在整理…':label}</button>
    {message&&<p className="load-error" role="alert">{message}</p>}
  </div>;
}

const labels:Record<keyof CourseworkRules,string>={
  useCourseMaterials:'按课件、题目和评分要求作答',
  answerExactQuestions:'按题号和小问作答',
  answersOnly:'正文只写题目要求的内容',
  queueNewAssignments:'同步时自动整理新作业清单',
};
export function CourseworkRulesEditor({initial}:{initial:RulesState}){
  const [current,setCurrent]=useState(initial);
  const [pending,setPending]=useState(false);
  const [status,setStatus]=useState({text:'',error:false});
  const [rules,setRules]=useState(initial.rules);

  async function submit(event:FormEvent){
    event.preventDefault();setPending(true);setStatus({text:'',error:false});
    try{
      const next=await save<RulesState>({action:'save_rules',version:current.version,rules});
      setCurrent(next);setStatus({text:'规则已保存。',error:false});
    }catch(error){setStatus({text:error instanceof Error?error.message:'暂时无法保存。',error:true});}
    finally{setPending(false);}
  }

  return <form className="summary" onSubmit={submit}>
    <h2>默认作业规则</h2>
    <fieldset disabled={pending} className="mb-3 grid gap-2 py-3">
      {(Object.keys(labels) as (keyof CourseworkRules)[]).map(key=><label key={key} className="flex items-start gap-2">
        <input type="checkbox" className="mt-1" checked={rules[key]} onChange={event=>setRules({...rules,[key]:event.target.checked})}/>
        {labels[key]}
      </label>)}
    </fieldset>
    <button className="snapshot-reload" disabled={pending} type="submit">保存规则</button>
    <p role={status.error?'alert':'status'}>{status.text}</p>
  </form>;
}

const requirementsLabels={deliverable:'交付要求',grading:'评分要求',policy:'协助规则'};
const formats:Record<Work['draftFormat'],string>={docx:'Word (.docx)',text:'文本 (.txt)',markdown:'Markdown (.md)',python:'Python (.py)',r:'R (.R)',csv:'CSV (.csv)'};

export function CourseworkEditor({initial}:{initial:Detail}){
  const [current,setCurrent]=useState(initial);
  const [work,setWork]=useState(initial.work);
  const [message,setMessage]=useState({text:'',error:false});
  const [pending,setPending]=useState(false);
  const [task,setTask]=useState('');
  const [reviewChange,setReviewChange]=useState(false);
  const source=current.source;
  const selector={courseId:source.courseId,itemId:source.itemId};
  const query=new URLSearchParams({courseId:String(source.courseId),itemId:source.itemId,expectedVerifiedAt:current.verifiedAt});
  const exportQuery=new URLSearchParams({courseId:String(source.courseId),itemId:source.itemId,
    version:String(current.version),sourceVersion:source.sourceVersion});
  const edit=<K extends keyof Work>(key:K,value:Work[K])=>setWork(previous=>({...previous,[key]:value}));

  async function submit(event:FormEvent){
    event.preventDefault();
    setMessage({text:'',error:false});setPending(true);
    try{
      const {draftSourceVersion:_,draft,...fields}=work;
      const next=await save<Detail>({action:'save_progress',...selector,version:current.version,
        sourceVersion:source.sourceVersion,work:{...fields,...((draft!==current.work.draft||reviewChange)?{draft}:{})}});
      setCurrent(next);setWork(next.work);setReviewChange(false);
      setMessage({text:'已保存。',error:false});
    }catch(error){setMessage({text:error instanceof Error?error.message:'暂时无法保存。',error:true});}
    finally{setPending(false);}
  }

  return <div className="grid gap-4">
    <section className="summary min-w-0">
      <h2>{source.title}</h2>
      <p>{source.group?'小组作业 · 保存自己的分工和版本':'个人作业'}</p>
      <div className="my-2 flex flex-wrap gap-3">
        <a href={'/read?op=item&'+query}>读题目、评分要求和附件</a>
        {source.schoolUrl&&<a href={source.schoolUrl}>学校原始页面</a>}
      </div>
      {!current.sourceCurrent&&<div role="status" className="mt-2">
        学校快照已更新。载入最新要求后可以继续保存。
        <CourseworkToolbar selector={selector} label="刷新这份作业"/>
      </div>}
      {source.requirements.length>0&&<details className="mt-2">
        <summary>已找到的要求和来源</summary>
        <ul className="grid gap-2 p-2">{source.requirements.map((entry,index)=><li key={index} className="break-words">
          {requirementsLabels[entry.kind]} · {entry.filename??'学校作业说明'}<br/>{entry.excerpt}
        </li>)}</ul>
      </details>}
      {source.attachments.length>0&&<details className="mt-2">
        <summary>关联附件</summary>
        <ul className="grid gap-1 p-2">{source.attachments.map(item=><li key={item.itemId+':'+item.resourceIndex} className="break-all">
          <a href={'/read?op=file&'+new URLSearchParams({...Object.fromEntries(query),itemId:item.itemId,resourceIndex:String(item.resourceIndex)})}>{item.filename}</a>
        </li>)}</ul>
      </details>}
      <details className="mt-2">
        <summary>你的作答规则</summary>
        <ul className="grid gap-1 p-2">{current.instructions.map(rule=><li key={rule}>{rule}</li>)}</ul>
      </details>
    </section>
    <form onSubmit={submit} className="summary min-w-0">
      <h2>进度和草稿</h2>
      <fieldset disabled={pending||!current.sourceCurrent}>
        <label className={area}>
          作业进度
          <select className={field} value={work.stage} onChange={event=>edit('stage',event.target.value as Work['stage'])}>
            <option value="planned">已准备清单</option>
            <option value="in_progress">进行中</option>
            <option value="ready">待交</option>
          </select>
        </label>
        {source.group&&<label className={area}>
          我的分工
          <textarea className={field} rows={2} maxLength={500} value={work.role} onChange={event=>edit('role',event.target.value)}/>
        </label>}
        <div className="py-2">
          <h3>待办</h3>
          <ul className="my-2 grid gap-2">
           {work.checklist.map((entry,index)=><li key={index} className="flex items-start gap-2">
             <label className="flex grow items-start gap-2">
               <input type="checkbox" className="mt-1" checked={entry.done} onChange={event=>edit('checklist',work.checklist.map((item,i)=>i===index?{...item,done:event.target.checked}:item))}/>
               {entry.text}
             </label>
             <button className="shrink-0 text-sm underline" type="button" aria-label={'移除待办 '+entry.text} onClick={()=>edit('checklist',work.checklist.filter((_,i)=>i!==index))}>移除</button>
           </li>)}
          </ul>
          {work.checklist.length<30&&<div className="flex flex-wrap items-center gap-2">
            <input className={field} aria-label="新增待办内容" placeholder="新待办" maxLength={250} value={task} onChange={event=>setTask(event.target.value)}/>
            <button className="snapshot-reload" type="button" disabled={!task.trim()} onClick={()=>{edit('checklist',[...work.checklist,{text:task.trim(),done:false}]);setTask('');}}>添加待办</button>
          </div>}
        </div>
        <label className={area}>计划<textarea className={field} rows={3} maxLength={6000} value={work.plan} onChange={event=>edit('plan',event.target.value)}/></label>
        <label className={area}>进度记录<textarea className={field} rows={3} maxLength={5000} value={work.notes} onChange={event=>edit('notes',event.target.value)}/></label>
        <label className={area}>
          老师允许的 AI 协助范围
          <select className={field} value={work.assistance} onChange={event=>edit('assistance',event.target.value as Work['assistance'])}>
            <option value="unknown">待核对</option><option value="planning_only">可规划</option>
            <option value="drafting_allowed">可协助起草</option><option value="prohibited">老师要求独立完成</option>
          </select>
        </label>
        <label className={area}>
          AI 使用申报
          <select className={field} value={work.disclosure} onChange={event=>edit('disclosure',event.target.value as Work['disclosure'])}>
            <option value="unknown">待核对</option>
            <option value="required">老师要求申报</option><option value="not_required">老师说明无需申报</option>
          </select>
        </label>
        <label className={area}>课程规则依据
          <textarea className={field} rows={2} maxLength={1000} placeholder="写下老师的原话或评分表位置" value={work.policySource} onChange={event=>edit('policySource',event.target.value)}/>
        </label>
        {current.policy.notice&&<p role="status">{current.policy.notice}</p>}
        <label className={area}>
          文稿来源
          <select className={field} value={work.draftKind} onChange={event=>edit('draftKind',event.target.value as Work['draftKind'])}>
            <option value="personal">自己写的</option><option value="ai_assisted">经 AI 协助</option>
          </select>
        </label>
        <label className={area}>
          导出格式
          <select className={field} value={work.draftFormat} onChange={event=>edit('draftFormat',event.target.value as Work['draftFormat'])}>
            {(Object.keys(formats) as Work['draftFormat'][]).map(format=><option key={format} value={format}>{formats[format]}</option>)}
          </select>
        </label>
        <label className={area}>
          文稿
          <textarea className={field} rows={12} maxLength={60000} value={work.draft} onChange={event=>edit('draft',event.target.value)}/>
        </label>
        {current.sourceChangedSinceDraft&&<label className="my-2 flex items-start gap-2">
          <input type="checkbox" className="mt-1" checked={reviewChange} onChange={event=>setReviewChange(event.target.checked)}/>
          我已核对更新后的要求，当前稿件适用于新版本。
        </label>}
        <button className="snapshot-reload" type="submit" disabled={pending||!current.sourceCurrent}>保存作业进度</button>
      </fieldset>
      <div className="mt-2 flex flex-wrap gap-3">
        {current.work.draft.trim()&&<a href={'/api/coursework?'+exportQuery} download>下载已保存文稿</a>}
        <span role={message.error?'alert':'status'} className={message.error?'load-error':undefined}>{message.text}</span>
      </div>
      <p className="mt-2">在已连接 iSpace 的聊天里，可以说「继续做 {source.title}，先读取作业工作台」。</p>
    </form>
  </div>;
}
