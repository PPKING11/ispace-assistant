import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "iSpace · 作业与考试",
  description: "查看个人课程的作业截止、考试时间和已核实的提交状态。",
  robots: { index: false, follow: false },
  icons: {
    icon: "/favicon.png",
    shortcut: "/favicon.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
