import {requireChatGPTUser} from '../chatgpt-auth';
import {headers} from 'next/headers';
import {readStatus,authorizeOwner,publicError} from '@/lib/runtime';
import Dashboard from '../sync-dashboard';
export const dynamic='force-dynamic';
export default async function Sync(){
  await requireChatGPTUser('/sync');
  try{return <Dashboard initial={await readStatus(await authorizeOwner(await headers()))} />;}
  catch(error){const failure=publicError(error);return <main className="shell"><section className="notice"><h1>暂时无法打开</h1><p>{failure.message}</p></section></main>;}
}
