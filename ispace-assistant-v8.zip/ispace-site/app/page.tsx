export { default, dynamic } from './deadlines/page';
