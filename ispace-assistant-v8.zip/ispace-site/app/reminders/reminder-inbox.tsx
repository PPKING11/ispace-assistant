'use client';

import { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, Bell, Check } from 'lucide-react';
import styles from './reminders.module.css';

type DateTime = { date: string; time: string | null };
type Reminder = {
  id: string;
  occurredAt: string;
  readAt: string | null;
} & (
  | { kind: 'deadline'; message: { title: string; sourceUrl: string | null; before: DateTime | null; after: DateTime | null; announced: DateTime[]; needsReview: boolean } }
  | { kind: 'attachment'; message: { title: string; sourceUrl: string | null; count: number; filenames: string[] } }
  | { kind: 'sync_failure'; message: { status: string } }
);
export type Inbox = { unread: number; events: Reminder[] };
const changeEvent = 'ispace-reminders-updated';
const notificationKey = 'ispace-active-reminder-notifications';
const timeZone = 'Asia/Shanghai';
const occurredAt = new Intl.DateTimeFormat('zh-CN', {
  timeZone, month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
});

function notificationEnabled() {
  try { return typeof Notification !== 'undefined' && Notification.permission === 'granted' && localStorage.getItem(notificationKey) === '1'; }
  catch { return false; }
}

function notifyUnread(unread: number) {
  if (!notificationEnabled()) return;
  try { new Notification('iSpace 有新提醒', { body: `当前有 ${unread} 条未读提醒。`, tag: 'ispace-course-reminder' }); }
  catch { /* The in-app count remains available when the browser restricts system notifications. */ }
}

function pollReminderUpdates<T>(summary: boolean, apply: (data: T) => void) {
  let request: AbortController | undefined;
  const refresh = async () => {
    request?.abort();
    const pending = new AbortController();
    request = pending;
    try {
      const response = await fetch(summary ? '/api/reminders?summary=1' : '/api/reminders',
        { cache: 'no-store', signal: pending.signal });
      if (response.ok && request === pending) apply(await response.json() as T);
    } catch { /* Keep the latest successful view until a later poll. */ }
  };
  void refresh();
  const timer = window.setInterval(refresh, 60000);
  window.addEventListener('focus', refresh);
  window.addEventListener(changeEvent, refresh);
  return () => {
    request?.abort();
    window.clearInterval(timer);
    window.removeEventListener('focus', refresh);
    window.removeEventListener(changeEvent, refresh);
  };
}

export function RemindersLink() {
  const [unread, setUnread] = useState<number | null>(null);
  const previous = useRef<number | null>(null);
  useEffect(() => pollReminderUpdates<{ unread: number }>(true, ({ unread }) => {
    if (previous.current !== null && unread > previous.current) notifyUnread(unread);
    previous.current = unread;
    setUnread(unread);
  }), []);
  return <a href="/reminders">提醒{unread ? <span aria-live="polite">（{unread}）</span> : null}</a>;
}

const readableDate = (date: DateTime | null) => date ? `${date.date} ${date.time ?? '时间未注明'}` : '暂无已确认日期';
const syncMessage: Record<string, string> = {
  missing_credential: '请检查学校连接凭据。',
  connection_unverified: '请检查学校连接是否已验证。',
  source_auth_failed: '学校登录授权已失效或不允许读取，请检查连接。',
  source_incomplete: '学校只返回了部分数据，请检查同步状态。',
  source_timeout: '读取学校数据超时，请检查同步状态。',
  source_unavailable: '暂时无法读取学校数据，请检查同步状态。',
};

function ReminderMessage({ event }: { event: Reminder }) {
  if (event.kind === 'sync_failure') {
    return <>
      <h2>课程同步失败</h2>
      <p>{syncMessage[event.message.status] ?? '课程资料同步未完成，请查看同步详情。'}</p>
      <a href="/sync">查看同步状态 <ArrowUpRight size={13} aria-hidden="true" /></a>
    </>;
  }
  const sourceUrl = event.message.sourceUrl;
  return <>
    <span className={styles.category}>{event.kind === 'deadline' ? '截止日期变化' : '附件更新'}</span>
    <h2>{event.message.title}</h2>
    {event.kind === 'deadline' ? <>
      <p>{readableDate(event.message.before)} → {readableDate(event.message.after)}</p>
      {event.message.announced.length > 0 && <p>课程改期说明为 {event.message.announced.map(readableDate).join('、')}。</p>}
      {event.message.needsReview && <p className={styles.warning}>日期来源待核对。</p>}
    </> : <p>{event.message.filenames.join('、')}{event.message.count > event.message.filenames.length &&
      ` 等 ${event.message.count} 份文件`}</p>}
    <a href={sourceUrl ?? (event.kind === 'deadline' ? '/deadlines' : '/read')}
      target={sourceUrl ? '_blank' : undefined} rel={sourceUrl ? 'noopener noreferrer' : undefined}>
      {sourceUrl ? '查看学校来源' : '查看对应资料'} <ArrowUpRight size={13} aria-hidden="true" />
    </a>
  </>;
}

export default function ReminderInbox({ initial }: { initial: Inbox }) {
  const [inbox, setInbox] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [notify, setNotify] = useState(false);
  const previous = useRef(initial.unread);

  useEffect(() => {
    setNotify(notificationEnabled());
    return pollReminderUpdates<Inbox>(false, data => {
      if (data.unread > previous.current) notifyUnread(data.unread);
      previous.current = data.unread;
      setInbox(data);
    });
  }, []);

  async function markDisplayedRead() {
    const ids = inbox.events.filter(event => !event.readAt).map(event => event.id);
    setBusy(true);
    setFeedback('');
    try {
      const response = await fetch('/api/reminders', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ids }),
      });
      if (!response.ok) throw new Error('mark_failed');
      window.dispatchEvent(new Event(changeEvent));
    } catch {
      setFeedback('暂时无法更新已读状态，请重试。');
    } finally { setBusy(false); }
  }

  async function toggleNotifications() {
    setFeedback('');
    try {
      if (notify) {
        localStorage.removeItem(notificationKey);
        setNotify(false);
        return;
      }
      if (typeof Notification === 'undefined' || await Notification.requestPermission() !== 'granted') {
        setFeedback('此浏览器未允许桌面通知。');
        return;
      }
      localStorage.setItem(notificationKey, '1');
      setNotify(true);
    } catch { setFeedback('此浏览器未开启桌面通知。'); }
  }

  return <main className="shell study-shell">
    <header className="masthead">
      <div className="wordmark"><span className="brand">iSpace<span className="brand-dot">.</span></span><span className="private-label">学习日程</span></div>
    </header>
    <nav className="study-nav" aria-label="学习日程">
      <a href="/deadlines">作业与考试</a><a href="/read">课程资料阅读</a><a href="/sync">同步状态</a>
      <a href="/reminders" aria-current="page">提醒</a>
    </nav>
    <div className="study-heading">
      <h1>课程提醒</h1>
      <div className={styles.actions}>
        <button className="snapshot-reload" onClick={() => void toggleNotifications()}><Bell size={14} aria-hidden="true" />
          {notify ? '关闭桌面通知' : '开启桌面通知'}</button>
        <button className="snapshot-reload" onClick={() => void markDisplayedRead()}
          disabled={busy || inbox.unread === 0}><Check size={14} aria-hidden="true" />将本页标为已读</button>
      </div>
    </div>
    <p className="snapshot-caption" aria-live="polite">{inbox.unread} 条未读 · 北京时间。打开插件页面时可接收桌面通知。</p>
    {feedback && <p role="status">{feedback}</p>}
    {inbox.events.length === 0
      ? <p className="empty-result">暂无课程提醒。下一次同步发现变化后会显示在这里。</p>
      : <ul className={styles.list}>
        {inbox.events.map(event => <li key={event.id} className={styles.entry}>
          <div className={styles.when}>
            <time dateTime={event.occurredAt}>{occurredAt.format(new Date(event.occurredAt))}</time>
            {!event.readAt && <span className={styles.unread}>未读</span>}
          </div>
          <ReminderMessage event={event} />
        </li>)}
      </ul>}
  </main>;
}
