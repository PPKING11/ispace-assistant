import { env } from 'cloudflare:workers';
import { headers } from 'next/headers';
import { requireChatGPTUser } from '../chatgpt-auth';
import { authorizeOwner, publicError } from '@/lib/runtime';
import { reminderInbox } from '@/lib/reminder-store.mjs';
import { SafeError } from '@/lib/sync-core.mjs';
import ReminderInbox from './reminder-inbox';
import type { Inbox } from './reminder-inbox';

export const dynamic = 'force-dynamic';

export default async function RemindersPage() {
  await requireChatGPTUser('/reminders');
  try {
    const owner = await authorizeOwner(await headers());
    if (!env.DB) throw new SafeError('storage_unavailable');
    const data = await reminderInbox(env.DB, owner) as Inbox;
    return <ReminderInbox initial={data} />;
  } catch (error) {
    const failure = publicError(error);
    return <main className="shell"><section className="notice">
      <h1>暂时无法打开提醒</h1><p>{failure.message}</p>
      <a href="/deadlines">返回作业与考试</a>
    </section></main>;
  }
}
