import {siteOrigin, SyncError} from './protocol.mjs';

const byId = id => document.getElementById(id);
const origin = byId('origin');
const state = byId('state');
const form = byId('folders');
const root = byId('root');
const year = byId('year');
const semester = byId('semester');
const fixedTerm = byId('fixedTerm');
const automatic = byId('automatic');
const autoIntervalMinutes = byId('autoIntervalMinutes');
const autoDailyLimit = byId('autoDailyLimit');
const sync = byId('sync');
const sample = byId('sample');
let account;

const descriptions = {
  busy: '正在执行另一项下载，请稍后再试。',
  invalid_origin: '请输入完整的 iSpace 插件站点地址。',
  site_permission: '请允许扩展访问你输入的站点。',
  sign_in: '请在本 Chrome 窗口登录你的 iSpace 插件站点，然后再次检查。',
  offline: '暂时连不上站点，联网后可以重试。',
  host_missing: '没有连接到 Windows 本机助手。请先完成本机助手安装。',
  host_timeout: 'Windows 本机助手还没有返回结果，请重试。',
  invalid_manifest: '站点没有返回可用的文件清单。',
  manifest_unavailable: '站点暂时无法提供课程清单。',
  endpoint_unavailable: '这个站点版本还未提供自动下载入口。',
  setup_required: '请先保存文件夹设置。',
  profile_changed: '站点里的账号发生了变化，请重新检查连接。',
  invalid_root: '请选择有效的本地文件夹路径。',
  invalid_term: '请选择有效的年级和学期。',
  invalid_auto_schedule: '检查间隔可填 5–1440 分钟，每日次数可填 0–288 次。',
  folder_unavailable: '无法访问所选文件夹，请选择可写的文件夹。',
  root_in_use: '这个归档目录已经由另一个 iSpace 账号使用，请选其他目录。',
  reparse_path: '该路径包含链接或重定向，请选择实际的本地文件夹。',
  download_permission: '登录或课程资料已更新，请检查登录后重试。',
  no_sample: '已核实的清单里没有符合条件的课件 PDF。试下载需要一份大小已知且不超过 5 MiB 的课件。',
  sample_invalid_pdf: '站点返回的内容不是有效的课件 PDF。',
  sample_paused: '试下载已暂停。',
  download_incomplete: '试下载的文件大小与清单不符。',
  download_integrity: '试下载的文件校验未通过。',
};

function showError(error) {
  state.textContent = descriptions[error?.code] ?? '本机操作未完成，请检查文件夹和登录状态后重试。';
}

async function send(type, data = {}) {
  const reply = await chrome.runtime.sendMessage({type, ...data});
  if (!reply?.ok) throw new SyncError(reply?.error ?? 'local_error');
  return reply.result;
}

function showDownload(result) {
  if (result.error) return showError({code: result.error});
  const parts = ['已保存 ' + result.saved + ' 份'];
  if (result.failed) parts.push(result.failed + ' 份下载失败，可重试');
  if (result.tooLarge) parts.push(result.tooLarge + ' 份超过下载上限');
  if (result.invalid) parts.push(result.invalid + ' 份没有可用的下载信息');
  if (result.remaining) parts.push('下次会继续检查剩余文件');
  state.textContent = parts.join('，') + '。';
}

async function runDownload(type, data) {
  sync.disabled = true;
  sample.disabled = true;
  state.textContent = '正在检查和保存课程文件…';
  try {
    const result = await send(type, data);
    if (result) showDownload(result);
    else state.textContent = '已保存，自动检查将按计划执行。';
  } catch (error) { showError(error); }
  finally { sync.disabled = false; sample.disabled = false; }
}

origin.value = (await send('current-origin').catch(() => null))?.origin ?? '';
origin.addEventListener('input', () => {
  form.hidden = true;
  account = undefined;
  state.textContent = '';
});
for (const field of [year, semester]) {
  field.addEventListener('input', () => { fixedTerm.checked = true; });
}

byId('connect').addEventListener('click', async () => {
  const button = byId('connect');
  button.disabled = true;
  form.hidden = true;
  account = undefined;
  try {
    const url = siteOrigin(origin.value);
    if (!(await chrome.permissions.request({origins: [url + '/*']}))) throw new SyncError('site_permission');
    state.textContent = '正在检查账号和本机助手…';
    const settings = await send('inspect', {origin: url});
    account = settings;
    root.value = settings.root;
    year.value = settings.term?.year ?? '';
    semester.value = String(settings.term?.semester ?? 1);
    fixedTerm.checked = settings.fixedTerm === true;
    automatic.checked = settings.automatic;
    autoIntervalMinutes.value = settings.autoIntervalMinutes;
    autoDailyLimit.value = settings.autoDailyLimit;
    sync.disabled = !settings.configured;
    sample.disabled = !settings.configured;
    byId('fileCount').textContent = '已找到 ' + settings.fileCount + ' 份可检查的课程附件。';
    form.hidden = false;
    if (settings.lastResult) showDownload(settings.lastResult);
    else state.textContent = '已连接。请选择课程文件夹。';
  } catch (error) { showError(error); }
  finally { button.disabled = false; }
});

byId('pick').addEventListener('click', async () => {
  try {
    const selected = await send('choose-folder', {current: root.value});
    if (selected.root) root.value = selected.root;
  } catch (error) { showError(error); }
});

form.addEventListener('submit', async event => {
  event.preventDefault();
  if (!account) return;
  const button = byId('save');
  button.disabled = true;
  try {
    const configured = await send('configure', {
      origin: account.origin, profileId: account.profileId, root: root.value,
      term: {year: Number(year.value), semester: Number(semester.value)}, fixedTerm: fixedTerm.checked,
      automatic: automatic.checked,
      autoIntervalMinutes: autoIntervalMinutes.valueAsNumber, autoDailyLimit: autoDailyLimit.valueAsNumber,
    });
    root.value = configured.root;
    year.value = configured.term.year;
    semester.value = String(configured.term.semester);
    fixedTerm.checked = configured.fixedTerm === true;
    state.textContent = '已保存课程目录。';
    sync.disabled = false;
    sample.disabled = false;
    if (automatic.checked) await runDownload('auto-check-now');
  } catch (error) { showError(error); }
  finally { button.disabled = false; }
});

sync.addEventListener('click', async () => {
  if (!account) return;
  await runDownload('sync', {profileId: account.profileId});
});

sample.addEventListener('click', async () => {
  if (!account) return;
  sync.disabled = true;
  sample.disabled = true;
  state.textContent = '正在查找并校验一份课件…';
  try {
    const result = await send('download-sample', {origin: account.origin, profileId: account.profileId});
    const outcome = result.saved ? '已保存并校验一份课件' : '相同文件已经保存并通过校验';
    state.textContent = outcome + '。' + result.courseCode + ' · ' + result.filename + '（' +
      result.bytes.toLocaleString('zh-CN') + ' 字节） SHA-256 ' + result.sha256;
  } catch (error) { showError(error); }
  finally { sync.disabled = false; sample.disabled = false; }
});

byId('skip').addEventListener('click', async () => {
  await send('skip').then(() => {
    automatic.checked = false;
    form.hidden = true;
    account = undefined;
    state.textContent = '已暂停本机自动下载。以后可以从扩展工具栏重新设置。';
  }, showError);
});
