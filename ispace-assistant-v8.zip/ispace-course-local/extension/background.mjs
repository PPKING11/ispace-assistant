import {automaticScheduleFrom, defaultAutomaticSchedule, downloadLectureSample, fetchManifest, nativeClient,
  refreshPairedManifest, reserveAutomaticCheck, reserveRefreshAttempt, siteOrigin, syncManifest, SyncError, termFrom} from './protocol.mjs';

const alarmName = 'ispace-course-sync';
const storage = chrome.storage.local;
let job;
let pauseJob = false;

async function ensureAlarm(lastCheckAt) {
  const {origin, autoProfile} = await storage.get(['origin', 'autoProfile']);
  if (!origin || autoProfile?.origin !== origin || !autoProfile.id) {
    await chrome.alarms.clear(alarmName);
    return;
  }
  const {autoIntervalMinutes} = await automaticSchedule(origin, autoProfile.id);
  const alarm = await chrome.alarms.get(alarmName);
  if (lastCheckAt === undefined && alarm?.periodInMinutes === autoIntervalMinutes) return;
  // Align the next alarm with the persisted interval check, including after startup.
  const when = lastCheckAt === undefined ? undefined : lastCheckAt + autoIntervalMinutes * 60_000;
  await chrome.alarms.create(alarmName, {periodInMinutes: autoIntervalMinutes, ...(when === undefined ? {} : {when})});
}

async function localOperation(callback) {
  const client = nativeClient();
  try { return await callback(client); } finally { client.close(); }
}

async function activeOrigin() {
  const state = await storage.get('origin');
  return state.origin ?? null;
}

async function hasSiteAccess(origin) {
  return await chrome.permissions.contains({origins: [origin + '/*']});
}

async function knownManifest(origin) {
  if (!(await hasSiteAccess(origin))) throw new SyncError('site_permission');
  return await fetchManifest(origin);
}

function termPreferenceKey(origin, profileId) {
  return `archive-term:${origin}:${profileId}`;
}

async function fixedArchiveTerm(origin, profileId) {
  const key = termPreferenceKey(origin, profileId);
  return termFrom((await storage.get(key))[key]);
}

function automaticScheduleKey(origin, profileId) {
  return `auto-schedule:${origin}:${profileId}`;
}

async function automaticSchedule(origin, profileId) {
  const key = automaticScheduleKey(origin, profileId);
  return automaticScheduleFrom((await storage.get(key))[key]) ?? defaultAutomaticSchedule;
}

async function check(origin) {
  const manifest = await knownManifest(origin);
  const termKey = termPreferenceKey(origin, manifest.profileId);
  const {autoProfile, lastResult, [termKey]: storedTerm} = await storage.get(['autoProfile', 'lastResult', termKey]);
  const fixedTerm = termFrom(storedTerm);
  const schedule = await automaticSchedule(origin, manifest.profileId);
  const {host, status} = await localOperation(async client => ({
    host: await client.send({op: 'hello'}),
    status: await client.send({op: 'status', profileId: manifest.profileId}),
  }));
  return {
    origin, profileId: manifest.profileId,
    term: fixedTerm ?? manifest.term ?? status.term,
    fixedTerm: Boolean(fixedTerm),
    root: status.root ?? host.defaultRoot,
    configured: status.configured,
    automatic: autoProfile?.id === manifest.profileId && autoProfile?.origin === origin,
    ...schedule,
    fileCount: manifest.files.length,
    lastResult: lastResult?.profileId === manifest.profileId ? lastResult : null,
  };
}

async function runSync(manualProfile) {
  const state = await storage.get(['origin', 'autoProfile', 'cursor', 'refreshAttempts']);
  const origin = state.origin;
  if (!origin) {
    if (manualProfile) throw new SyncError('setup_required');
    return null;
  }
  if (!manualProfile && (state.autoProfile?.origin !== origin || !state.autoProfile.id)) return null;
  const requestedProfile = manualProfile ?? state.autoProfile.id;
  if (!manualProfile) {
    const usageKey = `auto-usage:${origin}:${requestedProfile}`;
    const settings = await automaticSchedule(origin, requestedProfile);
    const usage = reserveAutomaticCheck((await storage.get(usageKey))[usageKey], settings);
    if (!usage || pauseJob) return null;
    await storage.set({[usageKey]: usage});
    await ensureAlarm(usage.at).catch(() => {});
  }
  let result;
  try {
    if (pauseJob) return null;
    const manifest = await knownManifest(origin);
    if (manifest.profileId !== requestedProfile) throw new SyncError('profile_changed');
    const fixedTerm = await fixedArchiveTerm(origin, requestedProfile);
    const startAt = state.cursor?.id === requestedProfile && state.cursor?.origin === origin ? state.cursor.offset : 0;
    result = await localOperation(async client => {
      let current = manifest;
      if (!pauseJob && manifest.shouldRefresh && state.autoProfile?.origin === origin && state.autoProfile.id === requestedProfile) {
        const attempts = reserveRefreshAttempt(state.refreshAttempts, origin, requestedProfile);
        if (attempts) {
          await client.send({op: 'hello'});
          if (!pauseJob) {
            await storage.set({refreshAttempts: attempts});
            if (!pauseJob) current = await refreshPairedManifest(origin, manifest);
          }
        }
      }
      return await syncManifest({...current, term: fixedTerm ?? current.term}, client,
        {startAt, shouldContinue: () => !pauseJob});
    });
    await storage.set({cursor: {id: requestedProfile, origin, offset: result.nextOffset}});
  } catch (error) {
    result = {error: error?.code ?? 'local_error'};
  }
  const lastResult = {...result, profileId: requestedProfile, time: new Date().toISOString()};
  await storage.set({lastResult});
  return lastResult;
}

function queueJob(run) {
  if (job) return Promise.reject(new SyncError('busy'));
  pauseJob = false;
  job = run().finally(() => { job = undefined; });
  return job;
}

function queueSync(manualProfile) {
  return queueJob(() => runSync(manualProfile));
}

async function runSample(message) {
  const origin = await activeOrigin();
  if (!origin) throw new SyncError('setup_required');
  if (siteOrigin(message.origin) !== origin) throw new SyncError('profile_changed');
  const manifest = await knownManifest(origin);
  if (manifest.profileId !== message.profileId) throw new SyncError('profile_changed');
  const fixedTerm = await fixedArchiveTerm(origin, manifest.profileId);
  return await localOperation(client => downloadLectureSample({...manifest, term: fixedTerm ?? manifest.term}, client,
    {shouldContinue: () => !pauseJob}));
}

async function configure(message) {
  const origin = siteOrigin(message.origin);
  const manifest = await knownManifest(origin);
  if (manifest.profileId !== message.profileId) throw new SyncError('profile_changed');
  const selectedTerm = termFrom(message.term);
  const fixedTerm = message.fixedTerm === true ? selectedTerm : message.fixedTerm === false ? null :
    await fixedArchiveTerm(origin, manifest.profileId);
  const term = fixedTerm ?? manifest.term ?? selectedTerm;
  if (!term || message.fixedTerm === true && !fixedTerm) throw new SyncError('invalid_term');
  const schedule = await automaticSchedule(origin, manifest.profileId);
  const selectedSchedule = automaticScheduleFrom({
    autoIntervalMinutes: Object.hasOwn(message, 'autoIntervalMinutes') ? message.autoIntervalMinutes : schedule.autoIntervalMinutes,
    autoDailyLimit: Object.hasOwn(message, 'autoDailyLimit') ? message.autoDailyLimit : schedule.autoDailyLimit,
  });
  if (!selectedSchedule) throw new SyncError('invalid_auto_schedule');
  const configured = await localOperation(client => client.send({
    op: 'configure', profileId: manifest.profileId, root: message.root,
    term,
  }));
  const oldOrigin = await activeOrigin();
  await storage.set({origin, autoProfile: !pauseJob && message.automatic === true ? {origin, id: manifest.profileId} : null,
    cursor: null, [termPreferenceKey(origin, manifest.profileId)]: fixedTerm,
    [automaticScheduleKey(origin, manifest.profileId)]: selectedSchedule});
  await ensureAlarm();
  if (oldOrigin && oldOrigin !== origin) await chrome.permissions.remove({origins: [oldOrigin + '/*']}).catch(() => {});
  return {...configured, fixedTerm: Boolean(fixedTerm), ...selectedSchedule};
}

async function extensionAction(message) {
  switch (message?.type) {
    case 'current-origin':
      return {origin: await activeOrigin()};
    case 'inspect':
      return await check(siteOrigin(message.origin));
    case 'choose-folder':
      return await localOperation(client => client.send({op: 'choose-folder', current: message.current}, 120000));
    case 'configure':
      return await queueJob(() => configure(message));
    case 'sync':
      if (typeof message.profileId !== 'string' || !message.profileId) throw new SyncError('invalid_request');
      return await queueSync(message.profileId);
    case 'auto-check-now':
      return await queueSync();
    case 'download-sample':
      return await queueJob(() => runSample(message));
    case 'skip':
      pauseJob = true;
      await storage.remove('autoProfile');
      await ensureAlarm();
      return null;
    default:
      throw new SyncError('invalid_request');
  }
}

function reply(promise, respond) {
  promise.then(result => respond({ok: true, result}), error => respond({ok: false, error: error?.code ?? 'local_error'}));
  return true;
}

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL('setup.html')) return false;
  return reply(extensionAction(message), respond);
});

async function externalAction(message, sender) {
  if (!sender?.url || !['probe', 'open-setup'].includes(message?.type)) return {installed: false};
  const source = new URL(sender.url);
  if (source.pathname !== '/setup') return {installed: false};
  const origin = siteOrigin(source.origin);
  if (origin !== await activeOrigin()) {
    return message.type === 'probe' ? {installed: true, localHost: false, protocol: 1, needsSiteSetup: true}
      : {opened: false};
  }
  if (message.type === 'open-setup') {
    await chrome.tabs.create({url: chrome.runtime.getURL('setup.html')});
    return {opened: true};
  }
  const localHost = await localOperation(client => client.send({op: 'hello'}, 2800)).then(
    host => host?.protocol === 1, () => false,
  );
  return {installed: true, localHost, protocol: 1};
}

chrome.runtime.onMessageExternal.addListener((message, sender, respond) => {
  externalAction(message, sender).then(respond, () => respond({installed: false}));
  return true;
});

chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({url: chrome.runtime.getURL('setup.html')}).catch(() => {});
});
chrome.runtime.onInstalled.addListener(() => { ensureAlarm().catch(() => {}); });
chrome.runtime.onStartup.addListener(() => {
  ensureAlarm().catch(() => {}).then(() => queueSync()).catch(() => {});
});
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === alarmName) queueSync().catch(() => {});
});
