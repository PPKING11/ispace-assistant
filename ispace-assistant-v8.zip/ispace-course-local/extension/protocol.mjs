export const hostName = 'com.ispace.course_sync';
export const protocolVersion = 1;
export const maxFileBytes = 96 * 1024 * 1024;
const maxTrialFileBytes = 5 * 1024 * 1024;
export const chunkBytes = 32 * 1024;
export const refreshRetryIntervalMs = 60 * 60 * 1000;
export const defaultAutomaticSchedule = Object.freeze({autoIntervalMinutes: 15, autoDailyLimit: 0});
const minuteMs = 60 * 1000;
const beijingOffsetMs = 8 * 60 * minuteMs;
const categories = new Set(['lectures', 'assignments', 'group-projects', 'labs', 'tutorials', 'exams', 'other']);
const boundedText = (value, length) => typeof value === 'string' && value.trim() === value && value.length > 0 && value.length <= length && !/[\p{Cc}\p{Cf}]/u.test(value);

export class SyncError extends Error {
  constructor(code) {
    super(code);
    this.code = code;
  }
}

export function siteOrigin(input) {
  if (typeof input !== 'string' || !input.trim()) throw new SyncError('invalid_origin');
  let origin;
  try { origin = new URL(input.trim()); } catch { throw new SyncError('invalid_origin'); }
  if (origin.protocol !== 'https:' || !/^[a-z0-9-]+\.[a-z0-9-]+\.chatgpt\.site$/i.test(origin.hostname) ||
      origin.port || origin.username || origin.password || origin.pathname !== '/' || origin.search || origin.hash) {
    throw new SyncError('invalid_origin');
  }
  return origin.origin;
}

export function termFrom(value) {
  return Number.isInteger(value?.year) && value.year >= 1 && value.year <= 12 &&
    [1, 2, 3].includes(value.semester) ? {year: value.year, semester: value.semester} : null;
}

export function automaticScheduleFrom(value) {
  const {autoIntervalMinutes, autoDailyLimit} = value ?? {};
  return Number.isInteger(autoIntervalMinutes) && autoIntervalMinutes >= 5 && autoIntervalMinutes <= 1440 &&
    Number.isInteger(autoDailyLimit) && autoDailyLimit >= 0 && autoDailyLimit <= 288
    ? {autoIntervalMinutes, autoDailyLimit} : null;
}

export function reserveAutomaticCheck(usage, {autoIntervalMinutes, autoDailyLimit}, now = Date.now()) {
  const day = new Date(now + beijingOffsetMs).toISOString().slice(0, 10);
  const count = usage?.day === day && Number.isSafeInteger(usage.count) && usage.count >= 0 ? usage.count : 0;
  if (autoDailyLimit && count >= autoDailyLimit) return null;
  if (Number.isSafeInteger(usage?.at) && now - usage.at < autoIntervalMinutes * minuteMs) return null;
  return {day, count: count + 1, at: now};
}

export function safeFileUrl(value, origin) {
  if (typeof value !== 'string' || !value.startsWith('/api/files?') || value.length > 1200) {
    throw new SyncError('invalid_manifest');
  }
  const url = new URL(value, origin);
  if (url.origin !== origin || url.pathname !== '/api/files' || url.hash || url.username || url.password) {
    throw new SyncError('invalid_manifest');
  }
  return url.href;
}

export function parseManifest(value, origin) {
  const uuid = value?.profileId;
  if (value?.schemaVersion !== protocolVersion || !boundedText(uuid, 128) ||
      !/^[a-zA-Z0-9_-]{8,128}$/.test(uuid) || !Array.isArray(value.files) || value.files.length > 15000) {
    throw new SyncError('invalid_manifest');
  }
  const files = [];
  const seen = new Set();
  let invalidFiles = 0;
  for (const file of value.files) {
    if (!file || !boundedText(String(file.courseId ?? ''), 100) ||
        !boundedText(file.courseCode, 50) || !boundedText(file.fileId, 220) ||
        !boundedText(file.revision, 256) || !boundedText(file.filename, 260) || !categories.has(file.category) ||
        file.bytes != null && (!Number.isSafeInteger(file.bytes) || file.bytes < 1) ||
        file.sha256 != null && (typeof file.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(file.sha256))) {
      invalidFiles++;
      continue;
    }
    let downloadUrl;
    try { downloadUrl = safeFileUrl(file.downloadUrl, origin); } catch { invalidFiles++; continue; }
    const key = JSON.stringify([String(file.courseId), file.fileId, file.revision]);
    if (seen.has(key)) continue;
    seen.add(key);
    files.push({
      courseId: String(file.courseId), courseCode: file.courseCode, category: file.category,
      fileId: file.fileId, revision: file.revision, filename: file.filename,
      downloadUrl, bytes: file.bytes ?? undefined, sha256: file.sha256 ?? undefined,
    });
  }
  const safeCount = number => Number.isInteger(number) && number >= 0 ? number : 0;
  const verifiedAt = typeof value.verifiedAt === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value.verifiedAt) &&
    Number.isFinite(Date.parse(value.verifiedAt)) ? value.verifiedAt : null;
  return {profileId: uuid, files, term: termFrom(value.term), invalidFiles, verifiedAt, shouldRefresh: value.shouldRefresh === true,
    skipped: {unsupported: safeCount(value.skipped?.unsupported), tooLarge: safeCount(value.skipped?.tooLarge)}};
}

export async function fetchManifest(origin, fetcher = fetch) {
  let response;
  try {
    response = await fetcher(new URL('/api/local-sync/manifest', origin), {
      credentials: 'include', cache: 'no-store', redirect: 'manual', signal: AbortSignal.timeout(20000),
    });
  } catch { throw new SyncError('offline'); }
  if ([401, 403].includes(response.status) || response.type === 'opaqueredirect') throw new SyncError('sign_in');
  if (response.status === 404) throw new SyncError('endpoint_unavailable');
  if (!response.ok) throw new SyncError('manifest_unavailable');
  if (!response.headers.get('content-type')?.toLowerCase().includes('application/json')) throw new SyncError('sign_in');
  let manifest;
  try { manifest = await response.json(); } catch { throw new SyncError('invalid_manifest'); }
  return parseManifest(manifest, origin);
}

export function reserveRefreshAttempt(attempts, origin, profileId, now = Date.now()) {
  const recent = Array.isArray(attempts) ? attempts.filter(attempt =>
    Number.isSafeInteger(attempt?.at) && attempt.at <= now && now - attempt.at < refreshRetryIntervalMs) : [];
  if (recent.length >= 64 || recent.some(attempt => attempt.origin === origin && attempt.profileId === profileId)) return null;
  return [...recent, {origin, profileId, at: now}];
}

export async function refreshPairedManifest(origin, manifest, fetcher = fetch) {
  try {
    await fetcher(new URL('/api/local-sync/refresh', origin), {
      method: 'POST', credentials: 'include', cache: 'no-store', redirect: 'manual',
      headers: {'X-ISpace-Sync-Profile': manifest.profileId}, signal: AbortSignal.timeout(90000),
    });
  } catch {
    // A timed-out request may have completed on the server.
  }
  let refreshed;
  try { refreshed = await fetchManifest(origin, fetcher); }
  catch { return manifest; }
  if (refreshed.profileId !== manifest.profileId) throw new SyncError('profile_changed');
  return refreshed;
}

export function nativeClient(chromeRuntime = chrome.runtime) {
  const port = chromeRuntime.connectNative(hostName);
  let pending;
  let closed = false;
  const finish = (callback, value) => {
    if (!pending) return;
    const {resolve, reject, timer} = pending;
    pending = undefined;
    clearTimeout(timer);
    (callback === 'resolve' ? resolve : reject)(value);
  };
  port.onMessage.addListener(response => {
    if (!pending) return;
    if (response?.ok === true) finish('resolve', response.result);
    else finish('reject', new SyncError(response?.error ?? 'local_error'));
  });
  port.onDisconnect.addListener(() => {
    // Read browser.lastError even when the port disconnected normally.
    const unavailable = Boolean(chromeRuntime.lastError);
    closed = true;
    finish('reject', new SyncError(unavailable ? 'host_missing' : 'local_error'));
  });
  return {
    send(message, timeout = 10000) {
      if (closed || pending) return Promise.reject(new SyncError('local_error'));
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          finish('reject', new SyncError('host_timeout'));
          closed = true;
          port.disconnect();
        }, timeout);
        pending = {resolve, reject, timer};
        try { port.postMessage(message); } catch {
          finish('reject', new SyncError('host_missing'));
        }
      });
    },
    close() {
      if (closed) return;
      closed = true;
      finish('reject', new SyncError('local_error'));
      port.disconnect();
    },
  };
}

async function requestAttachment(file, profileId, fetcher) {
  let response;
  try {
    response = await fetcher(file.downloadUrl, {
      credentials: 'include', cache: 'no-store', redirect: 'manual',
      headers: {'X-ISpace-Sync-Profile': profileId}, signal: AbortSignal.timeout(125000),
    });
  } catch { throw new SyncError('offline'); }
  if ([401, 403, 409].includes(response.status) || response.type === 'opaqueredirect') throw new SyncError('download_permission');
  if ([413].includes(response.status)) throw new SyncError('too_large');
  if (!response.ok || !response.body || !/^attachment(?:;|$)/i.test(response.headers.get('content-disposition') ?? '')) {
    await response.body?.cancel().catch(() => {});
    throw new SyncError('download_failed');
  }
  return response;
}

async function writeChunks(client, bytes, shouldContinue = () => true) {
  for (let offset = 0; offset < bytes.length; offset += chunkBytes) {
    if (!shouldContinue()) throw new SyncError('sample_paused');
    const chunk = bytes.subarray(offset, offset + chunkBytes);
    await client.send({op: 'chunk', data: btoa(String.fromCharCode(...chunk))});
  }
}

async function downloadAttachment(file, profileId, client, fetcher) {
  const response = await requestAttachment(file, profileId, fetcher);
  const sizeHeader = response.headers.get('content-length');
  if (sizeHeader && (!/^\d+$/.test(sizeHeader) || Number(sizeHeader) > maxFileBytes)) throw new SyncError('too_large');
  const reader = response.body.getReader();
  let bytes = 0;
  try {
    for (;;) {
      const part = await reader.read();
      if (part.done) break;
      bytes += part.value.length;
      if (bytes > maxFileBytes) throw new SyncError('too_large');
      await writeChunks(client, part.value);
    }
    if (sizeHeader && bytes !== Number(sizeHeader)) throw new SyncError('download_incomplete');
    return await client.send({op: 'commit', bytes}, 30000);
  } finally {
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}

export async function downloadLectureSample(manifest, client, {fetcher = fetch, shouldContinue = () => true} = {}) {
  const file = manifest.verifiedAt && manifest.files.find(candidate =>
    candidate.category === 'lectures' && /\.pdf$/i.test(candidate.filename) &&
    candidate.bytes >= 5 && candidate.bytes <= maxTrialFileBytes &&
    new URL(candidate.downloadUrl).searchParams.get('expectedVerifiedAt') === manifest.verifiedAt);
  if (!file) throw new SyncError('no_sample');

  const options = await client.send({op: 'status', profileId: manifest.profileId});
  if (!options.configured) throw new SyncError('setup_required');
  if (!shouldContinue()) throw new SyncError('sample_paused');

  const response = await requestAttachment(file, manifest.profileId, fetcher);
  const reader = response.body.getReader();
  const bytes = new Uint8Array(file.bytes);
  let received = 0;
  try {
    if (!/^application\/pdf(?:;|$)/i.test(response.headers.get('content-type') ?? '')) {
      throw new SyncError('sample_invalid_pdf');
    }
    const length = response.headers.get('content-length');
    if (length !== null && length !== String(file.bytes)) throw new SyncError('download_incomplete');
    for (;;) {
      if (!shouldContinue()) throw new SyncError('sample_paused');
      const part = await reader.read();
      if (part.done) break;
      if (received + part.value.length > bytes.length) throw new SyncError('download_incomplete');
      bytes.set(part.value, received);
      received += part.value.length;
    }
  } finally {
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
  if (received !== bytes.length) throw new SyncError('download_incomplete');
  if (new TextDecoder().decode(bytes.subarray(0, 5)) !== '%PDF-') throw new SyncError('sample_invalid_pdf');
  const hash = await crypto.subtle.digest('SHA-256', bytes);
  const sha256 = Array.from(new Uint8Array(hash), value => value.toString(16).padStart(2, '0')).join('');
  if (file.sha256 && file.sha256 !== sha256) throw new SyncError('download_integrity');
  if (!shouldContinue()) throw new SyncError('sample_paused');

  const {downloadUrl: _url, ...record} = file;
  const target = {courseCode: file.courseCode, filename: file.filename, bytes: received, sha256};
  try {
    const state = await client.send({
      op: 'begin', profileId: manifest.profileId, term: manifest.term ?? options.term, file: {...record, sha256},
    });
    if (state.unchanged) return {...target, saved: false};
    await writeChunks(client, bytes, shouldContinue);
    if (!shouldContinue()) throw new SyncError('sample_paused');
    const result = await client.send({op: 'commit', bytes: received}, 30000);
    return {...target, filename: result.filename, saved: true};
  } catch (error) {
    await client.send({op: 'abort'}).catch(() => {});
    throw error;
  }
}

export async function syncManifest(manifest, client, {maxDownloads = 8, fetcher = fetch, startAt = 0, shouldContinue = () => true} = {}) {
  const options = await client.send({op: 'status', profileId: manifest.profileId});
  if (!options.configured) throw new SyncError('setup_required');
  const result = {
    saved: 0, checked: 0, failed: 0, remaining: 0, nextOffset: 0,
    tooLarge: manifest.skipped?.tooLarge ?? 0,
    invalid: (manifest.invalidFiles ?? 0) + (manifest.skipped?.unsupported ?? 0),
  };
  const term = manifest.term ?? options.term;
  const records = manifest.files;
  if (!records.length) return result;
  startAt = Number.isSafeInteger(startAt) && startAt >= 0 && startAt < records.length ? startAt : 0;
  const limit = Math.min(records.length, 300);
  for (let checked = 0; checked < limit; checked++) {
    const index = (startAt + checked) % records.length;
    if (!shouldContinue()) {
      result.nextOffset = index;
      return result;
    }
    const file = records[index];
    if (file.bytes > maxFileBytes) {
      result.tooLarge++;
      continue;
    }
    if (result.saved + result.failed >= maxDownloads) {
      result.nextOffset = index;
      result.remaining = records.length - result.checked;
      return result;
    }
    const {downloadUrl: _url, ...record} = file;
    try {
      const state = await client.send({op: 'begin', profileId: manifest.profileId, term, file: record});
      if (state.unchanged) {
        result.checked++;
        continue;
      }
      await downloadAttachment(file, manifest.profileId, client, fetcher);
      result.saved++;
      result.checked++;
    } catch (error) {
      await client.send({op: 'abort'}).catch(() => {});
      if (['offline', 'sign_in', 'download_permission', 'host_missing', 'host_timeout', 'busy', 'local_error'].includes(error?.code)) throw error;
      if (result.failed === 0) result.firstError = error?.code ?? 'download_failed';
      result.failed++;
    }
  }
  if (limit < records.length) {
    result.remaining = records.length - result.checked;
    result.nextOffset = (startAt + limit) % records.length;
  }
  return result;
}
