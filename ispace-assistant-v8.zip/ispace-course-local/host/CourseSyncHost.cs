using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace ISpaceCourseSync
{
    internal sealed class SyncError : Exception
    {
        public SyncError(string code) : base(code) {}
    }

    internal sealed class Term
    {
        public int year { get; set; }
        public int semester { get; set; }
        public string FolderName
        {
            get { return string.Format(CultureInfo.InvariantCulture, "Year {0} Semester {1}", year, semester); }
        }
    }

    internal sealed class Settings
    {
        public string Root { get; set; }
        public Term Term { get; set; }
    }

    internal sealed class Receipt
    {
        public string Filename { get; set; }
        public long Bytes { get; set; }
        public string Sha256 { get; set; }
        public long LastWriteUtcTicks { get; set; }
    }

    internal sealed class Transfer : IDisposable
    {
        public string Root;
        public string Directory;
        public string Name;
        public string Identity;
        public string ReceiptPath;
        public string TemporaryPath;
        public long? ExpectedBytes;
        public string ExpectedSha;
        public FileStream Lock;
        public FileStream Stream;

        public void Dispose()
        {
            if (Stream != null) Stream.Dispose();
            if (TemporaryPath != null)
            {
                try { File.Delete(TemporaryPath); } catch (IOException) {} catch (UnauthorizedAccessException) {}
            }
            if (Lock != null) Lock.Dispose();
        }
    }

    internal static class Program
    {
        private const string Caller = "chrome-extension://fcgnjkllmgaomnachmiimchkdjgfenif/";
        private const long MaxFileBytes = 96L * 1024 * 1024;
        private const int MaxMessage = 262144;
        private const int MaxChunk = 32768;
        private const string Marker = ".ispace-course-owner";
        private const string PendingPrefix = ".ispace-course-";
        private static readonly JavaScriptSerializer Json = new JavaScriptSerializer {
            MaxJsonLength = MaxMessage, RecursionLimit = 16
        };
        private static readonly UTF8Encoding Utf8 = new UTF8Encoding(false, true);
        private static readonly Regex ProfileId = new Regex("^[a-zA-Z0-9_-]{8,128}$");
        private static readonly Regex Sha = new Regex("^[a-f0-9]{64}$");
        private static readonly Regex PartialName = new Regex(@"^\.ispace-course-[a-f0-9]{32}\.partial$");
        private static readonly Regex DeviceName = new Regex(
            @"^(CON|PRN|AUX|NUL|CONIN\$|CONOUT\$|COM[0-9¹²³]|LPT[0-9¹²³])(?:\.|$)", RegexOptions.IgnoreCase);
        private static readonly Dictionary<string, string> Categories = new Dictionary<string, string> {
            {"lectures", "Lectures"}, {"assignments", "Assignments"}, {"group-projects", "Group Projects"},
            {"labs", "Labs"}, {"tutorials", "Tutorials"}, {"exams", "Exams"}, {"other", "Other"}
        };
        private static Transfer transfer;
        private static string stateDirectory;

        [STAThread]
        public static int Main(string[] args)
        {
            if (args.Length < 1 || !String.Equals(args[0], Caller, StringComparison.Ordinal)) return 2;
            stateDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "iSpaceCourseSync");
#if ISPACE_TEST
            stateDirectory = Environment.GetEnvironmentVariable("ISPACE_TEST_STATE_DIRECTORY") ?? stateDirectory;
#endif
            try
            {
                using (Stream input = Console.OpenStandardInput())
                using (Stream output = Console.OpenStandardOutput())
                {
                    byte[] header = new byte[4];
                    while (ReadExactly(input, header))
                    {
                        uint length = BitConverter.ToUInt32(header, 0);
                        if (length == 0 || length > MaxMessage) return 3;
                        byte[] data = new byte[length];
                        if (!ReadExactly(input, data)) return 3;
                        object response;
                        try
                        {
                            var request = Json.Deserialize<Dictionary<string, object>>(Utf8.GetString(data));
                            response = new {ok = true, result = Handle(request)};
                        }
                        catch (SyncError error) { response = new {ok = false, error = error.Message}; }
                        catch (UnauthorizedAccessException) { response = new {ok = false, error = "folder_unavailable"}; }
                        catch (IOException) { response = new {ok = false, error = "folder_unavailable"}; }
                        catch (ArgumentException) { response = new {ok = false, error = "invalid_request"}; }
                        catch (FormatException) { response = new {ok = false, error = "invalid_request"}; }
                        catch (Exception) { response = new {ok = false, error = "local_error"}; }
                        byte[] reply = Utf8.GetBytes(Json.Serialize(response));
                        output.Write(BitConverter.GetBytes(reply.Length), 0, 4);
                        output.Write(reply, 0, reply.Length);
                        output.Flush();
                    }
                }
                return 0;
            }
            catch (IOException) { return 3; }
            finally { ClearTransfer(); }
        }

        private static bool ReadExactly(Stream stream, byte[] buffer)
        {
            int offset = 0;
            while (offset < buffer.Length)
            {
                int read = stream.Read(buffer, offset, buffer.Length - offset);
                if (read == 0) return false;
                offset += read;
            }
            return true;
        }

        private static object Handle(Dictionary<string, object> request)
        {
            switch (Text(request, "op", 32))
            {
                case "hello": return new {protocol = 1, defaultRoot = DefaultRoot()};
                case "status": return Status(GetSettings(Profile(request)));
                case "choose-folder": return ChooseFolder(request);
                case "configure": return Configure(request);
                case "begin": return Begin(request);
                case "chunk": return WriteChunk(request);
                case "commit": return Commit(request);
                case "abort": ClearTransfer(); return new {aborted = true};
                default: throw new SyncError("invalid_request");
            }
        }

        private static string DefaultRoot()
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            return String.IsNullOrEmpty(desktop) ? "" : Path.Combine(desktop, "Course");
        }

        private static object ChooseFolder(Dictionary<string, object> request)
        {
            if (transfer != null) throw new SyncError("busy");
            object value;
            string current = request.TryGetValue("current", out value) ? value as string : null;
            using (var picker = new FolderBrowserDialog())
            {
                picker.Description = "选择存放 iSpace 课程资料的本地文件夹";
                picker.ShowNewFolderButton = true;
                if (!String.IsNullOrEmpty(current) && Directory.Exists(current)) picker.SelectedPath = current;
                return new {root = picker.ShowDialog() == DialogResult.OK ? picker.SelectedPath : (string)null};
            }
        }

        private static string Text(Dictionary<string, object> value, string key, int maximum)
        {
            object field;
            string text = value != null && value.TryGetValue(key, out field) ? field as string : null;
            if (String.IsNullOrWhiteSpace(text) || text.Length > maximum || text.IndexOf('\0') >= 0)
                throw new SyncError("invalid_request");
            return text;
        }

        private static long Number(Dictionary<string, object> value, string key, long minimum, long maximum)
        {
            object field;
            if (value == null || !value.TryGetValue(key, out field) || !(field is int || field is long))
                throw new SyncError("invalid_request");
            long number = Convert.ToInt64(field, CultureInfo.InvariantCulture);
            if (number < minimum || number > maximum) throw new SyncError("invalid_request");
            return number;
        }

        private static Dictionary<string, object> ObjectField(Dictionary<string, object> value, string key)
        {
            object field;
            var result = value.TryGetValue(key, out field) ? field as Dictionary<string, object> : null;
            if (result == null) throw new SyncError("invalid_request");
            return result;
        }

        private static Term ReadTerm(Dictionary<string, object> request)
        {
            var data = ObjectField(request, "term");
            return new Term {year = (int)Number(data, "year", 1, 12), semester = (int)Number(data, "semester", 1, 3)};
        }

        private static string Profile(Dictionary<string, object> request)
        {
            string identifier = Text(request, "profileId", 128);
            if (!ProfileId.IsMatch(identifier)) throw new SyncError("invalid_request");
            return HashString(identifier);
        }

        private static string HashString(string value)
        {
            using (SHA256 sha = SHA256.Create()) return Hex(sha.ComputeHash(Utf8.GetBytes(value)));
        }

        private static string HashFile(string filename)
        {
            using (SHA256 sha = SHA256.Create())
            using (FileStream input = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read))
                return Hex(sha.ComputeHash(input));
        }

        private static string Hex(byte[] bytes)
        {
            return BitConverter.ToString(bytes).Replace("-", "").ToLowerInvariant();
        }

        private static string StatePath(string filename)
        {
            Directory.CreateDirectory(stateDirectory);
            return Path.Combine(stateDirectory, filename);
        }

        private static Settings GetSettings(string profile)
        {
            string filename = Path.Combine(stateDirectory, profile + ".json");
            return File.Exists(filename) ? Json.Deserialize<Settings>(File.ReadAllText(filename, Utf8)) : null;
        }

        private static object Status(Settings settings)
        {
            return new {configured = settings != null, root = settings == null ? null : settings.Root,
                term = settings == null ? null : settings.Term};
        }

        private static string NormalizeRoot(string input)
        {
            if (!Regex.IsMatch(input, @"^[A-Za-z]:[\\/]") || input.IndexOf(':', 2) >= 0)
                throw new SyncError("invalid_root");
            var full = Path.GetFullPath(input.Trim()).TrimEnd('\\', '/');
            if (full.Length < 4 || full.Length > 180) throw new SyncError("invalid_root");
            return full;
        }

        private static string InDirectory(string root, string filename)
        {
            string child = Path.GetFullPath(Path.Combine(root, filename));
            string parent = Path.GetDirectoryName(child);
            if (!String.Equals(parent, root, StringComparison.OrdinalIgnoreCase)) throw new SyncError("invalid_root");
            return child;
        }

        private static void CheckAttributes(string path)
        {
            try
            {
                if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
                    throw new SyncError("reparse_path");
            }
            catch (FileNotFoundException) {}
            catch (DirectoryNotFoundException) {}
        }

        private static void CheckPath(string folder)
        {
            for (DirectoryInfo directory = new DirectoryInfo(folder); directory != null; directory = directory.Parent)
                CheckAttributes(directory.FullName);
        }

        private static void EnsureRoot(string root)
        {
            CheckPath(root);
            if (!Directory.Exists(root)) throw new SyncError("folder_unavailable");
        }

        private static void CheckOwnership(string root, string profile, bool claim)
        {
            EnsureRoot(root);
            string marker = InDirectory(root, Marker);
            CheckAttributes(marker);
            if (!File.Exists(marker) && claim)
            {
                try
                {
                    using (var output = new FileStream(marker, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    {
                        byte[] owner = Utf8.GetBytes(profile);
                        output.Write(owner, 0, owner.Length);
                        output.Flush(true);
                    }
                }
                catch (IOException) { if (!File.Exists(marker)) throw; }
            }
            if (!File.Exists(marker)) throw new SyncError("folder_unavailable");
            if (!String.Equals(File.ReadAllText(marker, Utf8), profile, StringComparison.Ordinal))
                throw new SyncError("root_in_use");
        }

        private static FileStream LockProfile(string profile)
        {
            try { return new FileStream(StatePath(profile + ".lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None); }
            catch (IOException) { throw new SyncError("busy"); }
        }

        private static object Configure(Dictionary<string, object> request)
        {
            if (transfer != null) throw new SyncError("busy");
            string profile = Profile(request);
            var term = ReadTerm(request);
            var root = NormalizeRoot(Text(request, "root", 240).Trim());
            using (FileStream guard = LockProfile(profile))
            {
                CheckPath(root);
                Directory.CreateDirectory(root);
                CheckOwnership(root, profile, true);
                string schoolTerm = InDirectory(root, term.FolderName);
                CheckAttributes(schoolTerm);
                Directory.CreateDirectory(schoolTerm);
                CheckPath(schoolTerm);
                var settings = new Settings {Root = root, Term = term};
                SaveJson(StatePath(profile + ".json"), settings);
                return Status(settings);
            }
        }

        private static void SaveJson(string filename, object value)
        {
            string staging = InDirectory(Path.GetDirectoryName(filename), ".tmp-" + Guid.NewGuid().ToString("N").Substring(0, 12));
            try
            {
                using (var stream = new FileStream(staging, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    byte[] bytes = Utf8.GetBytes(Json.Serialize(value));
                    stream.Write(bytes, 0, bytes.Length);
                    stream.Flush(true);
                }
                if (File.Exists(filename)) File.Replace(staging, filename, null);
                else File.Move(staging, filename);
            }
            finally { if (File.Exists(staging)) File.Delete(staging); }
        }

        private static string FileComponent(string input, int length)
        {
            StringBuilder result = new StringBuilder();
            char[] invalid = Path.GetInvalidFileNameChars();
            foreach (char c in input.Normalize(NormalizationForm.FormC))
            {
                bool disallowed = Array.IndexOf(invalid, c) >= 0 || Char.IsControl(c) ||
                    CharUnicodeInfo.GetUnicodeCategory(c) == UnicodeCategory.Format;
                result.Append(disallowed ? '_' : c);
            }
            string name = result.ToString().Trim().TrimEnd('.');
            if (name.Length == 0 || DeviceName.IsMatch(name) || name.StartsWith(PendingPrefix, StringComparison.OrdinalIgnoreCase))
                name = "_" + name;
            if (name.Length > length)
            {
                string extension = Path.GetExtension(name);
                string suffix = "-" + HashString(name).Substring(0, 8);
                if (extension.Length > 15) extension = "";
                int prefixLength = length - extension.Length - suffix.Length;
                if (Char.IsHighSurrogate(name[prefixLength - 1])) prefixLength--;
                name = name.Substring(0, prefixLength).TrimEnd(' ', '.') + suffix + extension;
            }
            return name;
        }

        private static string ArchiveFolder(string root, Term term, string course, string category)
        {
            string destination = root;
            foreach (string component in new[] {term.FolderName, course, category})
            {
                destination = InDirectory(destination, component);
                CheckAttributes(destination);
                Directory.CreateDirectory(destination);
                CheckPath(destination);
            }
            return destination;
        }

        private static string CourseFolder(string termFolder, string courseId, string courseCode)
        {
            CheckAttributes(termFolder);
            string course = FileComponent(courseCode, 50);
            // Keep courses with identical short names separate in a shared term.
            string courseFolder = InDirectory(termFolder, course);
            CheckAttributes(courseFolder);
            string claimed = InDirectory(courseFolder, ".ispace-course-code");
            if (File.Exists(claimed))
            {
                CheckAttributes(claimed);
                if (!String.Equals(File.ReadAllText(claimed, Utf8), courseId, StringComparison.Ordinal))
                    course += "-" + HashString(courseId).Substring(0, 8);
            }
            return course;
        }

        private static void ClaimCourse(string courseFolder, string courseId)
        {
            string marker = InDirectory(courseFolder, ".ispace-course-code");
            CheckAttributes(marker);
            if (File.Exists(marker))
            {
                if (!String.Equals(File.ReadAllText(marker, Utf8), courseId, StringComparison.Ordinal))
                    throw new SyncError("invalid_root");
                return;
            }
            using (var writer = new StreamWriter(new FileStream(marker, FileMode.CreateNew, FileAccess.Write), Utf8))
                writer.Write(courseId);
        }

        private static string SnapshotIdentity(string courseId, string fileId, string revision)
        {
            return HashString(courseId + "\0" + fileId + "\0" + revision);
        }

        private static string GetReceiptPath(string profile, string root, Term term, string identity)
        {
            string directory = StatePath(profile + "-receipts");
            Directory.CreateDirectory(directory);
            return InDirectory(directory, HashString(root.ToUpperInvariant() + "\0" + term.FolderName + "\0" + identity) + ".json");
        }

        private static bool ReceiptExists(string receiptPath, string directory, string expectedSha)
        {
            if (!File.Exists(receiptPath)) return false;
            var receipt = Json.Deserialize<Receipt>(File.ReadAllText(receiptPath, Utf8));
            if (receipt == null || String.IsNullOrEmpty(receipt.Filename)) return false;
            string existing = InDirectory(directory, receipt.Filename);
            CheckAttributes(existing);
            if (!File.Exists(existing) || new FileInfo(existing).Length != receipt.Bytes ||
                expectedSha != null && !String.Equals(expectedSha, receipt.Sha256, StringComparison.Ordinal)) return false;
            return File.GetLastWriteTimeUtc(existing).Ticks == receipt.LastWriteUtcTicks ||
                String.Equals(receipt.Sha256, HashFile(existing), StringComparison.Ordinal);
        }

        private static void RecoverInterruptedDownloads(string directory)
        {
            foreach (string existing in Directory.EnumerateFiles(directory, PendingPrefix + "*.partial"))
            {
                if (!PartialName.IsMatch(Path.GetFileName(existing))) continue;
                FileAttributes attributes = File.GetAttributes(existing);
                if ((attributes & FileAttributes.ReparsePoint) == 0) File.Delete(existing);
            }
        }

        private static object Begin(Dictionary<string, object> request)
        {
            if (transfer != null) throw new SyncError("busy");
            string profile = Profile(request);
            var term = ReadTerm(request);
            var file = ObjectField(request, "file");
            string rawFilename = Text(file, "filename", 260);
            string rawCode = Text(file, "courseCode", 50);
            object courseField;
            file.TryGetValue("courseId", out courseField);
            string courseId = courseField is int || courseField is long
                ? Convert.ToString(courseField, CultureInfo.InvariantCulture) : Text(file, "courseId", 100);
            string identity = SnapshotIdentity(courseId, Text(file, "fileId", 220), Text(file, "revision", 256));
            string category;
            if (!Categories.TryGetValue(Text(file, "category", 20), out category)) throw new SyncError("invalid_request");
            object bytesField;
            object hashField;
            long? expectedBytes = file.TryGetValue("bytes", out bytesField) && bytesField != null
                ? (long?)Number(file, "bytes", 1, MaxFileBytes) : null;
            string expectedSha = file.TryGetValue("sha256", out hashField) && hashField != null
                ? Text(file, "sha256", 64) : null;
            if (expectedSha != null && !Sha.IsMatch(expectedSha)) throw new SyncError("invalid_request");

            var pending = new Transfer {Lock = LockProfile(profile), Identity = identity,
                ExpectedBytes = expectedBytes, ExpectedSha = expectedSha};
            try
            {
                var settings = GetSettings(profile);
                if (settings == null) throw new SyncError("setup_required");
                CheckOwnership(settings.Root, profile, false);
                pending.Root = settings.Root;
                string termFolder = InDirectory(settings.Root, term.FolderName);
                string course = CourseFolder(termFolder, courseId, rawCode);
                pending.Directory = ArchiveFolder(settings.Root, term, course, category);
                ClaimCourse(Path.GetDirectoryName(pending.Directory), courseId);
                // Fit standard Windows path limits, including the suffix kept for an updated file.
                int maxName = Math.Min(130, 240 - pending.Directory.Length - 25);
                if (maxName < 20) throw new SyncError("invalid_root");
                pending.Name = FileComponent(rawFilename, maxName);
                pending.ReceiptPath = GetReceiptPath(profile, settings.Root, term, identity);
                if (ReceiptExists(pending.ReceiptPath, pending.Directory, pending.ExpectedSha))
                {
                    pending.Dispose();
                    return new {unchanged = true};
                }

                pending.TemporaryPath = InDirectory(pending.Directory, PendingPrefix + Guid.NewGuid().ToString("N") + ".partial");
                CheckPath(pending.Directory);
                RecoverInterruptedDownloads(pending.Directory);
                pending.Stream = new FileStream(pending.TemporaryPath, FileMode.CreateNew, FileAccess.Write, FileShare.None);
                transfer = pending;
                return new {unchanged = false};
            }
            catch { pending.Dispose(); throw; }
        }

        private static object WriteChunk(Dictionary<string, object> request)
        {
            if (transfer == null) throw new SyncError("invalid_request");
            byte[] data = Convert.FromBase64String(Text(request, "data", 45500));
            if (data.Length == 0 || data.Length > MaxChunk || transfer.Stream.Length + data.Length > MaxFileBytes ||
                transfer.ExpectedBytes.HasValue && transfer.Stream.Length + data.Length > transfer.ExpectedBytes.Value)
                throw new SyncError("too_large");
            transfer.Stream.Write(data, 0, data.Length);
            return new {bytes = transfer.Stream.Length};
        }

        private static object Commit(Dictionary<string, object> request)
        {
            if (transfer == null) throw new SyncError("invalid_request");
            var pending = transfer;
            try
            {
                long size = pending.Stream.Length;
                if (Number(request, "bytes", 1, MaxFileBytes) != size ||
                    pending.ExpectedBytes.HasValue && pending.ExpectedBytes.Value != size)
                    throw new SyncError("download_incomplete");
                pending.Stream.Flush(true);
                pending.Stream.Dispose();
                pending.Stream = null;
                CheckPath(pending.Directory);
                CheckAttributes(pending.TemporaryPath);
                string hash = HashFile(pending.TemporaryPath);
                if (pending.ExpectedSha != null && !String.Equals(pending.ExpectedSha, hash, StringComparison.Ordinal))
                    throw new SyncError("download_integrity");

                string filename = DestinationFile(pending, size, hash);
                SaveJson(pending.ReceiptPath, new Receipt {
                    Filename = Path.GetFileName(filename), Bytes = size, Sha256 = hash,
                    LastWriteUtcTicks = File.GetLastWriteTimeUtc(filename).Ticks
                });
                return new {filename = Path.GetFileName(filename)};
            }
            finally { ClearTransfer(); }
        }

        private static string DestinationFile(Transfer pending, long size, string hash)
        {
            for (int attempt = 0; attempt < 100; attempt++)
            {
                string name = pending.Name;
                if (attempt > 0)
                {
                    string suffix = " (" + pending.Identity.Substring(0, 8) +
                        (attempt > 1 ? "-" + attempt.ToString(CultureInfo.InvariantCulture) : "") + ")";
                    name = Path.GetFileNameWithoutExtension(pending.Name) + suffix + Path.GetExtension(pending.Name);
                }
                string candidate = InDirectory(pending.Directory, name);
                CheckAttributes(candidate);
                if (File.Exists(candidate))
                {
                    if (new FileInfo(candidate).Length == size && String.Equals(hash, HashFile(candidate), StringComparison.Ordinal))
                        return candidate;
                    continue;
                }
                if (Directory.Exists(candidate)) continue;
                try { File.Move(pending.TemporaryPath, candidate); pending.TemporaryPath = null; return candidate; }
                catch (IOException) { if (!File.Exists(candidate)) throw; }
            }
            throw new SyncError("folder_unavailable");
        }

        private static void ClearTransfer()
        {
            if (transfer == null) return;
            transfer.Dispose();
            transfer = null;
        }
    }
}
