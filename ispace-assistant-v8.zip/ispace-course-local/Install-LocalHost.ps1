[CmdletBinding(DefaultParameterSetName = 'Install')]
param(
    [Parameter(ParameterSetName = 'Check')]
    [switch] $Check,
    [Parameter(ParameterSetName = 'Unregister')]
    [switch] $Unregister
)

$ErrorActionPreference = 'Stop'
$extensionId = 'fcgnjkllmgaomnachmiimchkdjgfenif'
$hostName = 'com.ispace.course_sync'
$chromeRegistry = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$hostName"
$destination = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'iSpaceCourseSync\host'
$executable = Join-Path $destination 'iSpaceCourseSyncHost.exe'
$manifest = Join-Path $destination "$hostName.json"
$allowedOrigin = "chrome-extension://$extensionId/"

if ($Check) {
    $status = 'not_registered'
    try {
        if (Test-Path -LiteralPath $chromeRegistry) {
            $status = 'needs_repair'
            $registered = (Get-Item -LiteralPath $chromeRegistry).GetValue('')
            if ($registered -eq $manifest -and (Test-Path -LiteralPath $manifest -PathType Leaf) -and
                (Test-Path -LiteralPath $executable -PathType Leaf)) {
                $info = Get-Content -LiteralPath $manifest -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction SilentlyContinue
                if ($info.name -ceq $hostName -and $info.type -ceq 'stdio' -and $info.path -eq $executable -and
                    @($info.allowed_origins).Count -eq 1 -and $info.allowed_origins[0] -ceq $allowedOrigin) {
                    $status = 'registered'
                }
            }
        }
    } catch {
        $status = 'unavailable'
    }
    [pscustomobject]@{status = $status} | ConvertTo-Json -Compress
    return
}

if ($Unregister) {
    if (Test-Path -LiteralPath $chromeRegistry) {
        Remove-Item -LiteralPath $chromeRegistry
    }
    Write-Output 'Chrome 本机助手已取消注册。'
    exit
}

$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (!(Test-Path -LiteralPath $compiler)) {
    $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
}
if (!(Test-Path -LiteralPath $compiler)) {
    throw '找不到 Windows .NET Framework C# 编译器。'
}

$source = Join-Path $PSScriptRoot 'host\CourseSyncHost.cs'
New-Item -ItemType Directory -Path $destination -Force | Out-Null
$staging = Join-Path $destination 'iSpaceCourseSyncHost.new.exe'
$outputArgument = '/out:' + $staging
& $compiler /nologo /target:exe /optimize+ /codepage:65001 /reference:System.Web.Extensions.dll /reference:System.Windows.Forms.dll $outputArgument $source
if ($LASTEXITCODE -ne 0) {
    throw '编译本机助手失败。'
}
Move-Item -LiteralPath $staging -Destination $executable -Force

$configuration = @{
    name = $hostName
    description = 'iSpace 课程文件同步助手'
    path = $executable
    type = 'stdio'
    allowed_origins = @($allowedOrigin)
}
$json = $configuration | ConvertTo-Json -Compress
[IO.File]::WriteAllText($manifest, $json, [Text.UTF8Encoding]::new($false))
New-Item -Path $chromeRegistry -Force | Out-Null
Set-Item -LiteralPath $chromeRegistry -Value $manifest
Write-Output '本机助手已注册。请通过 Chrome 加载同一安装包中的 extension 文件夹。'
