[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('ready', 'missing', 'unknown')][string]$ChromeExtension,

    [Parameter(Mandatory = $true)]
    [ValidateSet('ready', 'missing', 'unknown')][string]$WindowsHelper,

    [string]$DestinationDirectory,

    [ValidateSet('ready', 'missing', 'unknown')][string]$AttendanceExtension
)

$ErrorActionPreference = 'Stop'
$includeAttendance = $PSBoundParameters.ContainsKey('AttendanceExtension')
$courseNeeded = $ChromeExtension -eq 'missing' -or $WindowsHelper -eq 'missing' -or
    ($includeAttendance -and ($ChromeExtension -ne 'ready' -or $WindowsHelper -ne 'ready'))
$attendanceNeeded = $includeAttendance -and $AttendanceExtension -ne 'ready'
$result = [ordered]@{ status = 'not_needed' }
if ($includeAttendance) { $result.attendance = @{ status = 'ready' } }
if (!$courseNeeded -and !$attendanceNeeded) {
    $result | ConvertTo-Json -Compress
    return
}

if (!$DestinationDirectory) {
    $knownFolders = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders'
    $downloadsId = '{374DE290-123F-4565-9164-39C4925E467B}'
    $downloads = Get-ItemPropertyValue -LiteralPath $knownFolders -Name $downloadsId -ErrorAction SilentlyContinue
    $DestinationDirectory = if ($downloads) { [Environment]::ExpandEnvironmentVariables($downloads) } else {
        Join-Path ([Environment]::GetFolderPath('UserProfile')) 'Downloads'
    }
}

$folder = Get-Item -LiteralPath $DestinationDirectory
if (!$folder.PSIsContainer) { throw 'The download destination is not a directory.' }
Add-Type -AssemblyName System.IO.Compression.FileSystem

function Test-CurrentPackage([string]$Path, [array]$Sources) {
    try {
        $zip = [IO.Compression.ZipFile]::OpenRead($Path)
        try {
            if ($zip.Entries.Count -ne $Sources.Count) { return $false }
            foreach ($source in $Sources) {
                $entry = $zip.GetEntry($source.Name)
                if (!$entry) { return $false }
                $stream = $entry.Open()
                try {
                    if ((Get-FileHash -InputStream $stream).Hash -cne $source.Hash) { return $false }
                } finally { $stream.Dispose() }
            }
            return $true
        } finally { $zip.Dispose() }
    } catch {
        return $false
    }
}

function New-VerifiedSetupPackage([string]$SourceRoot, [string[]]$SourceNames, [string]$BaseName, [string]$OutputDirectory) {
    $files = foreach ($name in $SourceNames) {
        $path = Join-Path $SourceRoot $name
        $file = Get-Item -LiteralPath $path
        if ($file.PSIsContainer -or $file.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint)) {
            throw "Invalid iSpace component file: $name"
        }
        [pscustomobject]@{ Name = $name; Path = $file.FullName; Hash = (Get-FileHash -LiteralPath $path).Hash }
    }
    $hasher = [Security.Cryptography.SHA256]::Create()
    try {
        $digest = $hasher.ComputeHash([Text.Encoding]::UTF8.GetBytes(($files.Hash -join '')))
    } finally { $hasher.Dispose() }
    $fingerprint = [BitConverter]::ToString($digest).Replace('-', '').Substring(0, 12).ToLowerInvariant()
    $stem = "$BaseName-$fingerprint"
    $target = Join-Path $OutputDirectory "$stem.zip"
    if (Test-Path -LiteralPath $target) {
        if (Test-CurrentPackage $target $files) {
            return [ordered]@{ status = 'already_downloaded'; path = $target }
        }
        $target = Join-Path $OutputDirectory ($stem + '-' + [guid]::NewGuid().ToString('N') + '.zip')
    }

    $staged = Join-Path $OutputDirectory ('.ispace-components-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        $zip = [IO.Compression.ZipFile]::Open($staged, [IO.Compression.ZipArchiveMode]::Create)
        try {
            foreach ($source in $files) {
                [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $source.Path, $source.Name)
            }
        } finally { $zip.Dispose() }
        if (!(Test-CurrentPackage $staged $files)) { throw "Failed to verify the iSpace package: $BaseName" }
        try {
            [IO.File]::Move($staged, $target)
            $status = 'downloaded'
        } catch [IO.IOException] {
            if (!(Test-CurrentPackage $target $files)) { throw }
            $status = 'already_downloaded'
        }
        return [ordered]@{ status = $status; path = $target }
    } finally {
        [IO.File]::Delete($staged)
    }
}

if ($courseNeeded) {
    $courseFiles = @(
        'extension/background.mjs', 'extension/manifest.json', 'extension/protocol.mjs',
        'extension/icons/icon-16.png', 'extension/icons/icon-32.png',
        'extension/icons/icon-48.png', 'extension/icons/icon-128.png',
        'extension/setup.css', 'extension/setup.html', 'extension/setup.mjs',
        'host/CourseSyncHost.cs', 'Install-LocalHost.ps1', 'README.md'
    )
    $course = New-VerifiedSetupPackage $PSScriptRoot $courseFiles 'iSpace-course-components' $folder.FullName
    $result.status = $course.status
    $result.path = $course.path
}
if ($attendanceNeeded) {
    $attendanceRoot = Join-Path (Split-Path -Parent $PSScriptRoot) 'ispace-attendance-local'
    $attendanceFiles = @(
        'extension/attendance-content.js', 'extension/background.mjs', 'extension/icon.png',
        'extension/manifest.json', 'extension/plan.mjs', 'extension/popup.css',
        'extension/popup.html', 'extension/popup.mjs', 'README.md'
    )
    $result.attendance = New-VerifiedSetupPackage $attendanceRoot $attendanceFiles 'iSpace-attendance-extension' $folder.FullName
}
$result | ConvertTo-Json -Depth 3 -Compress
