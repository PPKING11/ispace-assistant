import { currentCandidate, isForm, overviewId } from './plan.mjs';

const { runtime, tabs } = chrome;
const { session, local } = chrome.storage;
const commands = new Set(['getState', 'checkNow', 'confirmPresent']);
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
let busy = false;

async function readPage(tabId, request) {
  try { return await tabs.sendMessage(tabId, request); }
  catch { return { state: 'unavailable' }; }
}

async function waitForReceipt(tabId, candidate) {
  for (let attempt = 0; attempt < 16; attempt++) {
    await pause(250);
    const tab = await tabs.get(tabId).catch(() => null);
    if (!tab) break;
    if (tab.status !== 'complete') continue;
    const reply = await readPage(tabId, { type: 'inspectAttendanceReceipt', candidate });
    if (['recorded', 'receipt_seen', 'already_recorded', 'verification_required'].includes(reply?.state)) return reply;
    if (isForm(tab.url, candidate.sessionId) && reply?.state !== 'unavailable') return reply;
  }
  return { state: 'unconfirmed' };
}

async function check(tabId, activityId) {
  const result = await readPage(tabId, { type: 'inspectAttendance' });
  if (result?.state === 'open' && !currentCandidate(result.candidate, activityId, Date.now())) {
    return { state: 'changed' };
  }
  return result ?? { state: 'unavailable' };
}

async function confirm(tabId, activityId, expected, message) {
  if (!currentCandidate(expected, activityId, Date.now()) || message.sessionId !== expected.sessionId ||
      message.rowKey !== expected.rowKey) return { state: 'changed' };
  const freshlyChecked = await check(tabId, activityId);
  if (freshlyChecked.state !== 'open') return freshlyChecked;
  const candidate = freshlyChecked.candidate;
  if (['courseId', 'activityId', 'sessionId', 'rowKey', 'href', 'startsAt', 'endsAt']
    .some(field => candidate[field] !== expected[field])) return { state: 'changed' };

  const attemptKey = activityId + ':' + candidate.sessionId;
  const { attempted = [] } = await local.get('attempted');
  if (attempted.includes(attemptKey)) return { state: 'unconfirmed' };
  // Opening the school form can save a mark. Record the one-time authorization first.
  await local.set({ attempted: [...attempted.slice(-99), attemptKey] });
  const opened = await readPage(tabId, { type: 'openAttendance', candidate });
  if (opened?.state !== 'opening' && opened?.state !== 'unavailable') return opened;
  const observed = await waitForReceipt(tabId, candidate);
  if (observed.state !== 'unconfirmed') return observed;
  const current = await tabs.get(tabId).catch(() => null);
  if (!isForm(current?.url, candidate.sessionId) || !currentCandidate(candidate, activityId, Date.now())) return observed;
  const submitted = await readPage(tabId, { type: 'submitAttendance', candidate });
  if (submitted?.state !== 'submitted' && submitted?.state !== 'unavailable') return submitted;
  return await waitForReceipt(tabId, candidate);
}

async function handle(message) {
  const [tab] = await tabs.query({ active: true, currentWindow: true });
  const activityId = overviewId(tab?.url);
  if (!Number.isInteger(tab?.id)) return { state: 'wrong_page', canCheck: false };
  const storageKey = 'inspection:' + tab.id;
  const previous = (await session.get(storageKey))[storageKey];
  if (message.type === 'getState') {
    if (activityId && previous?.activityId !== activityId) return { state: 'ready', canCheck: true };
    return { ...(previous?.result ?? { state: activityId ? 'ready' : 'wrong_page' }), canCheck: Boolean(activityId) };
  }
  if (!activityId) return { state: 'wrong_page', canCheck: false };
  if (busy) return { state: 'busy', canCheck: true };
  busy = true;
  try {
    const result = message.type === 'checkNow' ? await check(tab.id, activityId)
      : await confirm(tab.id, activityId, previous?.result?.candidate, message);
    await session.set({ [storageKey]: { activityId, result } });
    return { ...result, canCheck: true };
  } finally { busy = false; }
}

tabs.onRemoved.addListener(tabId => { void session.remove('inspection:' + tabId); });
runtime.onMessage.addListener((message, sender, reply) => {
  if (sender.id !== runtime.id || sender.url !== runtime.getURL('popup.html') || !commands.has(message?.type)) return false;
  void handle(message).then(reply, () => reply({ state: 'unavailable', canCheck: false }));
  return true;
});
