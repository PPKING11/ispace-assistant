(() => {
  'use strict';

  const SCHOOL = 'https://ispace.bnbu.edu.cn';
  const OVERVIEW_PATH = '/mod/attendance/view.php';
  const FORM_PATH = '/mod/attendance/attendance.php';
  const validId = value => typeof value === 'string' && /^[1-9]\d{0,12}$/.test(value);
  const BEIJING_OFFSET = 8 * 60 * 60 * 1000;
  const RECEIPT = 'Your attendance in this session has been recorded.';
  const MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
  const DATE_PREFIX = /^(?:([a-z]{3,9}),?\s+)?(\d{1,2})\s+([a-z]{3,9})\s+(\d{4})\s+(.+)$/i;
  const WEEKDAYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  const CHALLENGES = 'input[type="password"], input[name*="pass" i], input[name*="captcha" i], [name="g-recaptcha-response"], [name="h-captcha-response"], iframe[src*="captcha" i], #qrcode, [data-qrcode]';
  const CHALLENGE_NOTICE = /\b(?:qr code|captcha|passcode|password|location verification)\b|验证码|二维码|口令/i;
  const NOTICES = '.alert, [role="alert"], .notifyproblem, .notifysuccess';

  const text = node => String(node?.innerText ?? node?.textContent ?? '').replace(/\s+/g, ' ').trim();
  const all = (node, selector) => Array.from(node?.querySelectorAll(selector) ?? []);
  const visible = node => Boolean(node?.isConnected && node.getClientRects().length &&
    !node.closest('[hidden], [aria-hidden="true"], [inert]') && getComputedStyle(node).visibility === 'visible');
  const state = value => ({ state: value });
  let opened = false;
  let submitted = false;

  function schoolUrl(value) {
    if (typeof value !== 'string' || !value || value.length > 2048) return null;
    try {
      const url = new URL(value, location.href);
      return url.origin === SCHOOL && !url.username && !url.password && !url.hash ? url : null;
    } catch {
      return null;
    }
  }

  function exactId(url, path, id) {
    return url?.pathname === path && url.searchParams.get('id') === id && [...url.searchParams.keys()].length === 1;
  }

  function formSession(url) {
    if (url?.pathname !== FORM_PATH) return null;
    const keys = [...url.searchParams.keys()];
    if (!keys.includes('sessid') || new Set(keys).size !== keys.length ||
        keys.some(key => key !== 'sessid' && key !== 'sesskey')) return null;
    const sessionId = url.searchParams.get('sessid');
    return /^[1-9]\d{0,12}$/.test(sessionId) ? sessionId : null;
  }

  function loginPage() {
    return location.origin === SCHOOL && /^\/(?:login|auth)(?:\/|$)/.test(location.pathname);
  }

  function breadcrumbCourseId() {
    const breadcrumb = all(document, '#page-navbar a[href], .breadcrumb a[href]').filter(visible);
    const ids = new Set(breadcrumb.map(link => {
      const url = schoolUrl(link.getAttribute('href'));
      const id = url?.searchParams.get('id');
      return validId(id) && exactId(url, '/course/view.php', id) ? id : null;
    }).filter(Boolean));
    return ids.size === 1 ? [...ids][0] : null;
  }

  function courseContext(course) {
    return breadcrumbCourseId() === course.courseId;
  }

  function timeMinutes(value) {
    const match = /^(\d{1,2})(?::(\d{2}))?\s*([ap]\.?m\.?)?$/i.exec(value.trim());
    if (!match) return null;
    let hour = Number(match[1]);
    const minute = Number(match[2] ?? 0);
    if (minute > 59) return null;
    if (match[3]) {
      if (hour < 1 || hour > 12) return null;
      hour = (hour % 12) + (match[3].toLowerCase().startsWith('p') ? 12 : 0);
    } else if (hour > 23 || match[2] === undefined) {
      return null;
    }
    return hour * 60 + minute;
  }

  function sessionTimes(label, range) {
    const match = DATE_PREFIX.exec(label);
    if (!match) return null;
    const [, weekday, dayText, monthText, yearText, clock] = match;
    const day = Number(dayText);
    const month = MONTHS.findIndex(value => value === monthText.toLowerCase() || value.slice(0, 3) === monthText.toLowerCase());
    const year = Number(yearText);
    if (month < 0 || year < 2000 || year > 2100) return null;
    const localDate = new Date(Date.UTC(year, month, day));
    if (localDate.getUTCDate() !== day ||
        (weekday && WEEKDAYS[localDate.getUTCDay()] !== weekday.slice(0, 3).toLowerCase())) return null;
    const times = range ? clock.split(/\s*[-–—]\s*/) : [clock];
    if (times.length !== (range ? 2 : 1)) return null;
    const start = timeMinutes(times[0]);
    const end = range ? timeMinutes(times[1]) : null;
    if (start === null || (range && (end === null || end <= start))) return null;
    const midnight = localDate.getTime() - BEIJING_OFFSET;
    return { startsAt: midnight + start * 60_000, endsAt: end === null ? null : midnight + end * 60_000 };
  }

  function recordsTable() {
    const tables = [];
    for (const table of all(document, 'table')) {
      if (!visible(table) || table.tHead?.rows.length !== 1) continue;
      const headers = Array.from(table.tHead.rows[0].cells).map(cell => text(cell).toLowerCase());
      const required = ['date', 'description', 'status', 'points', 'remarks'];
      if (headers[0] !== 'date' || headers[1] !== 'description' ||
          required.some(name => headers.indexOf(name) < 0 || headers.indexOf(name) !== headers.lastIndexOf(name)) ||
          headers.slice(-3).join('|') !== 'status|points|remarks') continue;
      tables.push({ table, statusIndex: headers.indexOf('status') });
    }
    return tables;
  }

  function schoolRecord(row, statusIndex) {
    const cells = row.cells;
    const dateLabel = text(cells[0]);
    const description = text(cells[1]);
    const times = sessionTimes(dateLabel, true);
    // Keep only the time and the short identifying description. Never copy links or form fields into results.
    const details = times && description.length <= 120 && !/https?:\/\/|[?&](?:sesskey|token|qrpass)=/i.test(description)
      ? { ...times, label: description ? dateLabel + ' · ' + description : dateLabel,
          rowKey: JSON.stringify([times.startsAt, times.endsAt, description]) }
      : null;
    const statusCell = cells[statusIndex];
    const statusText = text(statusCell);
    const remarks = text(cells[statusIndex + 2]);
    const recorded = /^(Present|Late|Excused|Absent)(?:\s+Update attendance)?$/i.test(statusText) ||
      remarks === 'Self-recorded';
    const links = all(statusCell, 'a[href]').filter(link => visible(link) && text(link) === 'Submit attendance');
    return { details, statusText, remarks, recorded, links, challenge: all(statusCell, CHALLENGES).some(visible) };
  }

  function overviewRows(expectedCourse) {
    if (loginPage()) return { result: state('login_required') };
    const url = schoolUrl(location.href);
    const activityId = url?.searchParams.get('id');
    const courseId = breadcrumbCourseId();
    const course = { courseId, activityId };
    if (!courseId || !validId(activityId) || !exactId(url, OVERVIEW_PATH, activityId) ||
        (expectedCourse && (courseId !== expectedCourse.courseId || activityId !== expectedCourse.activityId))) {
      return { result: state('wrong_page') };
    }
    const tables = recordsTable();
    if (tables.length !== 1) return { result: state(tables.length ? 'ambiguous' : 'unsupported') };
    const [{ table, statusIndex }] = tables;
    const rows = Array.from(table.tBodies).flatMap(body => Array.from(body.rows))
      .filter(visible).map(row => schoolRecord(row, statusIndex));
    return { rows, course };
  }

  function inspectOverview(now, expectedCourse) {
    const { result, rows, course } = overviewRows(expectedCourse);
    if (result) return { result };
    if (rows.some(row => !row.details && (row.links.length || row.challenge))) return { result: state('unsupported') };
    const current = rows.filter(row => row.details && row.details.startsAt <= now && now < row.details.endsAt);
    if (current.length > 1 || current.some(row => row.links.length > 1)) return { result: state('ambiguous') };
    const [row] = current;
    if (!row) return { result: state('closed') };
    if (row.recorded) return { result: state('already_recorded') };
    if (row.challenge) return { result: state('verification_required') };
    const [link] = row.links;
    if (!link) return { result: state('closed') };
    const url = schoolUrl(link.getAttribute('href'));
    if (url?.searchParams.has('qrpass')) return { result: state('verification_required') };
    const sessionId = formSession(url);
    if (!sessionId || (link.target && link.target !== '_self') || link.hasAttribute('download')) {
      return { result: state('unsupported') };
    }
    const candidate = { ...row.details, courseId: course.courseId, activityId: course.activityId,
      sessionId, href: SCHOOL + FORM_PATH + '?sessid=' + sessionId };
    return { result: { state: 'open', candidate }, link };
  }

  function validCandidate(candidate) {
    return candidate && typeof candidate.sessionId === 'string' && /^[1-9]\d{0,12}$/.test(candidate.sessionId) &&
      candidate.href === SCHOOL + FORM_PATH + '?sessid=' + candidate.sessionId &&
      typeof candidate.label === 'string' && candidate.label.length <= 180 &&
      typeof candidate.rowKey === 'string' && candidate.rowKey.length <= 300 &&
      Number.isSafeInteger(candidate.startsAt) && Number.isSafeInteger(candidate.endsAt) &&
      candidate.startsAt < candidate.endsAt;
  }

  function sameCandidate(left, right) {
    return ['courseId', 'activityId', 'sessionId', 'href', 'label', 'rowKey', 'startsAt', 'endsAt']
      .every(key => left[key] === right[key]);
  }

  function noticeMatches(predicate) {
    return all(document, NOTICES).filter(visible).some(notice => predicate(text(notice)));
  }

  function attendanceForm(candidate, course, now) {
    if (loginPage()) return { result: state('login_required') };
    const url = schoolUrl(location.href);
    if (url?.pathname === FORM_PATH && url.searchParams.has('qrpass')) return { result: state('verification_required') };
    if (formSession(url) !== candidate.sessionId || !courseContext(course)) return { result: state('changed') };
    if (now < candidate.startsAt || now >= candidate.endsAt) return { result: state('closed') };
    if (noticeMatches(value => CHALLENGE_NOTICE.test(value))) return { result: state('verification_required') };
    if (noticeMatches(value => /(?:already (?:submitted|been marked)|attendance has already been)/i.test(value))) {
      return { result: state('already_recorded') };
    }
    const fields = all(document, '#id_session').filter(visible);
    if (fields.length !== 1) return { result: state('unsupported') };
    const [field] = fields;
    const form = field.closest('form');
    if (!form) return { result: state('unsupported') };
    if (all(form, CHALLENGES).length) return { result: state('verification_required') };
    if (/Your attendance has already been marked as:/i.test(text(form))) return { result: state('already_recorded') };
    const action = schoolUrl(form.getAttribute('action'));
    if (action?.pathname !== FORM_PATH || (action.search && formSession(action) !== candidate.sessionId) ||
        form.method.toLowerCase() !== 'post' || (form.target && form.target !== '_self')) {
      return { result: state('unsupported') };
    }
    const sessionFields = all(form, 'input[name="sessid"]');
    if (sessionFields.length !== 1 || sessionFields[0].type !== 'hidden' || sessionFields[0].value !== candidate.sessionId) {
      return { result: state('changed') };
    }
    const legend = field.querySelector('legend');
    const start = sessionTimes(text(legend?.querySelector('button') ?? legend), false);
    if (start?.startsAt !== candidate.startsAt) return { result: state('changed') };
    const radios = all(form, 'input[type="radio"][name="status"]');
    const presentControls = radios.filter(radio => Array.from(radio.labels ?? []).some(label => text(label) === 'Present'));
    const saveControls = all(form, 'input[type="submit"], button[type="submit"], button:not([type])')
      .filter(button => (button.tagName === 'INPUT' ? button.value.trim() : text(button)) === 'Save changes');
    if (presentControls.length !== 1 || saveControls.length !== 1) {
      return { result: state(presentControls.length > 1 || saveControls.length > 1 ? 'ambiguous' : 'unsupported') };
    }
    const [present] = presentControls;
    const [save] = saveControls;
    if (present.matches(':disabled') || save.matches(':disabled') || !visible(present) || !visible(save) ||
        save.id !== 'id_submitbutton' || ['formaction', 'formmethod', 'formtarget', 'formenctype', 'formnovalidate']
          .some(name => save.hasAttribute(name))) {
      return { result: state('unsupported') };
    }
    if (radios.some(radio => radio.checked)) return { result: state('changed') };
    return { present, save };
  }

  function inspectReceipt(candidate, course) {
    if (loginPage()) return state('login_required');
    const url = schoolUrl(location.href);
    const receiptSeen = noticeMatches(value => value === RECEIPT);
    if (formSession(url) === candidate.sessionId && courseContext(course)) {
      if (noticeMatches(value => CHALLENGE_NOTICE.test(value))) return state('verification_required');
      return state(receiptSeen ? 'receipt_seen' : 'unconfirmed');
    }
    const { result, rows } = overviewRows(course);
    if (result) return result;
    const matching = rows.filter(row => row.details && row.details.rowKey === candidate.rowKey &&
      row.details.startsAt === candidate.startsAt && row.details.endsAt === candidate.endsAt);
    if (matching.length > 1) return state('ambiguous');
    const [row] = matching;
    if (/^Present(?:\s+Update attendance)?$/.test(row?.statusText ?? '') && row.remarks === 'Self-recorded') {
      return { state: 'recorded', receipt: { label: candidate.label, message: receiptSeen ? RECEIPT : 'Present · Self-recorded' } };
    }
    if (noticeMatches(value => CHALLENGE_NOTICE.test(value))) return state('verification_required');
    return state('unconfirmed');
  }

  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || !message ||
        !['inspectAttendance', 'openAttendance', 'submitAttendance', 'inspectAttendanceReceipt'].includes(message.type)) return;
    try {
      const now = Date.now();
      if (message.type === 'inspectAttendance') {
        respond(inspectOverview(now).result);
        return;
      }
      const candidate = message.candidate;
      const course = { courseId: candidate?.courseId, activityId: candidate?.activityId };
      if (!validId(course.courseId) || !validId(course.activityId) || !validCandidate(candidate)) {
        respond(state('changed'));
        return;
      }
      if (message.type === 'inspectAttendanceReceipt') {
        respond(inspectReceipt(candidate, course));
        return;
      }
      if (message.type === 'openAttendance') {
        if (opened) {
          respond(state('unconfirmed'));
          return;
        }
        const { result, link } = inspectOverview(now, course);
        if (!link || !sameCandidate(candidate, result.candidate)) {
          respond(link ? state('changed') : result);
          return;
        }
        opened = true;
        respond(state('opening'));
        link.click();
        return;
      }
      if (submitted) {
        respond(state('unconfirmed'));
        return;
      }
      const { result, present, save } = attendanceForm(candidate, course, now);
      if (result) {
        respond(result);
        return;
      }
      submitted = true;
      present.click();
      if (!present.checked || !save.isConnected || save.matches(':disabled') || Date.now() >= candidate.endsAt) {
        respond(state('changed'));
        return;
      }
      save.click();
      respond(state('submitted'));
    } catch {
      respond(state('unconfirmed'));
    }
  });
})();
