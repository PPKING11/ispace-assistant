import { currentCandidate } from './plan.mjs';

const status = document.getElementById('status');
const label = document.getElementById('session');
const present = document.getElementById('present');
const check = document.getElementById('check');
const descriptions = {
  ready: '点击「检查当前签到活动」核对场次。',
  open: '学校当前有可提交的场次。请确认你已到场。',
  closed: '当前没有开放的签到场次。',
  already_recorded: '学校页面显示此场已签到。',
  recorded: '已在学校总览核对本场为出勤。',
  receipt_seen: '学校已显示签到回执。',
  login_required: '请先在 Chrome 登录 iSpace，再打开签到总览。',
  verification_required: '本场需要你在学校页面完成现场验证。',
  ambiguous: '学校页面有多个可能的场次，请在页面核对。',
  changed: '场次已变化或已关闭，请重新检查。',
  unconfirmed: '请在学校页面核对回执，避免重复提交。',
  wrong_page: '请打开本人课程在 iSpace 的签到总览。',
  unavailable: '暂时无法读取学校页。请刷新签到总览，再重新检查。',
  unsupported: '无法从此页面确定签到状态，请查看学校总览。',
  busy: '正在检查，请稍后。',
};

function render(result) {
  const candidate = result?.candidate;
  status.textContent = descriptions[result?.state] ?? descriptions.unavailable;
  label.textContent = candidate?.label ?? result?.receipt?.label ?? '';
  label.hidden = !label.textContent;
  check.disabled = result?.canCheck !== true;
  present.hidden = !result?.canCheck || result.state !== 'open' ||
    !currentCandidate(candidate, candidate?.activityId, Date.now());
  present.onclick = present.hidden ? null : event => {
    if (event.isTrusted) void action('confirmPresent', { sessionId: candidate.sessionId, rowKey: candidate.rowKey });
  };
}

async function action(type, extra) {
  check.disabled = true;
  present.disabled = true;
  status.textContent = type === 'confirmPresent' ? '正在核对并提交…' : descriptions.busy;
  try { render(await chrome.runtime.sendMessage({ type, ...extra })); }
  catch { render({ state: 'unavailable' }); }
  finally { present.disabled = false; }
}

check.onclick = () => void action('checkNow');
void action('getState');
