export const school = 'https://ispace.bnbu.edu.cn';
export const overviewPath = '/mod/attendance/view.php';
const formPath = '/mod/attendance/attendance.php';
const validId = value => typeof value === 'string' && /^[1-9]\d{0,12}$/.test(value);

function schoolUrl(raw) {
  try {
    const url = new URL(raw);
    return url.origin === school && !url.username && !url.password && !url.hash ? url : null;
  } catch { return null; }
}

export function overviewId(raw) {
  const url = schoolUrl(raw);
  const id = url?.searchParams.get('id');
  return url?.pathname === overviewPath && validId(id) && [...url.searchParams].length === 1 ? id : null;
}

export function isForm(raw, sessionId) {
  const url = schoolUrl(raw);
  return Boolean(url?.pathname === formPath && url.searchParams.get('sessid') === sessionId &&
    url.searchParams.getAll('sessid').length === 1 && url.searchParams.getAll('sesskey').length <= 1 &&
    [...url.searchParams.keys()].every(key => key === 'sessid' || key === 'sesskey'));
}

export function currentCandidate(candidate, activityId, now) {
  return Boolean(candidate && validId(activityId) && candidate.activityId === activityId &&
    validId(candidate.courseId) && validId(candidate.sessionId) &&
    typeof candidate.rowKey === 'string' && candidate.rowKey.length > 0 && candidate.rowKey.length <= 300 &&
    typeof candidate.label === 'string' && candidate.label.length > 0 && candidate.label.length <= 180 &&
    Number.isSafeInteger(candidate.startsAt) && Number.isSafeInteger(candidate.endsAt) &&
    candidate.startsAt <= now && now < candidate.endsAt &&
    candidate.href === school + formPath + '?sessid=' + candidate.sessionId);
}
