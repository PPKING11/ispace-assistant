"""Windows write-only secret clipboard with exclusion markers and sequence guard.

No clipboard-read API, history API, native call at import, logging or file access.
"""
import ctypes
from ctypes import wintypes
import os

from login_core import Secret, SyncError

EXCLUSION_FORMATS = (
    ('ExcludeClipboardContentFromMonitorProcessing', b'\0'),
    ('CanIncludeInClipboardHistory', b'\0\0\0\0'),
    ('CanUploadToCloudClipboard', b'\0\0\0\0'),
)


class WindowsPrivateClipboard:
    def __init__(self, window_handle):
        self.window_handle = window_handle

    def _api(self):
        if os.name != 'nt':
            raise SyncError('unsupported_platform')
        user = ctypes.WinDLL('user32', use_last_error=True)
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        for name, args, result in (
            ('IsWindow', [wintypes.HWND], wintypes.BOOL),
            ('OpenClipboard', [wintypes.HWND], wintypes.BOOL),
            ('CloseClipboard', [], wintypes.BOOL),
            ('EmptyClipboard', [], wintypes.BOOL),
            ('RegisterClipboardFormatW', [wintypes.LPCWSTR], wintypes.UINT),
            ('SetClipboardData', [wintypes.UINT, wintypes.HANDLE], wintypes.HANDLE),
            ('GetClipboardSequenceNumber', [], wintypes.DWORD),
        ):
            method = getattr(user, name); method.argtypes = args; method.restype = result
        for name, args, result in (
            ('GlobalAlloc', [wintypes.UINT, ctypes.c_size_t], wintypes.HANDLE),
            ('GlobalLock', [wintypes.HANDLE], ctypes.c_void_p),
            ('GlobalUnlock', [wintypes.HANDLE], wintypes.BOOL),
            ('GlobalFree', [wintypes.HANDLE], wintypes.HANDLE),
        ):
            method = getattr(kernel, name); method.argtypes = args; method.restype = result
        if not self.window_handle or not user.IsWindow(self.window_handle):
            raise SyncError('interactive_required')
        return user, kernel

    @staticmethod
    def _put(user, kernel, format_id, raw):
        handle = kernel.GlobalAlloc(0x0002, len(raw))  # GMEM_MOVEABLE
        if not handle:
            raise SyncError('storage_failure')
        pointer = None
        try:
            pointer = kernel.GlobalLock(handle)
            if not pointer:
                raise SyncError('storage_failure')
            ctypes.memmove(pointer, raw, len(raw))
            kernel.GlobalUnlock(handle); pointer = None
            if not user.SetClipboardData(format_id, handle):
                raise SyncError('storage_failure')
            handle = None  # successful SetClipboardData transfers ownership to Windows
        finally:
            if handle:
                if pointer:
                    ctypes.memset(pointer, 0, len(raw)); kernel.GlobalUnlock(handle)
                else:
                    pointer = kernel.GlobalLock(handle)
                    if pointer:
                        ctypes.memset(pointer, 0, len(raw)); kernel.GlobalUnlock(handle)
                kernel.GlobalFree(handle)

    def copy_secret(self, token):
        if type(token) is not Secret:
            raise SyncError('invalid_parameters')
        value = token._for_request()
        if not 16 <= len(value) <= 512 or not value.isascii() or not value.isalnum():
            raise SyncError('invalid_parameters')
        user, kernel = self._api()
        formats = [(user.RegisterClipboardFormatW(name), payload) for name, payload in EXCLUSION_FORMATS]
        if any(not fid for fid, _ in formats):
            raise SyncError('storage_failure')
        if not user.OpenClipboard(self.window_handle):
            raise SyncError('concurrent_run')
        try:
            if not user.EmptyClipboard():
                raise SyncError('storage_failure')
            # All exclusion markers must succeed BEFORE token publication.
            for fid, payload in formats:
                self._put(user, kernel, fid, payload)
            self._put(user, kernel, 13, value.encode('utf-16-le') + b'\0\0')  # CF_UNICODETEXT
            sequence = user.GetClipboardSequenceNumber()
            if not sequence:
                raise SyncError('storage_failure')
            return sequence
        except Exception:
            user.EmptyClipboard()  # still exclusively open; remove any partial secret
            raise SyncError('storage_failure') from None
        finally:
            user.CloseClipboard()

    def clear_if_unchanged(self, expected_sequence):
        if type(expected_sequence) is not int or not 0 < expected_sequence <= 0xffffffff:
            raise SyncError('invalid_parameters')
        user, _ = self._api()
        if not user.OpenClipboard(self.window_handle):
            raise SyncError('concurrent_run')
        try:
            # Check while exclusively open, so another writer cannot race clearing.
            if user.GetClipboardSequenceNumber() != expected_sequence:
                return False
            if not user.EmptyClipboard():
                raise SyncError('storage_failure')
            return True
        finally:
            user.CloseClipboard()
