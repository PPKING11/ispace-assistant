"""Obtain a Moodle mobile service token with a user-supplied login."""
import http.client
import json
import ssl
from urllib.parse import urlencode


class SyncError(Exception):
    pass


class Secret:
    def __init__(self, value):
        self._value = value

    def _for_request(self):
        return self._value

    def clear(self):
        self._value = ""

    def __repr__(self):
        return "Secret(<redacted>)"


def login(username, password, connection_factory=http.client.HTTPSConnection):
    if not username or not password or len(username) > 256 or len(password) > 4096:
        raise SyncError("请输入有效的账号和密码")
    context = ssl.create_default_context()
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    connection = None
    try:
        connection = connection_factory("ispace.bnbu.edu.cn", port=443, timeout=15, context=context)
        body = urlencode({"username": username, "password": password, "service": "moodle_mobile_app"}).encode("ascii")
        connection.request("POST", "/login/token.php", body=body, headers={
            "Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"
        })
        response = connection.getresponse()
        if 300 <= response.status < 400:
            raise SyncError("学校要求其他登录方式，请联系学校确认")
        if response.status != 200:
            raise SyncError("学校登录服务暂不可用")
        raw = response.read(65537)
        if len(raw) > 65536:
            raise SyncError("学校返回的数据异常")
        data = json.loads(raw)
        token = data.get("token") if isinstance(data, dict) else None
        if not isinstance(token, str) or not 16 <= len(token) <= 512 or not token.isascii() or not token.isalnum():
            raise SyncError("未取得授权，请核对账号或向学校确认移动端登录权限")
        return Secret(token)
    except SyncError:
        raise
    except Exception:
        raise SyncError("连接失败，请检查网络后重试") from None
    finally:
        if connection:
            connection.close()
