"""Interactive local sign-in and user-controlled secret transfer."""
import os
import queue
import threading
import tkinter as tk
from tkinter import ttk

from login_core import SyncError, login
from secure_clipboard import WindowsPrivateClipboard


def main():
    if os.name != "nt":
        raise SystemExit("此工具需要 Windows")
    root = tk.Tk()
    root.title("iSpace 助手｜连接学校账号")
    root.geometry("630x450")
    root.report_callback_exception = lambda *args: status.set("界面出现问题，请关闭后重试。")
    frame = ttk.Frame(root, padding=20)
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text="使用自己的学校账号登录", font=("", 14, "bold")).pack(anchor="w")
    ttk.Label(frame, wraplength=580, text="账号密码只发送到学校 iSpace。成功后可复制授权，亲自粘贴到自己私人 Sites 的 ISPACE_TOKEN 密钥设置。授权可能具有学校账号允许的其他权限。").pack(anchor="w", pady=10)
    ttk.Label(frame, text="学校账号").pack(anchor="w")
    account = ttk.Entry(frame, width=48)
    account.pack(anchor="w")
    ttk.Label(frame, text="学校密码").pack(anchor="w", pady=(8, 0))
    password = ttk.Entry(frame, show="●", width=48)
    password.pack(anchor="w")
    status = tk.StringVar(value="请登录后继续。")
    ttk.Label(frame, textvariable=status, wraplength=580).pack(anchor="w", pady=12)
    state = {"token": None, "sequence": None}
    result_queue = queue.Queue()
    clipboard = WindowsPrivateClipboard(root.winfo_id())

    def clear_clipboard(expected=None):
        sequence = state["sequence"]
        if expected is not None and sequence != expected:
            return
        if sequence is not None:
            try:
                clipboard.clear_if_unchanged(sequence)
            except Exception:
                status.set("未能清除剪贴板，请复制一段无关文字覆盖它。")
                return
            state["sequence"] = None

    def close():
        clear_clipboard()
        if state["token"]:
            state["token"].clear()
        root.destroy()

    def poll():
        try:
            token, error = result_queue.get_nowait()
        except queue.Empty:
            root.after(100, poll)
            return
        sign_in.config(state="normal")
        if error:
            status.set(error)
        else:
            state["token"] = token
            copy.config(state="normal")
            status.set("登录成功。打开自己的 Sites 设置，再点击复制授权。")

    def submit():
        username, secret = account.get(), password.get()
        password.delete(0, tk.END)
        sign_in.config(state="disabled")
        if state["token"]:
            state["token"].clear()
            state["token"] = None
        copy.config(state="disabled")
        status.set("正在连接学校……")

        def worker():
            try:
                result_queue.put((login(username, secret), None))
            except SyncError as error:
                result_queue.put((None, str(error)))
            except Exception:
                result_queue.put((None, "登录未完成，请稍后重试。"))

        threading.Thread(target=worker, daemon=True).start()
        root.after(100, poll)

    def copy_token():
        try:
            clear_clipboard()
            if state["sequence"] is not None:
                raise SyncError("无法清理旧的剪贴板内容")
            state["sequence"] = clipboard.copy_secret(state["token"])
            state["token"].clear()
            state["token"] = None
            copy.config(state="disabled")
            status.set("已复制。请在 60 秒内粘贴到私人 Sites 的 ISPACE_TOKEN 密钥字段并保存。")
            root.after(60000, clear_clipboard, state["sequence"])
        except Exception:
            status.set("复制失败，未完成配置。请重新登录后重试。")

    sign_in = ttk.Button(frame, text="登录学校 iSpace", command=submit)
    sign_in.pack(anchor="w")
    copy = ttk.Button(frame, text="复制授权到剪贴板", command=copy_token, state="disabled")
    copy.pack(anchor="w", pady=8)
    root.protocol("WM_DELETE_WINDOW", close)
    root.mainloop()


if __name__ == "__main__":
    main()
