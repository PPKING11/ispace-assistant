# ispace助手的任务和交接记录

在 `ispace助手` 项目中运行 `node assistant-runtime/assistant.mjs status` 可读取 `state.json` 和每个活跃聊天的交接状态。程序只处理本地记录，实际派发、创建聊天、改名、置顶、归档和查看 iSpace 回执由主聊天及受指派的副聊天使用相应工具完成。

CLI 接收一个 JSON 对象。Windows PowerShell 可以通过标准输入传递 JSON。

```powershell
@{ role = 'main'; chatId = '替换成当前主聊天ID' } | ConvertTo-Json -Compress | node assistant-runtime/assistant.mjs register-chat --stdin
```

聊天 ID、任务 ID 和提交尝试 ID 用现有可核对的标识，包含字母、数字、点、冒号、连字符或下划线。CLI 以运行时所在的项目为准，默认读取和写入 `state.json`。`--state` 可切换到同项目内的另一个相对 JSON 文件。不要直接编辑任务记录。`state.json.lock.sqlite` 只用于协调并行写入。

## 派发和进度

- `register-chat {role, chatId, createdAt?}` 登记主聊天或副聊天。`role` 为 `main` 或 `worker`。同一个聊天重复登记不会修改开始时间。
- `observe-rounds {chatId, rounds, working?, contextStrained?}` 记录已经完成的绝对轮数及安全交接状态。录入的轮数不会因重复运行而增加。只有知道状态时才更新两个可选标记。
- `add-task {taskId, title, course?, dueAt?, source?, nextStep?}` 登记作业。同一作业始终使用同一个 `taskId`。只给了日期时，用 `YYYY-MM-DD`。准确时间用带时区的 ISO 8601。无截止信息可省略 `dueAt`。
- `assign-task {taskId, chatId}` 指定负责人。重新分工时先用 `release-task {taskId, chatId}` 释放已登记的负责人，由当前主聊天或现负责人操作。提交状态待核实期间保持责任归属。
- `update-task {taskId, chatId, status?, nextStep?, artifact?, dueAt?, source?}` 保存进度。`status` 可以是 `todo`、`active`、`blocked`、`ready` 或 `done`。`artifact` 包含本地 `path`、明确的 `version` 和实际 `sha256`，也可补充 `bytes`。有负责副聊天时，由该聊天登记修改后的文件。

## 换聊天

1. `status` 可以传 `{chatId}` 查看单个聊天。主聊天达到 40 轮或 7 天，副聊天达到 25 轮或 3 天时进入候选。上下文吃力也可以提前进入候选。工作中、有未核实的提交，以及没有要接续的任务时会明确列出阻碍。刚收到一项待做工作时，可以用 `workPending: true` 评估再派发。
2. `plan-rotation {chatId, workPending?}` 只在首次登记交接时返回 `shouldCreate: true`，并给出唯一的 `candidateTitle`。若创建工具的返回不确定，先按这次交接标题查找，再关联现有候选。只有工具明确返回未创建，并且查找也确认无候选时，才用 `retry-rotation-create {rotationId, verifiedFailureRef}` 争取一次重试。超时或状态不明时，保留原交接并核对。
3. `attach-rotation {rotationId, newChatId}` 记下候选聊天。候选读取规则、对应任务、文件和未决事项，确认能接续后调用 `acknowledge-rotation {rotationId, chatId}`。主聊天调用 `commit-rotation {rotationId}` 完成接替。此时旧聊天和新聊天的正式名称才确定。副聊天接替时，未完成任务的负责人一并转移。
4. 接替后按旧聊天 ID 核对 Codex 自动化，暂停该旧聊天的 iSpace 专属定时并回读。项目级巡检从账本寻找当前主聊天，可以继续运行。确认旧聊天没有还在运行的专属定时后，调用 `confirm-rotation-schedule-cleanup {rotationId, oldChatId}`。
5. 回读实际改名、置顶和历史处理结果后，调用 `finish-rotation {rotationId, actual}`，填入已执行的 `archive` 或 `keep`。默认保留旧聊天。用户明确选择时用 `set-old-chat-policy {policy}` 保存。任一步中断后先查已有交接编号，继续善后。

## 学校提交

1. 主聊天在对话里提供具体作业与最终文件，核对题面要求个人还是小组完成。用户在同一聊天明确授权这项作业和这份文件后，用 `approve-submission {taskId, chatId, fileSha256, authorizationRef, workScope}` 登记。该消息就是授权来源。站点提交准备页及确认编号可供页面流程选用，聊天代交流程以账本和学校原页完成。`workScope` 为 `individual` 或 `group`。换文件需要重新确认。
2. 副聊天打开已登录的学校原页，读回实时状态后调用 `start-submission {taskId, chatId, attemptId, school}`。程序核对课程、作业、页面 ID 以及磁盘文件的 SHA-256 和大小。只在 `shouldAct: true` 时按返回的 `action` 操作。`attach` 可以开始附文件。在有独立提交按钮的页面可保存草稿。`finalize_draft` 表示使用确认过的现有学校草稿。
3. 点正式提交或会直接交卷的保存按钮前，重新读学校状态，调用 `authorize-submit {taskId, chatId, attemptId, school}`。只在 `shouldSubmit: true` 后点击一次。学校页面变动时暂停。草稿先从学校页面获取原件做 SHA-256 核对，只有唯一文件且指纹相同才继续。现有草稿若要在后续尝试正式提交，主聊天登记新授权并指定 `finalizeDraft: true`。
4. 点击后回读同一学校页面。已有同一提交的有效站点确认编号时，也可用 `verify_ispace_submission_receipt` 辅助核对本人或本组状态。把可见的回执区域截图存为项目内临时 PNG 或 JPEG，避开其他窗口、账号凭据及无关个人信息，再用 `record-receipt {taskId, chatId, attemptId, status, evidence, schoolReceipt}` 归档。截图缺失时说明原因。已提交、草稿、明确未提交、状态不明分别用 `submitted`、`draft`、`not_submitted`、`unknown`。状态模糊、超时或确认内容不符时，先记录 `unknown`，回读前暂停重复上传和换班。

`school` 字段来自打开的学校页面和经授权的站点读回，包含数值 `courseId`、`assignmentId`、`moduleId`，作业原页 `url`，带时区的 `observedAt`，当前 `status`，上传入口类型 `submissionMode`，布尔值 `hasSeparateSubmit`，`savedFileCount` 和简短 `evidence`。只有页面明确开放、当前步骤可操作，且无需等待本人登录、声明或验证码时，才填 `canAct: true`。题面小组或组上传时需要 `groupStatus: 'clear'` 和 `groupEvidence` 记录已核对的本组上传人及提交情况。发现已有组内提交或冲突草稿先停。学校草稿需要另填从学校原件计算的 `draftSha256`。

站点的 `observation` 中，`schoolAssignmentId`、`schoolModuleId`、`schoolUrl`、`readAt` 对应运行时的 `assignmentId`、`moduleId`、`url`、`observedAt`。`schoolStatus: 'new'` 且已核实无已存文件才对应 `not_submitted`。站点无法确认的字段应在官方 Chrome 页面核对，仍无法核实就暂停。题面要求小组而学校给个人入口时，站点的本人提交状态只能核对个人记录，另查组内安排。

`schoolReceipt` 包含同样的三个身份 ID、`url`、`submissionMode`、`status`、`observedAt` 及学校显示的回执 `text`。校方实际提供时间时填 `schoolTime` 或 `schoolTimeText`。明确显示附件时填写 `files: [{name, bytes}]`，大小未显示可填 `null`，附件清单未显示则省略 `files`。截图使用 `screenshotPath`，无法截取时填写 `screenshotUnavailableReason`。完全读不到页面的尝试可直接记录 `unknown` 并说明现象。

回执会按课程、作业、尝试编号和状态存至本机 `回执` 目录。先前状态不明的档案会和后续确证结果分别保存。可用 `verify-receipt-archive {path, sha256}` 检查账本所记回执 JSON 和附图的校验值。校方只给出文件名和大小时，回执记录文件元数据匹配，文件字节仍未核实。

在项目根目录运行 `node --test assistant-runtime/*.test.mjs` 验证助手规则、并发记录和模拟提交归档。
