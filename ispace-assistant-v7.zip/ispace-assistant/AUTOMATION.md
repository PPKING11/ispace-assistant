# Codex 本机后台任务

按首设保存的选择，查找当前安装目录对应的本地项目，用 Codex 的定时任务操作创建或更新「ispace助手｜后台检查与交接」。默认使用 `gpt-6.1-terra` 和 `high`，每天北京时间 08:10 和 20:10。电脑和 Codex 须能运行任务。匹配已有任务时沿用同一项。用本安装目录、用户的私人 iSpace 应用及本地项目。每次运行按以下顺序执行。

## 核对下载与递送通知

1. 在已安装的本项目读取 `assistant-runtime/download-audit-collect.js`。在工具编排中加载这个安装文件，把当前组件的绝对路径作为 `project`，并绑定同一个私人 iSpace 应用的两个读取工具。第一次设置使用 `preview: true` 核对。定时检查省略这个选项。
2. 如有 `pending`，读取 `assistant-runtime/assistant.mjs status` 取得当前 `mainChatId`。使用 Codex 的聊天消息工具将 `pending.message` 发给该主聊天。保留提醒编号和消息内容。确认应用已经接收，再运行 `node --no-warnings assistant-runtime/download-reminder.mjs confirm <编号>`。如果发送结果不明确，先核对主聊天是否收到同一个编号。
3. 保留日报列出的课程、文件名和原因。名单较长时，待发消息会附完整本机文件名单链接。遇到课程快照或本机目录暂时不可用时，按返回的待发提醒汇报，等下次有效核对再判断哪些文件新增或尚未下载。继续处理其它已授权的检查。

工具编排参考如下。两个读取函数是从本人已经连接的应用中选出的工具。路径来自本次安装位置。

```javascript
const reader = await tools.exec_command({
  cmd: "Get-Content -LiteralPath 'assistant-runtime/download-audit-collect.js' -Raw",
  workdir: projectDirectory,
  max_output_tokens: 24000,
});
if (reader.exit_code !== 0) throw new Error('下载核对程序未读到');
const collect = new Function('return (\n' + reader.output.trim() + '\n)')();
const report = await collect(tools, {
  project: projectDirectory,
  readSyncStatus: ownerSyncStatusTool,
  readLatestItems: ownerLatestItemsTool,
});
text(report);
```

## 登记并派发作业

先运行 `node --no-warnings assistant-runtime/setup-schedule.mjs claim assignments`。当返回 `allowed: true` 时进行新的作业检查。已有任务、交接和待发提醒可单独接续。新增和截止提醒遵守首设的作业提醒开关，关闭时仅按用户要求继续已有任务。

核实同步连接、当前选课和快照新鲜度。用 `search_course_items` 查作业，分页时固定快照。只有确认属于本人的待办才登记。用 `read_course_item` 核对作业名称、开放状态、直接附件及实际完成方式。按 `WORKFLOW.md` 的「新作业提醒与后续询问」和「小组作业的选题和分工」把对应的问题交给主聊天。新作业的初次提醒和等待答复记在原任务，后续检查沿用。用户同意起草个人作业或读取小组资料后，按截止时间和依赖交给空闲副聊天。用 `add-task` 和 `assign-task` 登记后再发送给负责的副聊天。小组第一次只回报选题和理由并请用户确认。主聊天确认选题和实际人数后，才安排制定分工。草稿、完成文件、选题建议或正式分工回报主聊天。完成文件先发给用户审查，再由主聊天询问具体文件是否代交。定时任务暂停在等待明确确认。

在获准巡检并读取同一份完整、新鲜且已验证的课程快照后，可将本轮前已登记的未交作业交给 `node --no-warnings assistant-runtime/assignment-deadline-reminders.mjs observe --stdin`。JSON 含 `verified`、`freshness`、`verifiedAt`、`courses`（含 `id` 和 `code`），以及 `items`（含 `id`、`courseId`、`title`、`kind`、`rawDates.duedate`、`rawSubmission.attempt.extensionduedate`、`learningState.submission`、`completion`）。发送时保留返回的提醒 ID。桌面工具接收后逐条用 `assignment-deadline-reminders.mjs confirm <id>` 确认。结果不明时先按编号检查是否已经递送。

任务在等待用户回复或已记录暂不需要协助时，本轮结束该任务的询问与派发，保留原记录等用户主动续接。

## 处理交接

1. 使用 `node assistant-runtime/rounds.mjs` 观察轮次，用桌面工具确认忙闲，只把核实的轮次和状态写入 `observe-rounds`。读取账本找当前角色和已进行的交接。遇到活跃的文件操作、学校回执待确认、源数据未取得或已有候选状态不清楚，优先解决不确定点。
2. 到达门槛、有任务需要接续时调用 `plan-rotation`。只有账本批准创建时才在当前安装项目里创建候选，使用账本给的唯一名称。返回不明确先查现有候选。确认未创建、查无候选时可用 `retry-rotation-create`。
3. 用实际新聊天 ID 调用 `attach-rotation`，通知候选核对规则、任务、文件版本和下一步，并让它调用 `acknowledge-rotation`。确认后调用 `commit-rotation`，改名并切换主聊天置顶。找出旧聊天专属的 iSpace 定时任务并暂停，回读后调用 `confirm-rotation-schedule-cleanup {rotationId, oldChatId}`。项目后台巡检继续用账本查找当前主聊天。按已保存的偏好保留或归档历史，未指定时默认保留。回读后调用 `finish-rotation`。永久删除需用户对具体聊天确认。
4. 作业有实质变化或需要用户确认时，在当前主聊天报告。后台进展以「【ispace助手后台汇报】」开头，换班核对以「【ispace助手交接核对】」开头。保存结果并结束本次工作。
