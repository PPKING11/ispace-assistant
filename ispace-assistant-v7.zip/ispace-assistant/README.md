# iSpace 助手｜一站式配置

解压后，在桌面版 Codex 中将 `ispace-assistant` 打开为一个本地项目，在新聊天里发送下面这句话。已经装过的同学在原项目和主聊天中继续。需要 Windows、Chrome 和 Node.js 22.13 或更新版本。请将解压后的各个组件目录放在一起。

> 请按这个项目 README 的「Codex 配置流程」设置 iSpace 助手并打开首次设置窗口。接通本人课程后，根据我的选择准备下载和签到组件，配置主副聊天、后台巡检、提醒和换班。我会在官方页面完成学校登录、课程授权和 Chrome 要求我确认的步骤。已经核对过的配置继续使用。

首次设置只填姓名、学号、本机下载、下载检查间隔和作业提醒。下载目录默认用桌面的 `Course`，也可以在扩展里选择。作业提醒默认提前 12 小时，收到提醒的时间取决于巡检。完成本人登录、学校令牌填写或 Chrome 安装授权后，回到同一聊天说「继续配置」。

## Codex 配置流程

1. **站点和学校课程。** 先读本项目 `AGENTS.md`、`WORKFLOW.md` 和 `AUTOMATION.md`。从本安装包的同级 `ispace-site` 目录[准备私人站点](../ispace-site/README.md)。先查看是否已有该目录对应的私人站点和 Codex 连接。有就继续使用。没有则帮助用户私有发布、打开正式设置并连接新站点生成的插件。学校只准本人使用的令牌由用户在官方 Sites Settings 密钥字段填入。请用户确认要同步的课程，并在官方设置页完成一次同步。使用匹配站点的 `read_sync_status`，核对课程、已验证且未过期的快照和 `localSyncProfileHash`。后续始终用这一连接。
2. **首次设置。** 提取第 1 步连接工具返回的非密钥 `syncStatus`。将 `{syncStatus}` 作为 JSON 传给 `node --no-warnings onboarding.mjs open --stdin`，在当前聊天提供程序打印的本机 URL。取得已经核实的扩展开关和间隔时，可以在同一个 JSON 中附上 `autoDownloadEnabled`、`autoIntervalMinutes`、`autoDailyLimit`。提交后回读 `首次设置待应用.json` 和 `助手设置.json`，按第 3、5 步应用保存内容。
3. **Windows 和 Chrome 下载。** 按[下载组件说明](../ispace-course-local/README.md)核对 `Install-LocalHost.ps1 -Check` 和私人站点「使用设置」页。按首设选择启用或关闭自动下载，核对扩展开关与间隔。如果用户选择下载且缺少组件，请按说明安装同包的 Windows 助手和 Chrome 扩展，由用户完成 Chrome 授权。设置私人站点、年级学期、归档目录和间隔。已核实的本人配对可以沿用。完成「试下载一份课件」并核对保存文件。选择关掉下载时，不要求新装课件下载组件。需要签到时，按[签到组件说明](../ispace-attendance-local/README.md)加载同包的 Chrome 扩展。
4. **主副聊天。** 在本项目把当前主聊天命名为「ispace助手」并置顶，创建或复用「默默工作的后台员工」。将 `{mainChatId, workerChatId, syncStatus}` 通过标准输入交给 `node --no-warnings onboarding.mjs finish --stdin`。核对 `readyForAutomation`。启用自动下载时再核对 `readyForAuditPreview`。前者已记录本机下载选择和已登记聊天，后者还确认同一账号的归档配对。重试时复用已登记聊天，换班按交接流程执行。
5. **定时检查。** 如果启用自动下载，按 `AUTOMATION.md` 完成一次只读下载清单核对。用 Codex 定时任务操作创建或更新本项目的本机后台任务，回读启用状态、日程和模型。首次设置默认后台为 `gpt-6.1-terra / high`。有待应用后台模型时，用 `node --no-warnings assistant-runtime/setup-preferences.mjs activate-background-model <回读模型> <回读推理强度>` 登记核对结果。确认所有待应用设置到位后清理本次待应用记录。向用户报告站点连接、下载配对、主副聊天和后台任务状态。

`node --no-warnings onboarding.mjs check` 可以在连接前查看初始进度。设置程序会在本项目写入本人配置、聊天任务记录和草稿目录。查状态时仅传站点连接工具返回的非密钥状态 JSON。给其他人分享时发送原安装包。
